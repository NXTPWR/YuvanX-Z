'use client';

import { useEffect, useState } from 'react';
import { CheckCircle2, Eye, EyeOff, LogIn, Mail, UserPlus } from 'lucide-react';
import { useAuthStore } from '@/lib/store/auth';
import { Button } from '@/components/ui/button';
import { Modal } from '@/components/ui/modal';
import { LogoMark } from '@/components/logo';
import { cn } from '@/lib/utils';

export interface AuthDialogProps {
  open: boolean;
  onClose: () => void;
  /** What the user was trying to do — used to word the copy. */
  reason?: 'sync' | 'files' | 'account';
}

type Mode = 'signin' | 'signup' | 'confirm';

const COPY: Record<Mode, { title: string; description: string }> = {
  signin: {
    title: 'Welcome back',
    description: 'Sign in to pick up your conversations, memories and files on any device.',
  },
  signup: {
    title: 'Create your account',
    description: 'Free, instant and no email confirmation needed — start in seconds.',
  },
  confirm: {
    title: 'Check your inbox',
    description: 'One more step: confirm your email address, then sign in.',
  },
};

export function AuthDialog({ open, onClose, reason = 'sync' }: AuthDialogProps) {
  /* Mounted only while the dialog is open, so the initial mode is always right. */
  const [mode, setMode] = useState<Mode>(() =>
    useAuthStore.getState().needsEmailConfirmation ? 'confirm' : 'signin',
  );
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const pending = useAuthStore((state) => state.pending);
  const error = useAuthStore((state) => state.error);
  const clearError = useAuthStore((state) => state.clearError);
  const signIn = useAuthStore((state) => state.signIn);
  const signUp = useAuthStore((state) => state.signUp);
  const googleEnabled = useAuthStore((state) => state.googleEnabled);
  const signInWithGoogle = useAuthStore((state) => state.signInWithGoogle);

  /* Clear any stale error from a previous attempt when the dialog opens. */
  useEffect(() => {
    if (!open) return;
    clearError();
  }, [open, clearError]);

  const switchMode = (next: Mode) => {
    clearError();
    setMode(next);
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (mode === 'signin') {
      const ok = await signIn(email.trim(), password);
      if (ok) onClose();
      return;
    }
    if (mode === 'signup') {
      const ok = await signUp(email.trim(), password);
      if (ok) {
        const { needsEmailConfirmation: confirm } = useAuthStore.getState();
        if (confirm) setMode('confirm');
        else onClose();
      }
    }
  };

  const reasonCopy =
    reason === 'files'
      ? 'An account lets you attach larger files and keep them private.'
      : reason === 'account'
        ? 'Sign in to manage your account.'
        : 'Your chats stay in sync across every device you sign in on.';

  const tabs = (
    <div
      role="tablist"
      aria-label="Account"
      className="mb-4 grid grid-cols-2 gap-1 rounded-[var(--radius-md)] border border-line bg-[rgb(var(--panel)/0.45)] p-1"
    >
      <button
        type="button"
        role="tab"
        aria-selected={mode === 'signin'}
        onClick={() => switchMode('signin')}
        className={cn(
          'flex h-9 items-center justify-center gap-1.5 rounded-[var(--radius-sm)] text-sm font-medium transition-all',
          'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
          mode === 'signin'
            ? 'bg-accent/15 text-accent shadow-[inset_0_0_0_1px_rgb(var(--accent)/0.35)]'
            : 'text-muted hover:bg-[rgb(var(--panel)/0.7)] hover:text-ink',
        )}
      >
        <LogIn size={14} /> Sign in
      </button>
      <button
        type="button"
        role="tab"
        aria-selected={mode === 'signup'}
        onClick={() => switchMode('signup')}
        className={cn(
          'flex h-9 items-center justify-center gap-1.5 rounded-[var(--radius-sm)] text-sm font-medium transition-all',
          'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
          mode === 'signup'
            ? 'bg-accent/15 text-accent shadow-[inset_0_0_0_1px_rgb(var(--accent)/0.35)]'
            : 'text-muted hover:bg-[rgb(var(--panel)/0.7)] hover:text-ink',
        )}
      >
        <UserPlus size={14} /> Create account
      </button>
    </div>
  );

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={COPY[mode].title}
      description={COPY[mode].description}
      size="sm"
    >
      {mode === 'confirm' ? (
        <div className="space-y-4">
          <div className="flex items-start gap-3 rounded-[var(--radius-md)] border border-[rgb(var(--success)/0.35)] bg-[rgb(var(--success)/0.08)] px-3 py-3 text-xs leading-relaxed text-ink">
            <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-success" />
            <span>
              We sent a confirmation link to <strong>{email || 'your inbox'}</strong>. Open it, then
              sign in here.
            </span>
          </div>
          <Button
            type="button"
            variant="primary"
            size="lg"
            className="w-full"
            onClick={() => switchMode('signin')}
          >
            <LogIn size={15} /> Back to sign in
          </Button>
        </div>
      ) : (
        <>
          {tabs}

          <form onSubmit={submit} className="space-y-3">
            <div>
              <label htmlFor="yx-auth-email" className="mb-1.5 block text-xs font-medium text-ink">
                Email
              </label>
              <input
                id="yx-auth-email"
                type="email"
                required
                data-autofocus
                autoComplete="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@example.com"
                className="h-10 w-full rounded-[var(--radius-md)] border border-line-strong bg-[rgb(var(--panel)/0.6)] px-3 text-sm text-ink placeholder:text-subtle focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30"
              />
            </div>

            <div>
              <label
                htmlFor="yx-auth-password"
                className="mb-1.5 block text-xs font-medium text-ink"
              >
                Password
              </label>
              <div className="relative">
                <input
                  id="yx-auth-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={8}
                  autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder={mode === 'signup' ? 'At least 8 characters' : 'Your password'}
                  className="h-10 w-full rounded-[var(--radius-md)] border border-line-strong bg-[rgb(var(--panel)/0.6)] pl-3 pr-10 text-sm text-ink placeholder:text-subtle focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((value) => !value)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-1.5 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-[6px] text-subtle transition-colors hover:bg-[rgb(var(--panel)/0.8)] hover:text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
              {mode === 'signup' ? (
                <p className="mt-1.5 text-[0.7rem] text-subtle">
                  Eight characters or more. A passphrase works great.
                </p>
              ) : null}
            </div>

            {error ? (
              <p
                role="alert"
                className="rounded-[var(--radius-sm)] border border-[rgb(var(--danger)/0.35)] bg-[rgb(var(--danger)/0.08)] px-3 py-2 text-xs leading-relaxed text-danger"
              >
                {error}
              </p>
            ) : null}

            <Button type="submit" variant="primary" size="lg" loading={pending} className="w-full">
              {mode === 'signup' ? (
                <>
                  <UserPlus size={15} /> Create account
                </>
              ) : (
                <>
                  <LogIn size={15} /> Sign in
                </>
              )}
            </Button>
          </form>

          {googleEnabled ? (
            <>
              <div className="my-4 flex items-center gap-3">
                <span className="h-px flex-1 bg-[rgb(var(--border)/0.14)]" />
                <span className="text-[0.68rem] uppercase tracking-wider text-subtle">or</span>
                <span className="h-px flex-1 bg-[rgb(var(--border)/0.14)]" />
              </div>

              <Button
                type="button"
                variant="outline"
                size="lg"
                className="w-full"
                disabled={pending}
                onClick={async () => {
                  const ok = await signInWithGoogle();
                  if (ok) onClose();
                }}
              >
                <svg width="15" height="15" viewBox="0 0 48 48" aria-hidden="true">
                  <path
                    fill="#EA4335"
                    d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M10.53 28.59A14.5 14.5 0 0 1 9.75 24c0-1.59.27-3.13.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                  />
                  <path
                    fill="#34A853"
                    d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                  />
                </svg>
                Continue with Google
              </Button>
            </>
          ) : null}

          <div className="mt-5 space-y-2 border-t border-line pt-4 text-xs text-muted">
            <p className="flex items-center gap-2">
              <LogoMark size={16} className="opacity-80" />
              {reasonCopy}
            </p>
            {mode === 'signup' ? (
              <p className="flex items-center gap-1.5 text-subtle">
                <Mail size={12} /> No spam, no credit card, no catch.
              </p>
            ) : null}
          </div>
        </>
      )}
    </Modal>
  );
}
