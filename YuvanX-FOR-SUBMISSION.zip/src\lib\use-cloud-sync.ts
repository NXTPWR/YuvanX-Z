'use client';

import { useEffect, useRef } from 'react';
import { createRemoteMemory, fetchConversations, fetchMemories } from '@/lib/cloud';
import { useAuthStore } from '@/lib/store/auth';
import { useChatStore } from '@/lib/store/chat';
import type { Memory } from '@/lib/types';

/**
 * Keeps the local mirrors in step with the cloud account.
 *
 * The browser store always holds what the UI renders; this hook refreshes it
 * from the server whenever the signed-in identity changes. The cloud copy is
 * authoritative — otherwise a memory deleted on another device would live on
 * here as a ghost.
 */
export function useCloudSync(): void {
  const status = useAuthStore((state) => state.status);
  const userId = useAuthStore((state) => state.user?.id);
  const booted = useRef(false);

  useEffect(() => {
    if (status === 'loading') return;
    if (status !== 'authenticated' || !userId) {
      booted.current = false;
      return;
    }

    booted.current = true;
    let cancelled = false;

    void (async () => {
      try {
        const [conversations, memories] = await Promise.all([
          fetchConversations(),
          fetchMemories(),
        ]);
        if (cancelled) return;

        const store = useChatStore.getState();
        store.setConversations(conversations);
        store.setHydrated(true);

        // Memories added as a guest carry a `mem_…` id. Upload those once, then
        // mirror the cloud list exactly (including deletions made elsewhere).
        const remoteIds = new Set(memories.map((memory) => memory.id));
        const guestMemories = store.memories.filter(
          (memory) => memory.id.startsWith('mem_') && !remoteIds.has(memory.id),
        );

        const uploaded: Memory[] = [];
        const failed: Memory[] = [];
        for (const memory of guestMemories) {
          const created = await createRemoteMemory({
            content: memory.content,
            category: memory.category,
          });
          if (created) uploaded.push(created);
          else failed.push(memory);
        }
        if (cancelled) return;

        useChatStore.getState().setMemories([...memories, ...uploaded, ...failed]);
      } catch {
        // Cloud sync is best-effort — the UI keeps working offline.
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [status, userId]);
}
