'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Download,
  Eraser,
  FileJson,
  Info,
  LogIn,
  LogOut,
  Monitor,
  Moon,
  Palette,
  ShieldCheck,
  Sun,
  Upload,
} from 'lucide-react';
import { useSettingsStore } from '@/lib/store/settings';
import { useAuthStore } from '@/lib/store/auth';
import { useChatStore } from '@/lib/store/chat';
import { useUiStore } from '@/lib/store/ui';
import { ACCENTS, MODELS } from '@/lib/constants';
import { Button } from '@/components/ui/button';
import { Modal } from '@/components/ui/modal';
import { SelectField, Switch } from '@/components/ui/field';
import { useToast } from '@/components/ui/toast';
import { cn, downloadTextFile } from '@/lib/utils';
import type { AccentName, AnimationLevel, FontScale, ThemeMode } from '@/lib/types';

const THEME_OPTIONS: Array<{ value: ThemeMode; label: string; icon: React.ReactNode }> = [
  { value: 'light', label: 'Light', icon: <Sun size={14} /> },
  { value: 'dark', label: 'Dark', icon: <Moon size={14} /> },
  { value: 'system', label: 'System', icon: <Monitor size={14} /> },
];

const FONT_OPTIONS: Array<{ value: FontScale; label: string }> = [
  { value: 'sm', label: 'Compact' },
  { value: 'md', label: 'Default' },
  { value: 'lg', label: 'Large' },
  { value: 'xl', label: 'Extra large' },
];

export default function SettingsPage() {
  const toast = useToast();
  const openAuthDialog = useUiStore((state) => state.openAuth);

  const settings = useSettingsStore();
  const setSetting = useSettingsStore((state) => state.set);
  const resetSettings = useSettingsStore((state) => state.reset);

  const user = useAuthStore((state) => state.user);
  const accountsEnabled = useAuthStore((state) => state.accountsEnabled);
  const signOut = useAuthStore((state) => state.signOut);

  const exportSnapshot = useChatStore((state) => state.exportSnapshot);
  const importSnapshot = useChatStore((state) => state.importSnapshot);
  const resetLocal = useChatStore((state) => state.resetLocal);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  useEffect(() => {
    if (!settings.hydrated) return;
  }, [settings.hydrated]);

  const exportData = useCallback(() => {
    const snapshot = exportSnapshot();
    downloadTextFile(
      `yuvanx-export-${new Date().toISOString().slice(0, 10)}.json`,
      JSON.stringify(snapshot, null, 2),
      'application/json',
    );
    toast.success('Your data has been exported.');
  }, [exportSnapshot, toast]);

  const importData = useCallback(
    async (file: File) => {
      try {
        const text = await file.text();
        const parsed = JSON.parse(text) as {
          version?: number;
          conversations?: unknown[];
          messagesByConversation?: Record<string, unknown[]>;
          memories?: unknown[];
        };
        if (!parsed || typeof parsed !== 'object' || !parsed.conversations) {
          throw new Error('bad shape');
        }
        importSnapshot(parsed as never);
        toast.success('Your data has been imported.');
      } catch {
        toast.error('That file is not a valid YuvanX export.');
      }
    },
    [importSnapshot, toast],
  );

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8 sm:px-6 sm:py-12">
      <header className="animate-fade-up">
        <span className="accent-gradient mb-4 flex h-11 w-11 items-center justify-center rounded-xl text-accent-contrast shadow-soft">
          <Palette size={20} />
        </span>
        <h1 className="font-display text-2xl font-semibold tracking-tight text-ink">Settings</h1>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
          Appearance, behaviour and privacy. Everything here is stored in this browser and can be
          changed at any time.
        </p>
      </header>

      {/* Appearance ------------------------------------------------------- */}
      <Section title="Appearance" description="How YuvanX looks on this device.">
        <div className="py-3">
          <span className="block text-sm font-medium text-ink">Theme</span>
          <div className="mt-2 flex flex-wrap gap-2" role="radiogroup" aria-label="Theme">
            {THEME_OPTIONS.map((option) => (
              <button
                key={option.value}
                type="button"
                role="radio"
                aria-checked={settings.theme === option.value}
                onClick={() => setSetting('theme', option.value)}
                className={cn(
                  'inline-flex h-9 items-center gap-1.5 rounded-[var(--radius-sm)] border px-3 text-[0.8rem] transition-colors',
                  'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
                  settings.theme === option.value
                    ? 'border-accent bg-[rgb(var(--accent)/0.14)] text-accent'
                    : 'border-line text-muted hover:border-line-strong hover:text-ink',
                )}
              >
                {option.icon}
                {option.label}
              </button>
            ))}
          </div>
        </div>

        <div className="py-3">
          <span className="block text-sm font-medium text-ink">Accent colour</span>
          <div className="mt-2 flex flex-wrap gap-2" role="radiogroup" aria-label="Accent colour">
            {ACCENTS.map((accent) => {
              const active = settings.accent === accent.id;
              return (
                <button
                  key={accent.id}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  aria-label={accent.name}
                  title={accent.name}
                  onClick={() => setSetting('accent', accent.id as AccentName)}
                  className={cn(
                    'flex h-9 items-center gap-2 rounded-[var(--radius-sm)] border px-2.5 text-[0.78rem] transition-colors',
                    'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
                    active
                      ? 'border-accent bg-[rgb(var(--accent)/0.12)] text-ink'
                      : 'border-line text-muted hover:border-line-strong hover:text-ink',
                  )}
                >
                  <span
                    aria-hidden="true"
                    className="h-4 w-4 rounded-full"
                    style={{
                      background: `linear-gradient(135deg, rgb(${accent.rgb.join(' ')}), rgb(${accent.rgb.join(' ')} / 0.55))`,
                    }}
                  />
                  {accent.name}
                </button>
              );
            })}
          </div>
        </div>

        <SelectField
          label="Text size"
          description="Applies to the whole interface."
          value={settings.fontScale}
          options={FONT_OPTIONS}
          onChange={(value) => setSetting('fontScale', value)}
        />

        <SelectField
          label="Animation"
          description="How much movement YuvanX uses."
          value={settings.animation}
          options={[
            { value: 'full', label: 'Full' },
            { value: 'reduced', label: 'Reduced' },
            { value: 'off', label: 'Off' },
          ]}
          onChange={(value) => setSetting('animation', value as AnimationLevel)}
        />

        <Switch
          checked={settings.reducedMotion}
          onChange={(value) => setSetting('reducedMotion', value)}
          label="Reduce motion"
          description="Turns off all transitions and background movement. Your system's accessibility setting is always respected."
        />
      </Section>

      {/* Behaviour -------------------------------------------------------- */}
      <Section title="Behaviour" description="Small things that make chatting feel natural.">
        <Switch
          checked={settings.enterToSend}
          onChange={(value) => setSetting('enterToSend', value)}
          label="Enter sends the message"
          description="When off, use Ctrl + Enter (or Cmd + Enter) to send."
        />
        <div className="h-px bg-[rgb(var(--border)/0.1)]" />
        <Switch
          checked={settings.sound}
          onChange={(value) => setSetting('sound', value)}
          label="Play a sound when a reply finishes"
          description="A short, quiet chime. Nothing is played while you type."
        />
        <div className="h-px bg-[rgb(var(--border)/0.1)]" />
        <Switch
          checked={settings.webSearch}
          onChange={(value) => setSetting('webSearch', value)}
          label="Web search by default"
          description="When on, YuvanX searches the web for time-sensitive questions and shows the sources it used."
        />
      </Section>

      {/* Model ------------------------------------------------------------ */}
      <Section title="Model" description="Which model answers your questions.">
        <div className="space-y-2 py-2">
          {MODELS.map((option) => {
            const active = (settings.model || MODELS[0].id) === option.id;
            return (
              <button
                key={option.id}
                type="button"
                onClick={() => setSetting('model', option.id)}
                aria-pressed={active}
                className={cn(
                  'flex w-full items-start gap-3 rounded-[var(--radius-md)] border px-3.5 py-3 text-left transition-colors',
                  'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
                  active
                    ? 'border-accent bg-[rgb(var(--accent)/0.1)]'
                    : 'border-line hover:border-line-strong hover:bg-[rgb(var(--border)/0.04)]',
                )}
              >
                <span
                  aria-hidden="true"
                  className={cn(
                    'mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border',
                    active ? 'border-accent bg-accent' : 'border-line-strong',
                  )}
                >
                  {active ? <span className="h-1.5 w-1.5 rounded-full bg-accent-contrast" /> : null}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-medium text-ink">{option.name}</span>
                    {option.badge ? (
                      <span className="rounded-md bg-[rgb(var(--accent)/0.16)] px-1.5 py-0.5 text-[0.6rem] font-semibold uppercase tracking-wider text-accent">
                        {option.badge}
                      </span>
                    ) : null}
                  </span>
                  <span className="mt-0.5 block text-xs leading-relaxed text-muted">
                    {option.description}
                  </span>
                  <span className="mt-1 block font-mono text-[0.64rem] text-subtle">{option.id}</span>
                </span>
              </button>
            );
          })}
        </div>
      </Section>

      {/* Account ---------------------------------------------------------- */}
      <Section title="Account" description="Sign in to sync conversations, memories and files.">
        {user ? (
          <div className="flex flex-wrap items-center gap-3 py-3">
            <span className="accent-gradient flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold text-accent-contrast">
              {(user.name ?? user.email ?? '?').charAt(0).toUpperCase()}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-medium text-ink">
                {user.name ?? 'Signed in'}
              </span>
              <span className="block truncate text-xs text-muted">{user.email}</span>
            </span>
            <Button variant="outline" onClick={() => void signOut()}>
              <LogOut size={14} />
              Sign out
            </Button>
          </div>
        ) : accountsEnabled ? (
          <div className="py-3">
            <p className="text-sm leading-relaxed text-muted">
              You are using YuvanX as a guest. Chats and memories stay in this browser; sign in to
              keep them in sync and to attach larger files.
            </p>
            <Button variant="primary" className="mt-3" onClick={() => openAuthDialog('sync')}>
              <LogIn size={14} />
              Sign in or create an account
            </Button>
          </div>
        ) : (
          <p className="py-3 text-sm leading-relaxed text-muted">
            This deployment does not have accounts enabled, so everything stays in this browser.
          </p>
        )}
      </Section>

      {/* Data ------------------------------------------------------------- */}
      <Section title="Your data" description="Export it, move it, or wipe it.">
        <div className="flex flex-wrap gap-2 py-3">
          <Button variant="outline" onClick={exportData}>
            <Download size={14} />
            Export everything
          </Button>
          <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
            <Upload size={14} />
            Import a backup
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json,.json"
            className="sr-only"
            aria-label="Import a YuvanX backup"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              if (file) await importData(file);
              event.target.value = '';
            }}
          />
          <Button variant="danger" onClick={() => setConfirmReset(true)}>
            <Eraser size={14} />
            Erase local data
          </Button>
        </div>
        <p className="pb-3 text-xs leading-relaxed text-muted">
          The export contains your conversations, messages and memories as a JSON file. It never
          contains your credentials.
        </p>
      </Section>

      {/* Privacy ---------------------------------------------------------- */}
      <Section title="Privacy & security" description="The short version.">
        <ul className="space-y-3 py-3 text-sm leading-relaxed text-muted">
          <li className="flex gap-2.5">
            <ShieldCheck size={15} className="mt-0.5 shrink-0 text-accent" />
            <span>
              Your AI provider key lives only on the server. It is never sent to your browser and
              never appears in the page bundle.
            </span>
          </li>
          <li className="flex gap-2.5">
            <FileJson size={15} className="mt-0.5 shrink-0 text-accent" />
            <span>
              Files are validated on the server, size-checked and stored privately. Model output is
              rendered as safe Markdown — raw HTML in a reply is never executed.
            </span>
          </li>
          <li className="flex gap-2.5">
            <Info size={15} className="mt-0.5 shrink-0 text-accent" />
            <span>
              Memory is off by default for automatic learning, and anything that looks like a
              password or API key is refused before it is stored.
            </span>
          </li>
        </ul>
        <div className="flex items-center justify-between gap-3 border-t border-line py-3">
          <p className="text-xs text-subtle">Reset every preference to its default.</p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              resetSettings();
              toast.success('Settings reset to their defaults.');
            }}
          >
            Reset settings
          </Button>
        </div>
      </Section>

      <Modal
        open={confirmReset}
        onClose={() => setConfirmReset(false)}
        title="Erase local data?"
        description="This clears the conversations and memories stored in this browser. Cloud conversations are not touched."
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmReset(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                resetLocal();
                setConfirmReset(false);
                toast.success('Local data erased.');
              }}
            >
              <Eraser size={14} />
              Erase
            </Button>
          </>
        }
      >
        <p className="text-sm leading-relaxed text-muted">
          This cannot be undone. Export your data first if you want to keep it.
        </p>
      </Modal>
    </div>
  );
}

function Section({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <section className="glass mt-6 rounded-[var(--radius-lg)] px-4 py-4 sm:px-5">
      <h2 className="font-display text-base font-semibold text-ink">{title}</h2>
      <p className="mt-0.5 text-xs text-muted">{description}</p>
      <div className="mt-1 divide-y divide-[rgb(var(--border)/0.08)]">{children}</div>
    </section>
  );
}
