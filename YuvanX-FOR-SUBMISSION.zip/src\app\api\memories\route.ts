import { NextResponse } from 'next/server';
import { resolveIdentity } from '@/lib/server/supabase';
import { clearMemories, createMemory, listMemories } from '@/lib/server/db';
import { containsSensitiveData, sanitizeMemoryContent, SENSITIVE_MEMORY_MESSAGE } from '@/lib/memory';
import type { MemoryCategory } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const VALID_CATEGORIES: MemoryCategory[] = ['preference', 'project', 'instruction', 'fact', 'note'];

export async function GET(request: Request) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json({ error: 'Not signed in.', code: 'unauthenticated' }, { status: 401 });
  }
  try {
    const memories = await listMemories(identity.userId);
    return NextResponse.json({ memories });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not load memories.' },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json({ error: 'Not signed in.', code: 'unauthenticated' }, { status: 401 });
  }
  const body = (await request.json().catch(() => ({}))) as {
    content?: string;
    category?: MemoryCategory;
  };
  const content = sanitizeMemoryContent(body.content ?? '');
  if (!content) {
    return NextResponse.json({ error: 'A memory needs some content.' }, { status: 400 });
  }
  if (containsSensitiveData(content)) {
    return NextResponse.json(
      { error: SENSITIVE_MEMORY_MESSAGE, code: 'sensitive' },
      { status: 400 },
    );
  }
  try {
    const memory = await createMemory(identity.userId, {
      content,
      category: VALID_CATEGORIES.includes(body.category as MemoryCategory)
        ? (body.category as MemoryCategory)
        : 'note',
      source: 'manual',
    });
    return NextResponse.json({ memory });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not save the memory.' },
      { status: 500 },
    );
  }
}

/** Clear every stored memory for the signed-in user. */
export async function DELETE(request: Request) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json({ error: 'Not signed in.', code: 'unauthenticated' }, { status: 401 });
  }
  try {
    await clearMemories(identity.userId);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not clear memories.' },
      { status: 500 },
    );
  }
}
