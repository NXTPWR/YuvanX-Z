import { NextResponse } from 'next/server';
import { getSupabaseConfig } from '@/lib/server/env';
import { resolveIdentity } from '@/lib/server/supabase';
import { checkRateLimit } from '@/lib/server/rate-limit';
import {
  detectKind,
  extractText,
  isDangerousFile,
  kindLabel,
} from '@/lib/server/attachments/parse';
import { storeBytes } from '@/lib/server/attachments/storage';
import { createAttachmentRecord } from '@/lib/server/db';
import { MAX_ATTACHMENTS, MAX_FILE_BYTES } from '@/lib/constants';
import type { AttachmentMeta } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const GUEST_MAX_BYTES = 2.5 * 1024 * 1024;

export async function POST(request: Request) {
  const identity = await resolveIdentity(request);

  const limit = checkRateLimit(`upload:${identity.userId ?? identity.clientId}`, 40, 10 * 60_000);
  if (!limit.allowed) {
    return NextResponse.json(
      { error: 'Too many uploads in a short time. Please wait a moment and try again.' },
      { status: 429 },
    );
  }

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: 'The upload could not be read.' }, { status: 400 });
  }

  const file = form.get('file');
  if (!(file instanceof File)) {
    return NextResponse.json({ error: 'No file was provided.' }, { status: 400 });
  }

  const name = (file.name || 'file').slice(0, 200);
  const mimeType = (file.type || 'application/octet-stream').slice(0, 120);
  const size = file.size;

  if (size === 0) {
    return NextResponse.json({ error: `"${name}" is empty.` }, { status: 400 });
  }

  if (isDangerousFile(name, mimeType)) {
    return NextResponse.json(
      { error: `"${name}" is not an allowed file type.` },
      { status: 415 },
    );
  }

  const kind = detectKind(name, mimeType);
  if (kind === 'unknown') {
    return NextResponse.json(
      {
        error: `YuvanX cannot analyse ${name.split('.').pop()?.toUpperCase() ?? 'this'} files. Supported formats: PDF, TXT, MD, DOCX, CSV, XLSX, PNG, JPG, WEBP and source code.`,
      },
      { status: 415 },
    );
  }

  const supabase = getSupabaseConfig();
  const canPersist = Boolean(identity.userId && supabase?.serviceRoleKey);
  const maxBytes = canPersist ? MAX_FILE_BYTES : GUEST_MAX_BYTES;

  if (size > maxBytes) {
    return NextResponse.json(
      {
        error: canPersist
          ? `"${name}" is larger than the ${(MAX_FILE_BYTES / (1024 * 1024)).toFixed(0)} MB limit.`
          : `"${name}" is larger than the ${(GUEST_MAX_BYTES / (1024 * 1024)).toFixed(1)} MB limit for signed-out use. Create a free account to upload files up to ${(MAX_FILE_BYTES / (1024 * 1024)).toFixed(0)} MB.`,
      },
      { status: 413 },
    );
  }

  const bytes = new Uint8Array(await file.arrayBuffer());

  let storageKey: string | undefined;
  if (canPersist && identity.userId) {
    try {
      storageKey =
        (await storeBytes(identity.userId, bytes, name, mimeType, null)) ?? undefined;
    } catch {
      return NextResponse.json(
        { error: 'The file could not be stored securely. Please try again.' },
        { status: 500 },
      );
    }
  }

  let extraction;
  try {
    extraction = await extractText(bytes, kind, name);
  } catch {
    extraction = { analyzable: false, note: 'The file could not be read.' };
  }

  const base: AttachmentMeta = {
    id: crypto.randomUUID(),
    name,
    mimeType,
    size,
    kind,
    analyzable: extraction.analyzable,
    note: extraction.note,
    storageKey,
  };

  // Authenticated users get a durable record; the chat request references the
  // id and the server resolves the bytes itself (the client never sends keys).
  if (canPersist && identity.userId) {
    try {
      const record = await createAttachmentRecord(identity.userId, {
        ...base,
        text: extraction.text,
        conversationId: null,
      });
      return NextResponse.json({ attachment: { ...record, persisted: true } });
    } catch {
      return NextResponse.json(
        { error: 'The file could not be registered. Please try again.' },
        { status: 500 },
      );
    }
  }

  // Guest mode: the content travels back with the message so no server-side
  // storage is required. Images are returned inline for the model to analyse.
  let dataUrl: string | undefined;
  if (kind === 'image') {
    dataUrl = `data:${mimeType};base64,${Buffer.from(bytes).toString('base64')}`;
  } else if (kind === 'pdf') {
    dataUrl = `data:${mimeType};base64,${Buffer.from(bytes).toString('base64')}`;
  }

  return NextResponse.json({
    attachment: {
      ...base,
      text: extraction.text,
      dataUrl,
      persisted: false,
      kindLabel: kindLabel(kind),
    },
  });
}

export async function GET() {
  return NextResponse.json({
    maxFiles: MAX_ATTACHMENTS,
    maxBytes: MAX_FILE_BYTES,
    formats: [
      'pdf', 'txt', 'md', 'docx', 'csv', 'xlsx',
      'png', 'jpg', 'jpeg', 'webp',
      'js', 'jsx', 'ts', 'tsx', 'py', 'java', 'go', 'rs', 'html', 'css', 'json', 'yaml', 'yml', 'xml', 'sql', 'sh',
    ],
  });
}
