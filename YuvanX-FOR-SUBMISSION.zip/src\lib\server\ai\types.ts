import type { AttachmentKind, Source } from '@/lib/types';

/** A file that has been resolved to actual bytes (or extracted text) server-side. */
export interface ResolvedAttachment {
  name: string;
  mimeType: string;
  kind: AttachmentKind;
  /** Raw bytes for binary formats (images, PDF). */
  bytes?: Uint8Array;
  /** Plain-text extraction for documents the server can parse. */
  text?: string;
}

export interface ChatTurn {
  role: 'user' | 'assistant';
  content: string;
  attachments?: ResolvedAttachment[];
}

export interface ProviderRequest {
  model: string;
  system: string;
  turns: ChatTurn[];
  webSearch: boolean;
  maxOutputTokens: number;
  thinkingLevel: 'low' | 'medium' | 'high';
  timeoutMs: number;
  /** Whether the provider may retain the interaction for later retrieval. */
  store: boolean;
  signal: AbortSignal;
}

export interface ProviderCallbacks {
  onText(delta: string): void;
  onSearch?(queries: string[]): void;
}

export interface TokenUsage {
  inputTokens?: number;
  outputTokens?: number;
  thoughtTokens?: number;
  totalTokens?: number;
}

export interface ProviderResult {
  text: string;
  sources: Source[];
  model: string;
  usage?: TokenUsage;
  searchQueries: string[];
}

export type ProviderErrorCode =
  | 'auth'
  | 'rate_limit'
  /** The daily allowance for the model is spent — it resets later today. */
  | 'quota_exceeded'
  | 'unavailable'
  /** The provider is at capacity for this model — retrying it now is wasted time. */
  | 'overloaded'
  | 'invalid_request'
  | 'model_not_found'
  | 'timeout'
  | 'aborted'
  | 'unknown';

/** Normalised error type thrown by every provider implementation. */
export class AIProviderError extends Error {
  readonly code: ProviderErrorCode;
  readonly retryable: boolean;
  readonly status?: number;

  constructor(code: ProviderErrorCode, message: string, retryable = false, status?: number) {
    super(message);
    this.name = 'AIProviderError';
    this.code = code;
    this.retryable = retryable;
    this.status = status;
  }
}

export interface AIProvider {
  readonly id: string;
  readonly label: string;
  readonly supportsAttachments: boolean;
  readonly supportsSearch: boolean;
  stream(request: ProviderRequest, callbacks: ProviderCallbacks): Promise<ProviderResult>;
}

export function isAbortError(error: unknown): boolean {
  if (error instanceof AIProviderError) return error.code === 'aborted';
  if (error instanceof Error) {
    return error.name === 'AbortError' || /abort/i.test(error.message);
  }
  return false;
}
