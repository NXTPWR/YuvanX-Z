'use client';

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { Brain, Menu, PanelLeftClose, PanelLeftOpen, Sparkles } from 'lucide-react';
import { Sidebar } from '@/components/sidebar';
import { AuthDialog } from '@/components/auth-dialog';
import { LogoMark } from '@/components/logo';
import { Button, IconButton } from '@/components/ui/button';
import { useAuthStore } from '@/lib/store/auth';
import { useChatStore } from '@/lib/store/chat';
import { useSettingsStore } from '@/lib/store/settings';
import { useUiStore } from '@/lib/store/ui';
import { useCloudSync } from '@/lib/use-cloud-sync';
import { useLocalStorageBoolean } from '@/lib/use-local-storage';
import { MODELS, modelLabel, modelRealName } from '@/lib/constants';
import { cn } from '@/lib/utils';

const COLLAPSE_KEY = 'yuvanx.sidebar.collapsed';

export function AppShell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [collapsed, setCollapsed] = useLocalStorageBoolean(COLLAPSE_KEY);

  const user = useAuthStore((state) => state.user);
  const accountsEnabled = useAuthStore((state) => state.accountsEnabled);
  const conversations = useChatStore((state) => state.conversations);
  const setActive = useChatStore((state) => state.setActive);

  const authOpen = useUiStore((state) => state.authOpen);
  const authReason = useUiStore((state) => state.authReason);
  const openAuth = useUiStore((state) => state.openAuth);
  const closeAuth = useUiStore((state) => state.closeAuth);

  const model = useSettingsStore((state) => state.model);
  const setSetting = useSettingsStore((state) => state.set);
  const memoryEnabled = useSettingsStore((state) => state.memoryEnabled);

  useCloudSync();

  const toggleCollapsed = useCallback(() => {
    setCollapsed(!collapsed);
  }, [collapsed, setCollapsed]);

  /* Derive the active conversation from the URL. */
  const conversationId = (() => {
    if (!pathname) return null;
    const match = /^\/chat\/(.+)$/.exec(pathname);
    return match ? match[1] : null;
  })();

  // The chat view owns its own scrolling (the transcript scrolls, the composer
  // and header stay put). Every other screen is a normal document page.
  const isChatView = Boolean(pathname && pathname.startsWith('/chat'));

  useEffect(() => {
    setActive(conversationId);
  }, [conversationId, setActive]);

  const conversation = conversationId
    ? conversations.find((item) => item.id === conversationId)
    : undefined;

  const openAuthWithReason = useCallback(
    (reason: 'sync' | 'files' | 'account' = 'sync') => {
      openAuth(reason);
    },
    [openAuth],
  );

  const handleNewChat = useCallback(() => {
    router.push('/chat');
    setDrawerOpen(false);
  }, [router]);

  return (
    <div className="flex h-dvh w-full overflow-hidden">
      <Sidebar
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        collapsed={collapsed}
        onToggleCollapsed={toggleCollapsed}
        activeId={conversationId}
        onSelect={(id) => router.push(`/chat/${id}`)}
        onNewChat={handleNewChat}
        onRequestAuth={openAuthWithReason}
      />

      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        <header className="glass sticky top-0 z-40 flex h-14 shrink-0 items-center gap-2 border-b border-line px-3 sm:px-4">
          <IconButton
            label="Open sidebar"
            onClick={() => setDrawerOpen(true)}
            className="lg:hidden"
            size="icon"
          >
            <Menu size={17} />
          </IconButton>

          <IconButton
            label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            onClick={toggleCollapsed}
            className="max-lg:hidden"
            size="icon"
          >
            {collapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}
          </IconButton>

          <div className="mx-1 lg:hidden">
            <LogoMark size={24} />
          </div>

          <div className="min-w-0 flex-1">
            <h1 className="truncate font-display text-sm font-semibold text-ink">
              {conversation?.title ?? 'YuvanX'}
            </h1>
          </div>

          {memoryEnabled ? (
            <span
              className="hidden items-center gap-1.5 rounded-full border border-line px-2.5 py-1 text-[0.68rem] text-muted sm:inline-flex"
              title="Persistent memory is on"
            >
              <Brain size={12} className="text-accent" />
              Memory on
            </span>
          ) : null}

          <label className="hidden items-center gap-1.5 sm:flex">
            <span className="sr-only">Model</span>
            <select
              value={model || MODELS[0].id}
              onChange={(event) => setSetting('model', event.target.value)}
              title={
                modelRealName(model || MODELS[0].id)
                  ? `Model: ${modelRealName(model || MODELS[0].id)}`
                  : 'Choose a model'
              }
              className="h-8 max-w-[13rem] cursor-pointer rounded-[var(--radius-sm)] border border-line bg-[rgb(var(--panel)/0.6)] px-2 text-xs text-ink focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25"
            >
              {MODELS.map((option) => (
                <option key={option.id} value={option.id} className="bg-panel-solid text-ink">
                  {modelLabel(option.id)} — {option.id}
                </option>
              ))}
            </select>
          </label>

          {!user && accountsEnabled ? (
            <Button size="sm" variant="primary" onClick={() => openAuthWithReason('sync')}>
              <Sparkles size={13} />
              Sign in
            </Button>
          ) : null}
        </header>

        <main
          className={cn(
            'flex min-h-0 flex-1 flex-col',
            isChatView ? 'overflow-hidden' : 'overflow-y-auto',
          )}
        >
          {children}
        </main>
      </div>

      {authOpen ? (
        <AuthDialog open onClose={closeAuth} reason={authReason} />
      ) : null}
    </div>
  );
}
