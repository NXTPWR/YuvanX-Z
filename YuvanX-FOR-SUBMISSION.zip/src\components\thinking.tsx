'use client';

import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface ThinkingProps {
  /** Web-search queries the model issued, when it is searching. */
  queries?: string[];
  /** True once the model has produced its first token. */
  active?: boolean;
  className?: string;
}

/** The "YuvanX is thinking" indicator shown while a response is streaming. */
export function Thinking({ queries = [], active = true, className }: ThinkingProps) {
  const [seconds, setSeconds] = useState(0);

  // A model can take a while to send its first token on a busy free tier.
  // Showing the elapsed time makes a slow answer feel alive instead of stuck.
  // The parent remounts this component at the start of every stream, so the
  // counter always begins at zero without resetting state inside the effect.
  useEffect(() => {
    if (!active) return;
    const startedAt = Date.now();
    const timer = window.setInterval(() => {
      setSeconds(Math.floor((Date.now() - startedAt) / 1000));
    }, 500);
    return () => window.clearInterval(timer);
  }, [active]);

  if (!active) return null;

  const label =
    seconds >= 20
      ? `Still working on it… ${seconds}s`
      : seconds >= 6
        ? `Thinking… ${seconds}s`
        : 'Thinking…';

  return (
    <div className={cn('flex items-center gap-2.5 text-sm text-muted', className)} role="status">
      <span className="flex items-center gap-1" aria-hidden="true">
        {[0, 1, 2].map((index) => (
          <span
            key={index}
            className="h-1.5 w-1.5 rounded-full bg-accent"
            style={{
              animation: 'yx-pulse-dot 1.15s ease-in-out infinite',
              animationDelay: `${index * 0.16}s`,
            }}
          />
        ))}
      </span>

      {queries.length > 0 ? (
        <span className="inline-flex min-w-0 items-center gap-1.5 text-xs">
          <Search size={12} className="shrink-0 text-accent" />
          <span className="truncate italic">{queries.join(' · ')}</span>
        </span>
      ) : (
        <span className="text-xs">{label}</span>
      )}
    </div>
  );
}
