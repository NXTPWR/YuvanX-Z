'use client';

/**
 * A very small, quiet completion chime built with the Web Audio API.
 *
 * No audio files are shipped, and nothing plays until the user asks for it in
 * Settings. Browsers block audio until the page has been interacted with, so
 * every failure is swallowed silently.
 */
export function playCompletionChime(): void {
  if (typeof window === 'undefined') return;
  try {
    const AudioCtor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtor) return;

    const context = new AudioCtor();
    const now = context.currentTime;

    const gain = context.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.06, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.42);
    gain.connect(context.destination);

    const frequencies = [784, 1174.66]; // G5, D6
    frequencies.forEach((frequency, index) => {
      const oscillator = context.createOscillator();
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(frequency, now + index * 0.09);
      oscillator.connect(gain);
      oscillator.start(now + index * 0.09);
      oscillator.stop(now + 0.45);
    });

    window.setTimeout(() => {
      void context.close();
    }, 900);
  } catch {
    // Audio is a nicety — never let it break the chat.
  }
}
