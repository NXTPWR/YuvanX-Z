import { NextResponse } from 'next/server';
import { complete, generateText } from '@/lib/server/ai';
import { AIProviderError, type ChatTurn, type ResolvedAttachment } from '@/lib/server/ai/types';
import {
  buildSystemInstruction,
  fallbackTitle,
  MEMORY_EXTRACTION_PROMPT,
  TITLE_SYSTEM_PROMPT,
} from '@/lib/server/ai/prompt';
import {
  mentionsPersonalFact,
  parseExtractedMemories,
  sanitizeMemoryContent,
  selectRelevantMemories,
} from '@/lib/server/ai/memory';
import { resolveIdentity } from '@/lib/server/supabase';
import { checkRateLimit } from '@/lib/server/rate-limit';
import { getServerConfig } from '@/lib/server/env';
import {
  addMessage,
  createConversation,
  createMemory,
  deleteMessagesById,
  getConversation,
  getAttachmentRecord,
  getDailyUsage,
  incrementDailyUsage,
  listMemories,
  updateConversation,
} from '@/lib/server/db';
import { loadBytes } from '@/lib/server/attachments/storage';
import { getServiceClient } from '@/lib/server/supabase';
import { DEFAULT_MODEL, MAX_ATTACHMENTS, MAX_MESSAGE_CHARS } from '@/lib/constants';
import type { AttachmentKind, ChatStreamEvent, Memory, Message, Source } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 300;

interface ClientAttachmentInput {
  id?: string;
  name: string;
  mimeType: string;
  size: number;
  kind: AttachmentKind;
  analyzable?: boolean;
  note?: string;
  text?: string;
  dataUrl?: string;
}

interface HistoryTurn {
  role: 'user' | 'assistant';
  content: string;
  attachments?: ClientAttachmentInput[];
}

interface ChatRequestBody {
  conversationId?: string | null;
  message?: string;
  attachments?: ClientAttachmentInput[];
  history?: HistoryTurn[];
  model?: string;
  webSearch?: boolean;
  memories?: Memory[];
  memoryEnabled?: boolean;
  autoMemory?: boolean;
  replaceMessageIds?: string[];
  persistUserMessage?: boolean;
  userMessageId?: string;
}

const MAX_INLINE_BYTES = 3 * 1024 * 1024;

/**
 * Message ids are opaque strings the client may choose for its own user
 * message. Only a conservative character set is accepted so a crafted id can
 * never reach the database verbatim. Rows are always scoped to the
 * authenticated user, so a caller can only ever address their own messages.
 */
const MESSAGE_ID_PATTERN = /^[A-Za-z0-9_-]{8,64}$/;

function sanitizeMessageId(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  return MESSAGE_ID_PATTERN.test(trimmed) ? trimmed : null;
}

/**
 * Cloud conversations are addressed by their database uuid. A guest thread
 * only ever has a browser-local id, so anything that is not a uuid must never
 * reach Postgres — it would raise an "invalid input syntax for type uuid"
 * error instead of a friendly answer.
 */
const CONVERSATION_ID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isCloudConversationId(value: string): boolean {
  return CONVERSATION_ID_PATTERN.test(value);
}

function decodeDataUrl(dataUrl: string): { bytes: Uint8Array; mimeType: string } | null {
  const match = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(dataUrl);
  if (!match) return null;
  const mimeType = match[1] || 'application/octet-stream';
  const isBase64 = Boolean(match[2]);
  try {
    if (isBase64) {
      return { bytes: new Uint8Array(Buffer.from(match[3], 'base64')), mimeType };
    }
    return { bytes: new TextEncoder().encode(decodeURIComponent(match[3])), mimeType };
  } catch {
    return null;
  }
}

/** Turn a client attachment into content the model can actually read. */
async function resolveAttachment(
  attachment: ClientAttachmentInput,
  userId: string | null,
): Promise<ResolvedAttachment> {
  const resolved: ResolvedAttachment = {
    name: attachment.name,
    mimeType: attachment.mimeType,
    kind: attachment.kind,
  };

  // Authenticated uploads are stored server-side; resolve them from the
  // database so the client never has to hand us storage keys.
  if (attachment.id && userId) {
    const record = await getAttachmentRecord(userId, attachment.id);
    if (record) {
      resolved.text = record.text;
      if (record.storageKey) {
        const bytes = await loadBytes(userId, record.storageKey);
        if (bytes) resolved.bytes = bytes;
      }
      return resolved;
    }
  }

  if (attachment.dataUrl) {
    const decoded = decodeDataUrl(attachment.dataUrl);
    if (decoded) {
      resolved.bytes = decoded.bytes;
      resolved.mimeType = decoded.mimeType || attachment.mimeType;
      return resolved;
    }
  }

  resolved.text = attachment.text;
  return resolved;
}

function toSse(event: ChatStreamEvent): string {
  return `data: ${JSON.stringify(event)}\n\n`;
}

function errorPayload(error: AIProviderError): {
  message: string;
  code: string;
  retryable: boolean;
} {
  switch (error.code) {
    case 'auth':
      return {
        message: error.message,
        code: 'provider_auth',
        retryable: false,
      };
    case 'rate_limit':
      return {
        // The provider layer has a precise, honest message ("Gemini is asking
        // us to slow down… try again in about 45 seconds"). Keep it.
        message: /\./.test(error.message) && error.message.length > 40
          ? error.message
          : 'The AI provider is limiting requests right now. Please wait a moment and try again.',
        code: 'rate_limit',
        retryable: true,
      };
    case 'quota_exceeded':
      return {
        // The provider layer can compute the exact reset time ("unlocks in
        // about 15 hours") or explain that a feature is not on the free tier —
        // keep the specific wording instead of a generic message.
        message: /unlocks in about .+?\./i.test(error.message) ||
          /free-tier allowance|not included in the free tier/i.test(error.message)
          ? error.message
          : 'This Gemini API key has used up its free-tier daily allowance. The quota resets later today — switch to a paid API key for unlimited use.',
        code: 'quota_exceeded',
        retryable: true,
      };
    case 'timeout':
      return {
        message:
          'That took longer than expected and the request timed out. Your message was kept — please try again.',
        code: 'timeout',
        retryable: true,
      };
    case 'model_not_found':
      return {
        message: 'The selected model is unavailable right now. Try another model in Settings.',
        code: 'model_unavailable',
        retryable: true,
      };
    case 'invalid_request':
      return {
        message: error.message || 'The request could not be processed.',
        code: 'invalid_request',
        retryable: false,
      };
    case 'aborted':
      return { message: 'Generation stopped.', code: 'aborted', retryable: true };
    case 'overloaded':
      return {
        message:
          'Every Gemini model is busy right now — Google\u2019s free tier throttles under load. Your message was kept; try again in a moment, or Retry below.',
        code: 'service_unavailable',
        retryable: true,
      };
    default:
      return {
        message:
          'YuvanX could not reach the AI service just now. Your message was kept — please retry.',
        code: 'service_unavailable',
        retryable: true,
      };
  }
}

export async function POST(request: Request) {
  const config = getServerConfig();

  if (!config.gemini) {
    return NextResponse.json(
      {
        error:
          'GEMINI_API_KEY is not configured on the server. Add it to your environment and restart the app.',
        code: 'provider_missing',
      },
      { status: 503 },
    );
  }

  let body: ChatRequestBody;
  try {
    body = (await request.json()) as ChatRequestBody;
  } catch {
    return NextResponse.json({ error: 'Malformed request.' }, { status: 400 });
  }

  const identity = await resolveIdentity(request);

  // --- Rate limiting -------------------------------------------------------
  const limitKey = identity.userId ? `user:${identity.userId}` : `guest:${identity.clientId}`;
  const rate = checkRateLimit(limitKey, config.requestsPerMinute, 60_000);
  if (!rate.allowed) {
    return NextResponse.json(
      {
        error: 'You are sending requests very quickly. Please wait a moment and try again.',
        code: 'rate_limit',
        retryable: true,
      },
      { status: 429, headers: { 'Retry-After': String(Math.ceil(rate.retryAfterMs / 1000)) } },
    );
  }

  if (identity.userId && config.dailyRequestLimit > 0) {
    try {
      const usage = await getDailyUsage(identity.userId);
      if (usage.requests >= config.dailyRequestLimit) {
        return NextResponse.json(
          {
            error:
              'YuvanX has reached the usage limit for today. Please try again tomorrow.',
            code: 'daily_limit',
            retryable: true,
          },
          { status: 429 },
        );
      }
    } catch {
      // Usage accounting must never block a request.
    }
  }

  // --- Validate the request ------------------------------------------------
  const rawMessage = typeof body.message === 'string' ? body.message : '';
  const message = rawMessage.trim();
  const attachments = Array.isArray(body.attachments) ? body.attachments.slice(0, MAX_ATTACHMENTS) : [];

  if (!message && attachments.length === 0) {
    return NextResponse.json({ error: 'Nothing to send.' }, { status: 400 });
  }
  if (message.length > MAX_MESSAGE_CHARS) {
    return NextResponse.json(
      { error: `Your message is too long (limit ${MAX_MESSAGE_CHARS.toLocaleString()} characters).` },
      { status: 413 },
    );
  }

  const inlineBytes = attachments.reduce((total, attachment) => {
    if (!attachment.dataUrl) return total;
    return total + Math.ceil((attachment.dataUrl.length * 3) / 4);
  }, 0);
  if (inlineBytes > MAX_INLINE_BYTES) {
    return NextResponse.json(
      {
        error:
          'The attached files are too large to send together. Remove one, or create a free account for larger uploads.',
        code: 'payload_too_large',
        retryable: false,
      },
      { status: 413 },
    );
  }

  const history: HistoryTurn[] = Array.isArray(body.history) ? body.history : [];
  const requestedModel =
    typeof body.model === 'string' && body.model.trim() ? body.model.trim() : DEFAULT_MODEL;

  // --- Memories ------------------------------------------------------------
  const memoryEnabled = body.memoryEnabled !== false;
  let memories: Memory[] = [];
  if (memoryEnabled) {
    if (identity.userId) {
      try {
        memories = await listMemories(identity.userId);
      } catch {
        memories = [];
      }
    } else if (Array.isArray(body.memories)) {
      memories = body.memories;
    }
  }
  const relevantMemories = memoryEnabled
    ? selectRelevantMemories(memories, message || attachments.map((a) => a.name).join(' '))
    : [];

  // --- Conversation --------------------------------------------------------
  let conversationId = body.conversationId ?? null;
  const client = getServiceClient();
  // True when a browser-only thread was promoted to the cloud because the
  // user signed in while the conversation was still open.
  let promotedFromGuest = false;

  if (identity.userId) {
    if (conversationId && !isCloudConversationId(conversationId)) {
      // The browser still holds a guest conversation id. Promote the thread
      // to a real cloud conversation instead of failing on the id, and tell
      // the client which conversation to follow from now on.
      const created = await createConversation(identity.userId, {
        title: 'New chat',
        model: requestedModel,
      });
      conversationId = created.id;
      promotedFromGuest = true;
    } else if (conversationId) {
      const existing = await getConversation(identity.userId, conversationId);
      if (!existing) {
        return NextResponse.json(
          { error: 'That conversation could not be found.', code: 'not_found' },
          { status: 404 },
        );
      }
    } else {
      const created = await createConversation(identity.userId, { title: 'New chat', model: requestedModel });
      conversationId = created.id;
    }
  }

  // --- Build the model turns ----------------------------------------------
  const turns: ChatTurn[] = [];
  for (const turn of history) {
    if (turn.role !== 'user' && turn.role !== 'assistant') continue;
    if (!turn.content) continue;
    const resolved: ResolvedAttachment[] = [];
    for (const attachment of (turn.attachments ?? []).slice(0, MAX_ATTACHMENTS)) {
      const item = await resolveAttachment(attachment, identity.userId);
      if (item.bytes || item.text) resolved.push(item);
    }
    turns.push({ role: turn.role, content: turn.content, attachments: resolved });
  }

  const currentAttachments: ResolvedAttachment[] = [];
  for (const attachment of attachments) {
    const item = await resolveAttachment(attachment, identity.userId);
    currentAttachments.push(item);
  }

  turns.push({
    role: 'user',
    content: message,
    attachments: currentAttachments,
  });

  const system = buildSystemInstruction({
    memories: relevantMemories,
    webSearch: Boolean(body.webSearch),
    userProfile: { name: identity.name },
  });

  const userMessageId = sanitizeMessageId(body.userMessageId) ?? crypto.randomUUID();
  const assistantMessageId = crypto.randomUUID();
  const createdAt = Date.now();

  // Request metadata only — never the message content — so a stray or
  // duplicated request is visible in the logs without leaking what was said.
  console.warn(
    `[yuvanx] chat ${userMessageId} chars=${message.length} history=${history.length} ` +
      `persist=${body.persistUserMessage !== false} replace=${
        Array.isArray(body.replaceMessageIds) ? body.replaceMessageIds.length : 0
      }`,
  );

  const abortController = new AbortController();
  request.signal.addEventListener('abort', () => abortController.abort(), { once: true });

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const encoder = new TextEncoder();
      const send = (event: ChatStreamEvent) => {
        try {
          controller.enqueue(encoder.encode(toSse(event)));
        } catch {
          /* the client disconnected */
        }
      };

      let assistantText = '';
      let sources: Source[] = [];
      let modelUsed = requestedModel;
      let failed = false;
      let stopped = false;

      try {
        send({ type: 'start', messageId: assistantMessageId, model: modelUsed });
        if (promotedFromGuest && conversationId) {
          // The thread now lives in the cloud under a different id.
          send({ type: 'conversation', conversationId });
        }

        const result = await complete({
          model: requestedModel,
          system,
          turns,
          webSearch: Boolean(body.webSearch),
          signal: abortController.signal,
          onText: (delta) => {
            assistantText += delta;
            send({ type: 'delta', text: delta });
          },
          // A failed attempt may already have streamed part of an answer.
          // Drop it so the user only ever sees one clean response.
          onReset: () => {
            assistantText = '';
            send({ type: 'reset' });
          },
          onSearch: (queries) => {
            send({ type: 'search', queries });
          },
        });

        sources = result.sources ?? [];
        modelUsed = result.model ?? requestedModel;

        if (sources.length) send({ type: 'sources', sources });

        // The answer is complete. Announce it right away so the composer
        // unlocks immediately — bookkeeping (usage accounting, persistence,
        // titling, memory extraction) continues in the background of the same
        // stream and must never keep the user waiting.
        if (!failed) {
          send({ type: 'done', message: buildAssistantMessage() });
        }

        // Private usage accounting — never surfaced to the customer.
        if (identity.userId) {
          try {
            await incrementDailyUsage(identity.userId, {
              inputTokens: result.usage?.inputTokens ?? 0,
              outputTokens: result.usage?.outputTokens ?? 0,
            });
          } catch {
            /* accounting must never break a response */
          }
        }
      } catch (error) {
        failed = true;
        const providerError =
          error instanceof AIProviderError
            ? error
            : new AIProviderError(
                'unknown',
                error instanceof Error ? error.message : 'Unknown error.',
                false,
              );
        stopped = providerError.code === 'aborted';
        const payload = errorPayload(providerError);
        send({ ...payload, type: 'error' } as ChatStreamEvent);
      }

      // --- Persist ---------------------------------------------------------
      if (identity.userId && conversationId && client) {
        try {
          if (promotedFromGuest) {
            // Carry the guest thread over into the cloud conversation so a
            // sign-in in the middle of a conversation never loses history.
            const historyStart = createdAt - (history.length + 1) * 1000;
            for (const [index, turn] of history.entries()) {
              if (turn.role !== 'user' && turn.role !== 'assistant') continue;
              if (!turn.content) continue;
              await addMessage(identity.userId, conversationId, {
                id: crypto.randomUUID(),
                role: turn.role,
                content: turn.content,
                attachments: (turn.attachments ?? []).map((attachment) => ({
                  id: attachment.id ?? crypto.randomUUID(),
                  name: attachment.name,
                  mimeType: attachment.mimeType,
                  size: attachment.size,
                  kind: attachment.kind,
                  analyzable: attachment.analyzable ?? false,
                  note: attachment.note,
                  text: attachment.text,
                })),
                sources: [],
                status: 'complete',
                createdAt: historyStart + index * 1000,
              });
            }
          }
          if (Array.isArray(body.replaceMessageIds) && body.replaceMessageIds.length) {
            await deleteMessagesById(identity.userId, body.replaceMessageIds);
          }
          if (body.persistUserMessage !== false && message) {
            await addMessage(identity.userId, conversationId, {
              id: userMessageId,
              role: 'user',
              content: message,
              attachments: attachments.map((attachment) => ({
                id: attachment.id ?? crypto.randomUUID(),
                name: attachment.name,
                mimeType: attachment.mimeType,
                size: attachment.size,
                kind: attachment.kind,
                analyzable: attachment.analyzable ?? false,
                note: attachment.note,
                storageKey: undefined,
                text: attachment.text,
              })),
              sources: [],
              status: 'complete',
              createdAt,
            });
          }
          // A stopped generation still keeps whatever was produced, so the
          // partial answer survives a page reload.
          if (assistantText && (!failed || stopped)) {
            await addMessage(identity.userId, conversationId, {
              id: assistantMessageId,
              role: 'assistant',
              content: assistantText,
              attachments: [],
              sources,
              status: stopped ? 'stopped' : 'complete',
              model: modelUsed,
              createdAt: Date.now(),
            });
          }
        } catch (error) {
          console.error('[yuvanx] failed to persist the exchange:', error);
        }
      }

      // --- Title ------------------------------------------------------------
      // The answer was already announced above, so the composer is free. The
      // title and the memory extraction continue in the background of the same
      // stream and must never keep the user waiting.
      if (!failed && message && conversationId) {
        try {
          const title = await generateTitle({
            model: modelUsed,
            message,
            conversationId,
            userId: identity.userId,
          });
          if (title) send({ type: 'title', title });
        } catch {
          /* titles are cosmetic — never fail the response for one */
        }
      }

      // --- Memory extraction -------------------------------------------------
      // Only worth a provider request when the message is actually about the
      // user — the extraction call is not free and provider quotas are small.
      let extractedMemories: Memory[] = [];
      if (
        !failed &&
        memoryEnabled &&
        body.autoMemory &&
        message &&
        mentionsPersonalFact(message)
      ) {
        try {
          extractedMemories = await extractMemories({
            model: modelUsed,
            message,
            signal: abortController.signal,
            userId: identity.userId,
            existing: memories,
          });
        } catch {
          /* memory extraction is best-effort */
        }
      }

      if (extractedMemories.length) {
        send({ type: 'memory', memories: extractedMemories });
      }

      function buildAssistantMessage(): Message {
        return {
          id: assistantMessageId,
          conversationId: conversationId ?? 'local',
          role: 'assistant',
          content: assistantText,
          attachments: [],
          sources,
          status: failed ? 'error' : 'complete',
          createdAt: Date.now(),
          model: modelUsed,
        };
      }

      try {
        controller.close();
      } catch {
        /* already closed */
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  });
}

/** Generate a short, meaningful title for a conversation. */
async function generateTitle(options: {
  model: string;
  message: string;
  conversationId: string;
  userId: string | null;
}): Promise<string | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const raw = await generateText({
      model: options.model,
      system: TITLE_SYSTEM_PROMPT,
      prompt: options.message.slice(0, 4000),
      signal: controller.signal,
      maxOutputTokens: 64,
    });
    const cleaned = raw
      .replace(/^["'`]|["'`]$/g, '')
      .replace(/^Title:\s*/i, '')
      .split('\n')[0]
      .trim();
    if (!cleaned) return null;
    const title = cleaned.slice(0, 70);

    if (options.userId) {
      const conversation = await getConversation(options.userId, options.conversationId);
      if (conversation && (conversation.title === 'New chat' || !conversation.title)) {
        await updateConversation(options.userId, options.conversationId, {
          title,
          autoTitle: true,
        });
      } else if (!conversation) {
        return null;
      }
    }
    return title;
  } catch {
    return fallbackTitle(options.message);
  } finally {
    clearTimeout(timer);
  }
}

/** Ask the model which durable facts the latest message contains. */
async function extractMemories(options: {
  model: string;
  message: string;
  signal: AbortSignal;
  userId: string | null;
  existing: Memory[];
}): Promise<Memory[]> {
  const controller = new AbortController();  const timer = setTimeout(() => controller.abort(), 10_000);
  const onAbort = () => controller.abort();
  options.signal.addEventListener('abort', onAbort, { once: true });

  try {
    const raw = await generateText({
      model: options.model,
      system: MEMORY_EXTRACTION_PROMPT,
      prompt: options.message.slice(0, 4000),
      signal: controller.signal,
      maxOutputTokens: 512,
    });
    const candidates = parseExtractedMemories(raw);
    if (candidates.length === 0) return [];

    const existingBodies = new Set(options.existing.map((memory) => memory.content.toLowerCase()));
    const created: Memory[] = [];

    for (const candidate of candidates) {
      const content = sanitizeMemoryContent(candidate.content);
      if (!content) continue;
      if (existingBodies.has(content.toLowerCase())) continue;
      existingBodies.add(content.toLowerCase());

      if (options.userId) {
        try {
          const memory = await createMemory(options.userId, {
            content,
            category: candidate.category,
            source: 'auto',
          });
          created.push(memory);
        } catch {
          /* ignore individual failures */
        }
      } else {
        created.push({
          id: crypto.randomUUID(),
          content,
          category: candidate.category,
          source: 'auto',
          enabled: true,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });
      }
    }

    return created;
  } catch {
    return [];
  } finally {
    clearTimeout(timer);
    options.signal.removeEventListener('abort', onAbort);
  }
}
