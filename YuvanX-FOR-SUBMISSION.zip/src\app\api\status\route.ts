import { NextResponse } from 'next/server';
import { getFallbackProviderConfig, getGeminiConfig, getSupabaseConfig } from '@/lib/server/env';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Ask Supabase which social providers are enabled.
 *
 * The UI only offers "Continue with Google" when the provider is really
 * configured — otherwise the button would bounce the user to an error page on
 * supabase.co, which looks like the app is broken. Best effort: if the probe
 * fails we simply do not advertise the provider.
 */
async function probeGoogle(url: string, anonKey: string): Promise<boolean> {
  try {
    const response = await fetch(`${url}/auth/v1/settings`, {
      headers: { apikey: anonKey },
      cache: 'no-store',
      signal: AbortSignal.timeout(4000),
    });
    if (!response.ok) return false;
    const data = (await response.json()) as { external?: { google?: boolean } };
    return Boolean(data.external?.google);
  } catch {
    return false;
  }
}

/**
 * Reports the server configuration so the UI can show a helpful setup screen
 * instead of failing silently. It never returns any secret material.
 */
export async function GET() {
  const gemini = getGeminiConfig();
  const supabase = getSupabaseConfig();
  const fallback = getFallbackProviderConfig();
  const accountsEnabled = Boolean(supabase?.url && supabase?.anonKey);

  return NextResponse.json({
    ok: true,
    providerConfigured: Boolean(gemini),
    provider: 'gemini',
    model: gemini?.model ?? null,
    fallbackModels: gemini?.fallbackModels ?? [],
    failoverConfigured: Boolean(fallback),
    cloudPersistence: Boolean(supabase?.serviceRoleKey),
    accountsEnabled,
    googleAuth: accountsEnabled && supabase ? await probeGoogle(supabase.url, supabase.anonKey) : false,
    guestMode: !supabase?.serviceRoleKey,
  });
}
