import type { Metadata, Viewport } from 'next';
import { Inter, Manrope } from 'next/font/google';
import './globals.css';
import { Providers } from '@/components/providers';
import { Background } from '@/components/background';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-body',
  display: 'swap',
});

const manrope = Manrope({
  subsets: ['latin'],
  variable: '--font-display-face',
  display: 'swap',
});

export const metadata: Metadata = {
  title: {
    default: 'YuvanX — a genuinely helpful AI assistant',
    template: '%s · YuvanX',
  },
  description:
    'YuvanX is a premium AI assistant that reads your files, searches the web, and remembers what matters — with real streaming answers and full control over your data.',
  applicationName: 'YuvanX',
  keywords: ['AI assistant', 'Gemini', 'chat', 'file analysis', 'web search'],
  authors: [{ name: 'YuvanX' }],
  openGraph: {
    title: 'YuvanX — a genuinely helpful AI assistant',
    description:
      'Real streaming answers, file analysis, web search with citations, and persistent memory you control.',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: '/icon.svg',
    apple: '/icon.svg',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f4f6fc' },
    { media: '(prefers-color-scheme: dark)', color: '#050812' },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${manrope.variable} antialiased`}>
        <Providers>
          <Background />
          {children}
        </Providers>
      </body>
    </html>
  );
}
