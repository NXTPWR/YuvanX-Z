'use client';

import { useCallback, useRef, useState, type ComponentPropsWithoutRef, type ReactNode } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import { Check, Copy } from 'lucide-react';
import { cn } from '@/lib/utils';

function isExternal(href: string | undefined): boolean {
  if (!href) return false;
  return /^https?:\/\//i.test(href);
}

/** Code blocks get a language chip and a copy button. */
function CodeBlock({ children }: { children?: ReactNode }) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const timer = useRef<number | null>(null);

  const copy = useCallback(async () => {
    const code = wrapperRef.current?.querySelector('pre code');
    const text = code?.textContent ?? '';
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Clipboard access can be denied — fall back to a hidden textarea.
      const area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      try {
        document.execCommand('copy');
      } catch {
        /* nothing else we can do */
      }
      document.body.removeChild(area);
    }
    setCopied(true);
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setCopied(false), 1600);
  }, []);

  const language = detectLanguage(children);

  return (
    <div ref={wrapperRef} className="group/code relative">
      {language ? (
        <span className="absolute right-12 top-2 z-10 select-none rounded-md bg-[rgb(var(--bg-deep)/0.8)] px-2 py-0.5 font-mono text-[0.65rem] uppercase tracking-wider text-subtle">
          {language}
        </span>
      ) : null}
      <button
        type="button"
        onClick={copy}
        aria-label={copied ? 'Code copied' : 'Copy code'}
        className={cn(
          'absolute right-2 top-2 z-10 rounded-md border border-line bg-[rgb(var(--panel-solid)/0.85)] p-1.5',
          'text-subtle opacity-0 transition-opacity hover:text-ink focus-visible:opacity-100',
          'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent group-hover/code:opacity-100',
        )}
      >
        {copied ? <Check size={13} className="text-success" /> : <Copy size={13} />}
      </button>
      {/* react-markdown hands us the <code> child, but the <pre> wrapper was
          replaced by this component — keep a real <pre> so the block styles
          apply and the copy handler above can read pre > code. */}
      <pre>{children}</pre>
    </div>
  );
}

/** Pull the fence language out of `<code className="language-js">`. */
function detectLanguage(children: ReactNode): string | null {
  const candidate = Array.isArray(children) ? children[0] : children;
  if (!candidate || typeof candidate !== 'object') return null;
  const className = (candidate as { props?: { className?: unknown } }).props?.className;
  if (typeof className !== 'string') return null;
  const match = /language-([\w+#.-]+)/.exec(className);
  return match ? match[1] : null;
}

export interface MarkdownProps {
  content: string;
  className?: string;
}

/**
 * Renders model output as GitHub-flavoured Markdown.
 *
 * Raw HTML is intentionally not enabled — the model output is untrusted and is
 * never injected as HTML.
 */
export function Markdown({ content, className }: MarkdownProps) {
  return (
    <div className={cn('prose-yx', className)}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[[rehypeHighlight, { detect: true, ignoreMissing: true }]]}
        components={{
          a({ href, children, ...props }: ComponentPropsWithoutRef<'a'>) {
            const external = isExternal(href);
            return (
              <a
                href={href}
                {...(external ? { target: '_blank', rel: 'noopener noreferrer nofollow' } : {})}
                {...props}
              >
                {children}
              </a>
            );
          },
          img({ src, alt, ...props }: ComponentPropsWithoutRef<'img'>) {
            return (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={src}
                alt={alt ?? ''}
                loading="lazy"
                referrerPolicy="no-referrer"
                {...props}
              />
            );
          },
          pre({ children }: ComponentPropsWithoutRef<'pre'>) {
            return <CodeBlock>{children}</CodeBlock>;
          },
          table({ children, ...props }: ComponentPropsWithoutRef<'table'>) {
            return (
              <div className="my-3 overflow-x-auto rounded-[var(--radius-md)] border border-line">
                <table {...props}>{children}</table>
              </div>
            );
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
