'use client';

import { useId } from 'react';
import { cn } from '@/lib/utils';

export interface LogoProps {
  size?: number;
  className?: string;
  /** Render only the glyph, without the wordmark. */
  markOnly?: boolean;
}

/**
 * The YuvanX mark — a rounded prism badge with an aurora gradient and a
 * luminous "Y". Each instance gets its own gradient id so multiple marks on
 * one page (sidebar, header, dialogs) never fight over the same definition.
 */
export function LogoMark({
  size = 28,
  className,
  animated = false,
}: {
  size?: number;
  className?: string;
  /** Slow aurora drift on the gradient — used on the welcome screen. */
  animated?: boolean;
}) {
  const gradientId = `yx-mark-${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`;
  const softId = `${gradientId}-soft`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      role="img"
      aria-label="YuvanX"
      className={cn('shrink-0 drop-shadow-[0_2px_10px_rgb(var(--accent)/0.35)]', className)}
    >
      <defs>
        <linearGradient id={gradientId} x1="4" y1="3" x2="28" y2="29" gradientUnits="userSpaceOnUse">
          <stop stopColor="rgb(var(--accent))" />
          <stop offset="1" stopColor="rgb(var(--accent-2))" />
          {animated ? (
            <animateTransform
              attributeName="gradientTransform"
              type="rotate"
              from="0 0.5 0.5"
              to="360 0.5 0.5"
              dur="14s"
              repeatCount="indefinite"
            />
          ) : null}
        </linearGradient>
        <radialGradient id={softId} cx="0.3" cy="0.2" r="0.9">
          <stop stopColor="rgb(255 255 255 / 0.45)" />
          <stop offset="1" stopColor="rgb(255 255 255 / 0)" />
        </radialGradient>
      </defs>
      {/* Solid badge — visible in every theme, unlike a low-opacity outline. */}
      <rect x="1" y="1" width="30" height="30" rx="9" fill={`url(#${gradientId})`} />
      {animated ? (
        <rect x="1" y="1" width="30" height="30" rx="9" fill={`url(#${softId})`}>
          <animate
            attributeName="opacity"
            values="0.25;0.7;0.25"
            dur="6s"
            repeatCount="indefinite"
          />
        </rect>
      ) : null}
      {/* Soft inner highlight for depth. */}
      <rect
        x="1.7"
        y="1.7"
        width="28.6"
        height="28.6"
        rx="8.3"
        stroke="rgb(255 255 255 / 0.28)"
        strokeWidth="1.2"
      />
      <path
        d="M9.5 8.5 16 15.8l6.5-7.3"
        stroke="white"
        strokeWidth="2.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M16 15.8v8.2" stroke="white" strokeWidth="2.8" strokeLinecap="round" />
    </svg>
  );
}

export function Logo({ size = 28, className, markOnly = false }: LogoProps) {
  if (markOnly) return <LogoMark size={size} className={className} />;

  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <LogoMark size={size} />
      <span className="font-display text-[1.05rem] font-semibold tracking-tight text-ink">
        Yuvan<span className="text-accent">X</span>
      </span>
    </span>
  );
}
