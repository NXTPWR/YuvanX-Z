'use client';

import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type DragEvent,
  type KeyboardEvent,
} from 'react';
import { ArrowUp, Globe, Loader2, Paperclip, Square, X } from 'lucide-react';
import { ACCEPT_ATTRIBUTE, MAX_ATTACHMENTS, MAX_FILE_BYTES } from '@/lib/constants';
import { uploadAttachment } from '@/lib/api';
import { cn, formatBytes } from '@/lib/utils';
import type { AttachmentMeta } from '@/lib/types';
import { useSettingsStore } from '@/lib/store/settings';
import { useToast } from '@/components/ui/toast';

export interface ComposerProps {
  onSend: (text: string, attachments: AttachmentMeta[]) => void;
  onStop: () => void;
  streaming: boolean;
  disabled?: boolean;
  webSearch: boolean;
  onToggleWebSearch: (value: boolean) => void;
  /** Signed-in users get the larger upload allowance. */
  authenticated?: boolean;
  placeholder?: string;
}

interface PendingUpload {
  id: string;
  name: string;
  size: number;
  status: 'uploading' | 'ready' | 'error';
  error?: string;
  previewUrl?: string;
  attachment?: AttachmentMeta;
}

const MAX_TEXTAREA_HEIGHT = 260;

export function Composer({
  onSend,
  onStop,
  streaming,
  disabled = false,
  webSearch,
  onToggleWebSearch,
  authenticated = false,
  placeholder = 'Ask YuvanX anything…',
}: ComposerProps) {
  const [text, setText] = useState('');
  const [uploads, setUploads] = useState<PendingUpload[]>([]);
  const [dragging, setDragging] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragDepth = useRef(0);

  const enterToSend = useSettingsStore((state) => state.enterToSend);
  const toast = useToast();

  /* Auto-grow the textarea. */
  useEffect(() => {
    const element = textareaRef.current;
    if (!element) return;
    element.style.height = 'auto';
    element.style.height = `${Math.min(element.scrollHeight, MAX_TEXTAREA_HEIGHT)}px`;
    element.style.overflowY = element.scrollHeight > MAX_TEXTAREA_HEIGHT ? 'auto' : 'hidden';
  }, [text]);

  /* Focus the composer when a new chat starts. */
  useEffect(() => {
    if (!disabled) textareaRef.current?.focus();
  }, [disabled]);

  const ready = uploads.filter((upload) => upload.status === 'ready');
  const uploading = uploads.some((upload) => upload.status === 'uploading');
  const canSend = !disabled && (text.trim().length > 0 || ready.length > 0) && !uploading;

  const handleFiles = useCallback(
    async (files: FileList | File[]) => {
      const list = Array.from(files);
      if (list.length === 0) return;

      setUploads((current) => {
        const room = MAX_ATTACHMENTS - current.length;
        if (room <= 0) {
          toast.error(`You can attach at most ${MAX_ATTACHMENTS} files per message.`);
          return current;
        }
        if (list.length > room) {
          toast.info(`Only the first ${room} file${room === 1 ? '' : 's'} were attached.`);
        }
        return current;
      });

      const room = MAX_ATTACHMENTS - uploads.length;
      if (room <= 0) return;
      const accepted = list.slice(0, room);

      for (const file of accepted) {
        const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const previewUrl = file.type.startsWith('image/')
          ? URL.createObjectURL(file)
          : undefined;

        setUploads((current) => [
          ...current,
          { id, name: file.name, size: file.size, status: 'uploading', previewUrl },
        ]);

        try {
          const response = await uploadAttachment(file);
          setUploads((current) =>
            current.map((upload) =>
              upload.id === id
                ? { ...upload, status: 'ready', attachment: response.attachment }
                : upload,
            ),
          );
        } catch (error) {
          const message = error instanceof Error ? error.message : 'Upload failed.';
          setUploads((current) =>
            current.map((upload) =>
              upload.id === id ? { ...upload, status: 'error', error: message } : upload,
            ),
          );
          toast.error(message);
        }
      }
    },
    [toast, uploads.length],
  );

  const onFileChange = async (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) await handleFiles(event.target.files);
    event.target.value = '';
  };

  const removeUpload = (id: string) => {
    setUploads((current) => {
      const target = current.find((upload) => upload.id === id);
      if (target?.previewUrl) URL.revokeObjectURL(target.previewUrl);
      return current.filter((upload) => upload.id !== id);
    });
  };

  const onDragEnter = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    dragDepth.current += 1;
    if (event.dataTransfer?.types?.includes('Files')) setDragging(true);
  };

  const onDragLeave = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    dragDepth.current -= 1;
    if (dragDepth.current <= 0) {
      dragDepth.current = 0;
      setDragging(false);
    }
  };

  const onDrop = async (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    dragDepth.current = 0;
    setDragging(false);
    if (disabled) return;
    if (event.dataTransfer?.files?.length) await handleFiles(event.dataTransfer.files);
  };

  const submit = () => {
    if (!canSend) return;
    const attachments = ready
      .map((upload) => upload.attachment)
      .filter((attachment): attachment is AttachmentMeta => Boolean(attachment));
    onSend(text.trim(), attachments);
    setText('');
    setUploads((current) => {
      current.forEach((upload) => {
        if (upload.previewUrl) URL.revokeObjectURL(upload.previewUrl);
      });
      return [];
    });
  };

  const onKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key !== 'Enter') return;
    if (event.nativeEvent.isComposing) return;
    const shouldSend = enterToSend ? !event.shiftKey : event.ctrlKey || event.metaKey;
    if (!shouldSend) return;
    event.preventDefault();
    submit();
  };

  return (
    <div
      onDragEnter={onDragEnter}
      onDragOver={(event) => event.preventDefault()}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
      className="relative"
    >
      {dragging ? (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center rounded-[var(--radius-lg)] border-2 border-dashed border-accent bg-[rgb(var(--accent)/0.08)] text-sm font-medium text-accent">
          Drop files to attach
        </div>
      ) : null}

      <div className="glass shadow-soft rounded-[var(--radius-lg)] transition-shadow focus-within:shadow-lifted">
        {uploads.length > 0 ? (
          <ul className="flex flex-wrap gap-2 border-b border-line px-3 py-2.5">
            {uploads.map((upload) => (
              <li
                key={upload.id}
                className={cn(
                  'group relative flex max-w-[16rem] items-center gap-2 rounded-[var(--radius-sm)] border px-2 py-1.5',
                  upload.status === 'error'
                    ? 'border-[rgb(var(--danger)/0.4)]'
                    : 'border-line bg-[rgb(var(--panel)/0.7)]',
                )}
              >
                {upload.previewUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={upload.previewUrl}
                    alt=""
                    className="h-8 w-8 shrink-0 rounded object-cover"
                  />
                ) : (
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded bg-[rgb(var(--accent)/0.12)] text-[0.6rem] font-semibold uppercase text-accent">
                    {upload.name.split('.').pop()?.slice(0, 4) ?? '?'}
                  </span>
                )}

                <span className="min-w-0 flex-1">
                  <span className="block truncate text-xs font-medium text-ink">
                    {upload.name}
                  </span>
                  <span
                    className={cn(
                      'block text-[0.68rem]',
                      upload.status === 'error' ? 'text-danger' : 'text-subtle',
                    )}
                  >
                    {upload.status === 'uploading'
                      ? 'Uploading…'
                      : upload.status === 'error'
                        ? (upload.error ?? 'Upload failed')
                        : formatBytes(upload.size)}
                  </span>
                </span>

                {upload.status === 'uploading' ? (
                  <Loader2 size={13} className="shrink-0 animate-spin text-subtle" />
                ) : (
                  <button
                    type="button"
                    onClick={() => removeUpload(upload.id)}
                    aria-label={`Remove ${upload.name}`}
                    className="shrink-0 rounded p-0.5 text-subtle transition-colors hover:text-danger focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                  >
                    <X size={13} />
                  </button>
                )}
              </li>
            ))}
          </ul>
        ) : null}

        <div className="flex items-end gap-2 px-2.5 py-2.5">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept={ACCEPT_ATTRIBUTE}
            onChange={onFileChange}
            className="sr-only"
            aria-label="Attach files"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={disabled || uploads.length >= MAX_ATTACHMENTS}
            aria-label="Attach a file"
            title={
              authenticated
                ? `Attach files (up to ${formatBytes(MAX_FILE_BYTES)} each)`
                : `Attach files (up to ${formatBytes(2.5 * 1024 * 1024)} each)`
            }
            className={cn(
              'flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-sm)] text-muted',
              'transition-colors hover:bg-[rgb(var(--border)/0.08)] hover:text-ink',
              'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
              'disabled:cursor-not-allowed disabled:opacity-40',
            )}
          >
            <Paperclip size={16} />
          </button>

          <textarea
            ref={textareaRef}
            value={text}
            onChange={(event) => setText(event.target.value)}
            onKeyDown={onKeyDown}
            rows={1}
            disabled={disabled}
            placeholder={placeholder}
            aria-label="Message YuvanX"
            className={cn(
              'max-h-[260px] min-h-[2.25rem] flex-1 resize-none bg-transparent py-2 text-[0.9375rem] leading-relaxed',
              'text-ink placeholder:text-subtle outline-none',
              'disabled:cursor-not-allowed disabled:opacity-60',
            )}
          />

          <button
            type="button"
            onClick={() => onToggleWebSearch(!webSearch)}
            aria-pressed={webSearch}
            aria-label={webSearch ? 'Turn off web search' : 'Turn on web search'}
            title={webSearch ? 'Web search is on' : 'Web search is off'}
            className={cn(
              'flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-sm)] transition-colors',
              'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
              webSearch
                ? 'bg-[rgb(var(--accent)/0.16)] text-accent'
                : 'text-muted hover:bg-[rgb(var(--border)/0.08)] hover:text-ink',
            )}
          >
            <Globe size={16} />
          </button>

          {streaming ? (
            <button
              type="button"
              onClick={onStop}
              aria-label="Stop generating"
              title="Stop generating"
              className={cn(
                'flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-md)]',
                'border border-line-strong bg-[rgb(var(--panel)/0.8)] text-ink',
                'transition-colors hover:border-accent/60',
                'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
              )}
            >
              <Square size={13} fill="currentColor" />
            </button>
          ) : (
            <button
              type="button"
              onClick={submit}
              disabled={!canSend}
              aria-label="Send message"
              className={cn(
                'flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-md)] transition-all',
                'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
                canSend
                  ? 'accent-gradient text-accent-contrast shadow-soft hover:brightness-110'
                  : 'cursor-not-allowed border border-line-strong bg-[rgb(var(--panel)/0.5)] text-subtle',
              )}
            >
              <ArrowUp size={17} />
            </button>
          )}
        </div>
      </div>

      <p className="mt-2 px-1 text-[0.68rem] text-subtle">
        {enterToSend
          ? 'Press Enter to send · Shift + Enter for a new line'
          : 'Press Ctrl + Enter to send · Enter for a new line'}
      </p>
    </div>
  );
}
