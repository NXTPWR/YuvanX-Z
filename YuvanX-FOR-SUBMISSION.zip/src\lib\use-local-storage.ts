'use client';

import { useCallback, useSyncExternalStore } from 'react';

/**
 * A tiny external store over `localStorage`.
 *
 * Using `useSyncExternalStore` keeps the first client render identical to the
 * server render (no hydration mismatch) while still letting the value change
 * when it is written from this tab or another one.
 */

const listeners = new Map<string, Set<() => void>>();

function notify(key: string): void {
  listeners.get(key)?.forEach((listener) => listener());
}

export function useLocalStorageBoolean(
  key: string,
  fallback = false,
): [boolean, (next: boolean) => void] {
  const subscribe = useCallback(
    (onStoreChange: () => void) => {
      let set = listeners.get(key);
      if (!set) {
        set = new Set();
        listeners.set(key, set);
      }
      set.add(onStoreChange);

      const onStorage = (event: StorageEvent) => {
        if (event.key === null || event.key === key) onStoreChange();
      };
      window.addEventListener('storage', onStorage);

      return () => {
        set?.delete(onStoreChange);
        window.removeEventListener('storage', onStorage);
      };
    },
    [key],
  );

  const getSnapshot = useCallback(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw === null) return fallback;
      return raw === '1' || raw === 'true';
    } catch {
      return fallback;
    }
  }, [key, fallback]);

  const getServerSnapshot = useCallback(() => fallback, [fallback]);

  const value = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const setValue = useCallback(
    (next: boolean) => {
      try {
        window.localStorage.setItem(key, next ? '1' : '0');
      } catch {
        /* storage unavailable — the value still changes for this session */
      }
      notify(key);
    },
    [key],
  );

  return [value, setValue];
}
