'use client';

import { useCallback, useMemo, useState } from 'react';
import {
  Brain,
  Check,
  Pencil,
  Plus,
  Sparkles,
  Trash2,
  TriangleAlert,
  X,
} from 'lucide-react';
import { useChatStore } from '@/lib/store/chat';
import { useAuthStore } from '@/lib/store/auth';
import { useSettingsStore } from '@/lib/store/settings';
import {
  clearRemoteMemories,
  createRemoteMemory,
  deleteRemoteMemory,
  patchRemoteMemory,
} from '@/lib/cloud';
import { Button, IconButton } from '@/components/ui/button';
import { Modal } from '@/components/ui/modal';
import { Switch } from '@/components/ui/field';
import { useToast } from '@/components/ui/toast';
import { useUiStore } from '@/lib/store/ui';
import { uid } from '@/lib/utils';
import {
  containsSensitiveData,
  sanitizeMemoryContent,
  SENSITIVE_MEMORY_MESSAGE,
} from '@/lib/memory';
import type { Memory, MemoryCategory } from '@/lib/types';

const CATEGORIES: Array<{ value: MemoryCategory; label: string }> = [
  { value: 'preference', label: 'Preference' },
  { value: 'project', label: 'Project' },
  { value: 'instruction', label: 'Instruction' },
  { value: 'fact', label: 'Fact' },
  { value: 'note', label: 'Note' },
];

const CATEGORY_STYLES: Record<MemoryCategory, string> = {
  preference: 'bg-[rgb(var(--accent)/0.14)] text-accent',
  project: 'bg-[rgb(var(--accent-2)/0.14)] text-accent-2',
  instruction: 'bg-[rgb(var(--warning)/0.15)] text-warning',
  fact: 'bg-[rgb(var(--success)/0.15)] text-success',
  note: 'bg-[rgb(var(--border)/0.12)] text-muted',
};

export default function MemoriesPage() {
  const toast = useToast();
  const openAuthDialog = useUiStore((state) => state.openAuth);

  const memories = useChatStore((state) => state.memories);
  const addMemory = useChatStore((state) => state.addMemory);
  const patchMemory = useChatStore((state) => state.patchMemory);
  const removeMemory = useChatStore((state) => state.removeMemory);
  const clearMemories = useChatStore((state) => state.clearMemories);

  const user = useAuthStore((state) => state.user);
  const accountsEnabled = useAuthStore((state) => state.accountsEnabled);
  const openAuth = useAuthStore((state) => state.status);

  const memoryEnabled = useSettingsStore((state) => state.memoryEnabled);
  const autoMemory = useSettingsStore((state) => state.autoMemory);
  const setSetting = useSettingsStore((state) => state.set);

  const [draft, setDraft] = useState('');
  const [category, setCategory] = useState<MemoryCategory>('note');
  const [editing, setEditing] = useState<Memory | null>(null);
  const [editValue, setEditValue] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);

  const enabled = useMemo(() => memories.filter((memory) => memory.enabled), [memories]);

  const add = useCallback(async () => {
    const raw = draft.trim();
    if (!raw) return;

    // Secrets never reach the store — not locally, not in the cloud.
    if (containsSensitiveData(raw)) {
      setDraft('');
      toast.error(SENSITIVE_MEMORY_MESSAGE);
      return;
    }

    const content = sanitizeMemoryContent(raw);
    if (!content) return;
    setDraft('');

    if (openAuth === 'authenticated' && user) {
      const created = await createRemoteMemory({ content, category });
      if (created) {
        addMemory(created);
        toast.success('Memory saved.');
        return;
      }
      toast.error('That memory could not be saved to the cloud.');
      return;
    }

    addMemory({
      id: uid('mem'),
      content,
      category,
      source: 'manual',
      enabled: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
    toast.success('Memory saved.');
  }, [addMemory, category, draft, openAuth, toast, user]);

  const saveEdit = useCallback(async () => {
    if (!editing) return;
    const raw = editValue.trim();
    const target = editing;
    setEditing(null);
    if (!raw || raw === target.content) return;

    if (containsSensitiveData(raw)) {
      toast.error(SENSITIVE_MEMORY_MESSAGE);
      return;
    }

    const content = sanitizeMemoryContent(raw);
    if (!content) return;

    patchMemory(target.id, { content, updatedAt: Date.now() });
    if (user) {
      const remote = await patchRemoteMemory(target.id, { content });
      if (remote) patchMemory(target.id, remote);
    }
  }, [editValue, editing, patchMemory, toast, user]);

  const toggle = useCallback(
    async (memory: Memory) => {
      const next = !memory.enabled;
      patchMemory(memory.id, { enabled: next, updatedAt: Date.now() });
      if (user) await patchRemoteMemory(memory.id, { enabled: next });
    },
    [patchMemory, user],
  );

  const remove = useCallback(
    async (memory: Memory) => {
      removeMemory(memory.id);
      if (user) await deleteRemoteMemory(memory.id);
      toast.success('Memory deleted.');
    },
    [removeMemory, toast, user],
  );

  const clearAll = useCallback(async () => {
    setConfirmClear(false);
    clearMemories();
    if (user) await clearRemoteMemories();
    toast.success('All memories cleared.');
  }, [clearMemories, toast, user]);

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8 sm:px-6 sm:py-12">
      <header className="animate-fade-up">
        <span className="accent-gradient mb-4 flex h-11 w-11 items-center justify-center rounded-xl text-accent-contrast shadow-soft">
          <Brain size={20} />
        </span>
        <h1 className="font-display text-2xl font-semibold tracking-tight text-ink">Memory</h1>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">
          YuvanX uses these facts to personalise its answers. Nothing is stored until you add it
          here, and secrets are always rejected.
        </p>
      </header>

      <section className="glass mt-7 rounded-[var(--radius-lg)] px-4 py-1">
        <Switch
          checked={memoryEnabled}
          onChange={(value) => setSetting('memoryEnabled', value)}
          label="Remember things across conversations"
          description="The master switch. When it is off, nothing is stored and nothing is recalled."
        />
        <div className="h-px bg-[rgb(var(--border)/0.1)]" />
        <Switch
          checked={autoMemory}
          onChange={(value) => setSetting('autoMemory', value)}
          disabled={!memoryEnabled}
          label="Learn automatically"
          description="Let YuvanX propose durable facts from your messages. Everything it learns is shown here and can be removed at any time."
        />
      </section>

      {memoryEnabled ? (
        <>
          <section className="glass mt-6 rounded-[var(--radius-lg)] p-4">
            <label htmlFor="yx-memory-input" className="mb-2 block text-sm font-medium text-ink">
              Add something to remember
            </label>
            <textarea
              id="yx-memory-input"
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {
                  event.preventDefault();
                  void add();
                }
              }}
              rows={3}
              maxLength={400}
              placeholder="e.g. I prefer TypeScript over JavaScript for new projects."
              className="w-full resize-y rounded-[var(--radius-md)] border border-line-strong bg-[rgb(var(--panel)/0.6)] px-3 py-2 text-sm leading-relaxed text-ink placeholder:text-subtle focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25"
            />
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <select
                value={category}
                onChange={(event) => setCategory(event.target.value as MemoryCategory)}
                aria-label="Memory category"
                className="h-9 rounded-[var(--radius-sm)] border border-line-strong bg-[rgb(var(--panel)/0.6)] px-2.5 text-xs text-ink focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25"
              >
                {CATEGORIES.map((option) => (
                  <option key={option.value} value={option.value} className="bg-panel-solid text-ink">
                    {option.label}
                  </option>
                ))}
              </select>
              <Button variant="primary" onClick={() => void add()} disabled={!draft.trim()}>
                <Plus size={14} />
                Save memory
              </Button>
              <span className="text-[0.68rem] text-subtle">⌘ + Enter to save</span>
            </div>
          </section>

          <section className="mt-8">
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-display text-base font-semibold text-ink">
                {memories.length === 0
                  ? 'No memories yet'
                  : `${memories.length} memor${memories.length === 1 ? 'y' : 'ies'}`}
              </h2>
              {memories.length > 0 ? (
                <Button variant="danger" size="sm" onClick={() => setConfirmClear(true)}>
                  <Trash2 size={13} />
                  Clear all
                </Button>
              ) : null}
            </div>

            {memories.length === 0 ? (
              <div className="mt-4 rounded-[var(--radius-lg)] border border-dashed border-line-strong px-5 py-10 text-center">
                <Sparkles size={20} className="mx-auto text-subtle" />
                <p className="mt-3 text-sm text-muted">
                  Nothing here yet. Add a preference, a project or an instruction and YuvanX will
                  use it from then on.
                </p>
              </div>
            ) : (
              <ul className="mt-4 space-y-2">
                {memories.map((memory) => (
                  <li
                    key={memory.id}
                    className="glass flex items-start gap-3 rounded-[var(--radius-md)] px-3.5 py-3"
                  >
                    <span
                      className={`mt-0.5 shrink-0 rounded-md px-1.5 py-0.5 text-[0.62rem] font-semibold uppercase tracking-wider ${CATEGORY_STYLES[memory.category]}`}
                    >
                      {memory.category}
                    </span>

                    <div className="min-w-0 flex-1">
                      <p
                        className={`text-sm leading-relaxed ${memory.enabled ? 'text-ink' : 'text-subtle line-through'}`}
                      >
                        {memory.content}
                      </p>
                      <p className="mt-1 text-[0.66rem] text-subtle">
                        {memory.source === 'auto' ? 'Learned automatically' : 'Added by you'}
                        {memory.source === 'auto' ? ' · ' : ' · '}
                        {new Date(memory.createdAt).toLocaleDateString()}
                      </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-0.5">
                      <IconButton
                        label={memory.enabled ? 'Disable this memory' : 'Enable this memory'}
                        onClick={() => void toggle(memory)}
                        size="icon"
                        className="h-8 w-8"
                      >
                        {memory.enabled ? (
                          <Check size={14} className="text-success" />
                        ) : (
                          <X size={14} className="text-subtle" />
                        )}
                      </IconButton>
                      <IconButton
                        label="Edit memory"
                        onClick={() => {
                          setEditing(memory);
                          setEditValue(memory.content);
                        }}
                        size="icon"
                        className="h-8 w-8"
                      >
                        <Pencil size={13} />
                      </IconButton>
                      <IconButton
                        label="Delete memory"
                        onClick={() => void remove(memory)}
                        size="icon"
                        className="h-8 w-8 hover:text-danger"
                      >
                        <Trash2 size={13} />
                      </IconButton>
                    </div>
                  </li>
                ))}
              </ul>
            )}

            {enabled.length > 0 ? (
              <p className="mt-4 text-[0.7rem] text-subtle">
                {enabled.length} memor{enabled.length === 1 ? 'y is' : 'ies are'} currently used when
                answering.
              </p>
            ) : null}
          </section>
        </>
      ) : (
        <div className="mt-8 rounded-[var(--radius-lg)] border border-dashed border-line-strong px-5 py-10 text-center">
          <TriangleAlert size={20} className="mx-auto text-warning" />
          <p className="mt-3 text-sm text-muted">
            Memory is switched off. Turn it back on above to add and recall memories.
          </p>
        </div>
      )}

      {!user && accountsEnabled ? (
        <p className="mt-8 text-center text-[0.72rem] text-subtle">
          Memories are stored in this browser only.{' '}
          <button
            type="button"
            onClick={() => openAuthDialog('sync')}
            className="font-medium text-accent underline-offset-2 hover:underline"
          >
            Sign in
          </button>{' '}
          to sync them across devices.
        </p>
      ) : null}

      <Modal
        open={Boolean(editing)}
        onClose={() => setEditing(null)}
        title="Edit memory"
        description="Keep it to a single, self-contained sentence."
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={() => void saveEdit()}>
              Save
            </Button>
          </>
        }
      >
        <textarea
          value={editValue}
          onChange={(event) => setEditValue(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {
              event.preventDefault();
              void saveEdit();
            }
          }}
          rows={3}
          maxLength={400}
          aria-label="Memory content"
          className="w-full resize-y rounded-[var(--radius-md)] border border-line-strong bg-[rgb(var(--panel)/0.6)] px-3 py-2 text-sm leading-relaxed text-ink focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25"
        />
      </Modal>

      <Modal
        open={confirmClear}
        onClose={() => setConfirmClear(false)}
        title="Clear every memory?"
        description="This removes all memories permanently. YuvanX will forget everything it was told."
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmClear(false)}>
              Keep them
            </Button>
            <Button variant="danger" onClick={() => void clearAll()}>
              <Trash2 size={14} />
              Clear everything
            </Button>
          </>
        }
      >
        <p className="text-sm leading-relaxed text-muted">
          {memories.length} memor{memories.length === 1 ? 'y' : 'ies'} will be deleted.
        </p>
      </Modal>
    </div>
  );
}
