'use client';

import { create } from 'zustand';
import type { Session, User } from '@supabase/supabase-js';
import { getSupabaseBrowserClient, isSupabaseConfigured } from '@/lib/supabase-client';
import { getClientId } from '@/lib/api';
import { useChatStore } from '@/lib/store/chat';

export interface AuthUser {
  id: string;
  email: string | null;
  name: string | null;
  avatarUrl: string | null;
}

export type AuthStatus = 'loading' | 'authenticated' | 'anonymous';

function toAuthUser(user: User): AuthUser {
  const metadata = (user.user_metadata ?? {}) as Record<string, unknown>;
  const name =
    (typeof metadata.full_name === 'string' && metadata.full_name) ||
    (typeof metadata.name === 'string' && metadata.name) ||
    (user.email ? user.email.split('@')[0] : null);
  const avatarUrl =
    (typeof metadata.avatar_url === 'string' && metadata.avatar_url) ||
    (typeof metadata.picture === 'string' && metadata.picture) ||
    null;
  return { id: user.id, email: user.email ?? null, name, avatarUrl };
}

export interface AuthStore {
  user: AuthUser | null;
  status: AuthStatus;
  /** True while an auth request is in flight. */
  pending: boolean;
  error: string | null;
  /** True when the deployment has Supabase configured (accounts available). */
  accountsEnabled: boolean;
  /** True when Supabase reports that the Google provider is configured. */
  googleEnabled: boolean;
  /** Set after sign-up when the provider requires an email confirmation. */
  needsEmailConfirmation: boolean;

  init(): Promise<void>;
  signIn(email: string, password: string): Promise<boolean>;
  signUp(email: string, password: string): Promise<boolean>;
  signInWithOtp(email: string): Promise<boolean>;
  verifyOtp(email: string, token: string): Promise<boolean>;
  signInWithGoogle(): Promise<boolean>;
  signOut(): Promise<void>;
  clearError(): void;
}

/**
 * The chat store caches conversations, messages and memories in `localStorage`
 * so the app opens instantly and works offline. That cache belongs to whoever
 * was signed in, so it must not survive a change of identity: otherwise the
 * next person using the same browser would read the previous account's chats.
 *
 * The store remembers its owner persistently, which makes this safe even when
 * the tab is closed or crashes instead of signing out cleanly. Guest data is
 * kept — it is adopted by the next account rather than thrown away.
 */
function syncIdentity(user: AuthUser | null): void {
  const id = user?.id ?? null;
  // The persisted cache must finish loading first: claiming ownership of an
  // empty in-memory store would compare against `null` and let stale data from
  // a previous account survive the reload.
  if (useChatStore.persist.hasHydrated()) {
    useChatStore.getState().claimOwnership(id);
    return;
  }
  const unsubscribe = useChatStore.persist.onFinishHydration(() => {
    unsubscribe();
    useChatStore.getState().claimOwnership(id);
  });
}

function friendly(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes('invalid login credentials')) {
    return 'That email and password combination does not match an account.';
  }
  if (lower.includes('email not confirmed')) {
    return 'Please confirm your email address first — check your inbox for the link.';
  }
  if (lower.includes('user already registered')) {
    return 'An account already exists for that email. Try signing in instead.';
  }
  if (lower.includes('password should be')) {
    return 'Passwords must be at least 6 characters long.';
  }
  if (lower.includes('rate limit') || lower.includes('too many')) {
    return 'Too many attempts. Please wait a moment and try again.';
  }
  if (lower.includes('failed to fetch') || lower.includes('network')) {
    return 'Could not reach the authentication service. Check your connection and try again.';
  }
  return message;
}

export const useAuthStore = create<AuthStore>()((set) => ({
  user: null,
  status: 'loading',
  pending: false,
  error: null,
  accountsEnabled: isSupabaseConfigured(),
  googleEnabled: false,
  needsEmailConfirmation: false,

  init: async () => {
    const client = getSupabaseBrowserClient();
    if (!client) {
      set({ status: 'anonymous', accountsEnabled: false });
      return;
    }

    // Which social providers are actually wired up? Asking the server keeps the
    // UI honest instead of offering a button that leads to an error page.
    void fetch('/api/status', { cache: 'no-store' })
      .then((response) => (response.ok ? response.json() : null))
      .then((data: unknown) => {
        const google = (data as { googleAuth?: unknown } | null)?.googleAuth;
        if (typeof google === 'boolean') set({ googleEnabled: google });
      })
      .catch(() => undefined);

    const { data } = await client.auth.getSession();
    if (data.session) {
      const user = toAuthUser(data.session.user);
      syncIdentity(user);
      set({ user, status: 'authenticated' });
    } else {
      syncIdentity(null);
      set({ status: 'anonymous' });
    }

    client.auth.onAuthStateChange((_event: string, session: Session | null) => {
      if (session) {
        const user = toAuthUser(session.user);
        syncIdentity(user);
        set({ user, status: 'authenticated', error: null });
      } else {
        syncIdentity(null);
        set({ user: null, status: 'anonymous' });
      }
    });
  },

  signIn: async (email, password) => {
    const client = getSupabaseBrowserClient();
    if (!client) {
      set({ error: 'Accounts are not enabled on this deployment.' });
      return false;
    }
    set({ pending: true, error: null });
    const { data, error } = await client.auth.signInWithPassword({ email, password });
    set({ pending: false });
    if (error) {
      set({ error: friendly(error.message) });
      return false;
    }
    if (data.session) {
      const user = toAuthUser(data.session.user);
      syncIdentity(user);
      set({ user, status: 'authenticated' });
    }
    return true;
  },

  signUp: async (email, password) => {
    const client = getSupabaseBrowserClient();
    if (!client) {
      set({ error: 'Accounts are not enabled on this deployment.' });
      return false;
    }
    set({ pending: true, error: null });

    // Preferred path: the server creates the account with the address already
    // confirmed and returns a ready session, so a fresh deployment works
    // without an email provider. If the route is unavailable we fall back to
    // Supabase's own sign-up flow.
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-yuvanx-client': getClientId() },
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        const data = (await response.json()) as {
          session?: {
            access_token: string;
            refresh_token: string;
            user: User;
          };
          needsEmailConfirmation?: boolean;
        };

        if (data.session) {
          const { error } = await client.auth.setSession({
            access_token: data.session.access_token,
            refresh_token: data.session.refresh_token,
          });
          if (!error) {
            set({
              pending: false,
              user: toAuthUser(data.session.user),
              status: 'authenticated',
              needsEmailConfirmation: false,
            });
            return true;
          }
        } else if (data.needsEmailConfirmation) {
          set({ pending: false, needsEmailConfirmation: true, status: 'anonymous' });
          return true;
        }
      } else if (response.status === 409) {
        const data = (await response.json().catch(() => null)) as { error?: string } | null;
        set({
          pending: false,
          error: data?.error ?? 'An account already exists for that email. Try signing in instead.',
        });
        return false;
      } else if (response.status === 400 || response.status === 429) {
        const data = (await response.json().catch(() => null)) as { error?: string } | null;
        set({ pending: false, error: data?.error ?? 'Could not create that account.' });
        return false;
      }
      // Any other status (e.g. 404 = feature not deployed) falls through to
      // the browser flow below.
    } catch {
      /* network failure — fall through to the browser flow */
    }

    const { data, error } = await client.auth.signUp({ email, password });
    set({ pending: false });
    if (error) {
      set({ error: friendly(error.message) });
      return false;
    }
    if (data.session) {
      const user = toAuthUser(data.session.user);
      syncIdentity(user);
      set({ user, status: 'authenticated', needsEmailConfirmation: false });
    } else {
      set({ needsEmailConfirmation: true, status: 'anonymous' });
    }
    return true;
  },

  signInWithOtp: async (email) => {
    const client = getSupabaseBrowserClient();
    if (!client) {
      set({ error: 'Accounts are not enabled on this deployment.' });
      return false;
    }
    set({ pending: true, error: null });
    const { error } = await client.auth.signInWithOtp({
      email,
      options: { shouldCreateUser: true, emailRedirectTo: `${window.location.origin}/chat` },
    });
    set({ pending: false });
    if (error) {
      set({ error: friendly(error.message) });
      return false;
    }
    return true;
  },

  verifyOtp: async (email, token) => {
    const client = getSupabaseBrowserClient();
    if (!client) {
      set({ error: 'Accounts are not enabled on this deployment.' });
      return false;
    }
    set({ pending: true, error: null });
    const { data, error } = await client.auth.verifyOtp({ email, token, type: 'email' });
    set({ pending: false });
    if (error) {
      set({ error: friendly(error.message) });
      return false;
    }
    if (data.session) {
      const user = toAuthUser(data.session.user);
      syncIdentity(user);
      set({ user, status: 'authenticated', needsEmailConfirmation: false });
    }
    return true;
  },

  signInWithGoogle: async () => {
    const client = getSupabaseBrowserClient();
    if (!client) {
      set({ error: 'Accounts are not enabled on this deployment.' });
      return false;
    }
    set({ pending: true, error: null });
    const { error } = await client.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/chat` },
    });
    set({ pending: false });
    if (error) {
      set({ error: friendly(error.message) });
      return false;
    }
    return true;
  },

  signOut: async () => {
    const client = getSupabaseBrowserClient();
    if (client) await client.auth.signOut();
    // Belt and braces: the SIGNED_OUT listener usually fires first, but the
    // cache must never outlive the session.
    syncIdentity(null);
    set({ user: null, status: 'anonymous', error: null });
  },

  clearError: () => set({ error: null, needsEmailConfirmation: false }),
}));

export const selectAuthUser = (state: AuthStore) => state.user;
export const selectAuthStatus = (state: AuthStore) => state.status;
