import type { Memory, MemoryCategory } from '@/lib/types';
import { containsSensitiveData, sanitizeMemoryContent } from '@/lib/memory';

export { containsSensitiveData, sanitizeMemoryContent };

const STOP_WORDS = new Set([
  'about', 'after', 'again', 'also', 'been', 'being', 'could', 'does', 'from', 'have',
  'here', 'into', 'just', 'like', 'make', 'more', 'most', 'much', 'need', 'only',
  'other', 'over', 'please', 'should', 'some', 'such', 'than', 'that', 'their',
  'there', 'these', 'they', 'this', 'those', 'through', 'using', 'very', 'want',
  'what', 'when', 'where', 'which', 'while', 'who', 'why', 'will', 'with', 'would',
  'your', 'yours', 'tell', 'show', 'write', 'give', 'help', 'need', 'thanks',
  'okay', 'yes', 'hello', 'hi', 'hey',
]);

/** Split text into comparable tokens for lexical matching. */
export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .split(/[^a-z0-9+#.-]+/)
    .map((token) => token.replace(/^[.-]+|[.-]+$/g, ''))
    .filter((token) => token.length > 2 && !STOP_WORDS.has(token));
}

/**
 * Score how relevant a memory is to the current question.
 * A simple, predictable lexical model — no embeddings required.
 */
export function scoreMemory(memory: Memory, queryTokens: Set<string>): number {
  const memoryTokens = tokenize(memory.content);
  if (memoryTokens.length === 0) return 0;
  let hits = 0;
  for (const token of memoryTokens) {
    if (queryTokens.has(token)) hits += 1;
  }
  if (hits === 0) {
    // Persistent instructions are usually relevant even without keyword overlap.
    return memory.category === 'instruction' ? 0.2 : 0;
  }
  const coverage = hits / Math.sqrt(memoryTokens.length);
  const categoryBoost = memory.category === 'instruction' ? 0.35 : 0;
  return coverage + categoryBoost;
}

/** Pick the memories most likely to be useful for the current question. */
export function selectRelevantMemories(
  memories: Memory[],
  query: string,
  limit = 8,
): Memory[] {
  const queryTokens = new Set(tokenize(query));
  return memories
    .filter((memory) => memory.enabled && !containsSensitiveData(memory.content))
    .map((memory) => ({ memory, score: scoreMemory(memory, queryTokens) }))
    .filter((entry) => entry.score > 0.15)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((entry) => entry.memory);
}

const VALID_CATEGORIES: MemoryCategory[] = ['preference', 'project', 'instruction', 'fact', 'note'];

/** Parse the JSON payload returned by the memory-extraction prompt. */
export function parseExtractedMemories(raw: string): Array<{ content: string; category: MemoryCategory }> {
  const cleaned = raw
    .trim()
    .replace(/^```(?:json)?/i, '')
    .replace(/```$/, '')
    .trim();

  let parsed: unknown;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (!match) return [];
    try {
      parsed = JSON.parse(match[0]);
    } catch {
      return [];
    }
  }

  const list =
    parsed && typeof parsed === 'object' && Array.isArray((parsed as { memories?: unknown }).memories)
      ? ((parsed as { memories: unknown[] }).memories)
      : [];

  const output: Array<{ content: string; category: MemoryCategory }> = [];
  for (const item of list) {
    if (!item || typeof item !== 'object') continue;
    const entry = item as { content?: unknown; category?: unknown };
    if (typeof entry.content !== 'string') continue;
    const content = sanitizeMemoryContent(entry.content);
    if (!content || content.length < 8) continue;
    if (containsSensitiveData(content)) continue;
    const category = VALID_CATEGORIES.includes(entry.category as MemoryCategory)
      ? (entry.category as MemoryCategory)
      : 'note';
    output.push({ content, category });
  }
  return output;
}

/** Detect an explicit request to remember something. */
export function hasExplicitRememberSignal(message: string): boolean {
  return /\b(remember|remind me|keep in mind|note that|from now on|don'?t forget|save this)\b/i.test(
    message,
  );
}

/**
 * Cheap check for messages that might contain a durable fact about the user.
 *
 * Extracting memories costs one provider request and provider quotas are
 * small, so the extraction only runs when the message looks like it is about
 * the user themselves. The extraction prompt then decides what is worth
 * keeping.
 */
const PERSONAL_FACT_PATTERNS: RegExp[] = [
  /\bmy name is\b/i,
  /\bcall me\b/i,
  /\bi(?:'m| am)\s+(?:a|an|the)\b/i,
  /\bi work (?:as|at|for|with)\b/i,
  /\bi live in\b/i,
  /\bi(?:'m| am) (?:from|based in)\b/i,
  /\bi (?:use|prefer|love|hate|enjoy|avoid|run|own)\b/i,
  /\bmy (?:email|phone|number|company|team|role|job|title|birthday|timezone|partner|wife|husband|son|daughter|dog|cat|manager|professor|stack|setup|machine|goal|budget|deadline|portfolio)\b/i,
  /\bwe (?:use|have|run|are building)\b/i,
  /\balways (?:use|reply|respond|answer)\b/i,
  /\bnever (?:use|reply|respond|answer)\b/i,
];

export function mentionsPersonalFact(message: string): boolean {
  if (hasExplicitRememberSignal(message)) return true;
  return PERSONAL_FACT_PATTERNS.some((pattern) => pattern.test(message));
}
