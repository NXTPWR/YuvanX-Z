'use client';

import { ApiError, buildHeaders } from '@/lib/api';
import type { ChatStreamEvent, Memory } from '@/lib/types';

export interface ChatRequestPayload {
  conversationId?: string | null;
  message?: string;
  attachments?: unknown[];
  history?: Array<{ role: 'user' | 'assistant'; content: string; attachments?: unknown[] }>;
  model?: string;
  webSearch?: boolean;
  memories?: Memory[];
  memoryEnabled?: boolean;
  autoMemory?: boolean;
  replaceMessageIds?: string[];
  persistUserMessage?: boolean;
  /**
   * Id the client assigned to the outgoing user message. The server reuses it
   * when persisting so the client store and the database agree on identity,
   * which is what makes `replaceMessageIds` (edit) reliable.
   */
  userMessageId?: string;
}

export interface StreamCallbacks {
  /** Called with every text delta, batched to animation frames. */
  onDelta?: (text: string) => void;
  /** Called for every non-text event (start, sources, title, done, error...). */
  onEvent?: (event: ChatStreamEvent) => void;
  signal?: AbortSignal;
}

/**
 * Consume the server-sent event stream produced by `POST /api/chat`.
 *
 * Text deltas are coalesced into animation frames so a fast model does not
 * force a React re-render for every token.
 */
export async function streamChat(
  payload: ChatRequestPayload,
  callbacks: StreamCallbacks = {},
): Promise<void> {
  const headers = await buildHeaders();
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
    signal: callbacks.signal,
    cache: 'no-store',
  });

  if (!response.ok || !response.body) {
    let message = `The request failed (${response.status}).`;
    let code = 'error';
    let retryable = false;
    try {
      const payloadError = (await response.json()) as {
        error?: string;
        code?: string;
        retryable?: boolean;
      };
      if (payloadError?.error) message = payloadError.error;
      if (payloadError?.code) code = payloadError.code;
      if (typeof payloadError?.retryable === 'boolean') retryable = payloadError.retryable;
    } catch {
      /* keep the default message */
    }
    throw new ApiError(message, response.status, code, retryable);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let pending = '';

  const flush = () => {
    if (!pending) return;
    const text = pending;
    pending = '';
    callbacks.onDelta?.(text);
  };

  let scheduled = false;
  const scheduleFlush = () => {
    if (scheduled) return;
    scheduled = true;
    const run = () => {
      scheduled = false;
      flush();
    };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(run);
    else setTimeout(run, 24);
  };

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let boundary = buffer.indexOf('\n\n');
      while (boundary !== -1) {
        const frame = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);

        for (const rawLine of frame.split('\n')) {
          const line = rawLine.trimEnd();
          if (!line.startsWith('data:')) continue;
          const body = line.slice(5).trim();
          if (!body || body === '[DONE]') continue;

          let event: ChatStreamEvent;
          try {
            event = JSON.parse(body) as ChatStreamEvent;
          } catch {
            continue;
          }

          if (event.type === 'delta') {
            pending += event.text;
            scheduleFlush();
          } else {
            flush();
            callbacks.onEvent?.(event);
          }
        }

        boundary = buffer.indexOf('\n\n');
      }
    }
    flush();
  } finally {
    try {
      await reader.cancel();
    } catch {
      /* the stream is already closed */
    }
  }
}
