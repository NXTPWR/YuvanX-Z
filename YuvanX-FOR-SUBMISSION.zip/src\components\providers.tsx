'use client';

import { useEffect, useRef, type ReactNode } from 'react';
import { useSettingsStore } from '@/lib/store/settings';
import { useAuthStore } from '@/lib/store/auth';
import { ToastProvider } from '@/components/ui/toast';

function applyTheme(theme: 'light' | 'dark' | 'system') {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const dark = theme === 'system' ? prefersDark : theme === 'dark';
  root.classList.toggle('dark', dark);
  root.style.colorScheme = dark ? 'dark' : 'light';
}

const FONT_SCALE: Record<string, string> = {
  sm: '15px',
  md: '16px',
  lg: '17.5px',
  xl: '19px',
};

/**
 * Applies the user's appearance preferences to the document root and boots
 * the authentication session.
 */
export function Providers({ children }: { children: ReactNode }) {
  const theme = useSettingsStore((state) => state.theme);
  const accent = useSettingsStore((state) => state.accent);
  const fontScale = useSettingsStore((state) => state.fontScale);
  const animation = useSettingsStore((state) => state.animation);
  const reducedMotion = useSettingsStore((state) => state.reducedMotion);
  const initAuth = useAuthStore((state) => state.init);
  const booted = useRef(false);

  useEffect(() => {
    if (booted.current) return;
    booted.current = true;
    void initAuth();
  }, [initAuth]);

  /* Theme --------------------------------------------------------------- */
  useEffect(() => {
    applyTheme(theme);
    if (theme !== 'system' || typeof window === 'undefined') return;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = () => applyTheme('system');
    media.addEventListener('change', onChange);
    return () => media.removeEventListener('change', onChange);
  }, [theme]);

  /* Accent -------------------------------------------------------------- */
  useEffect(() => {
    if (typeof document === 'undefined') return;
    document.documentElement.setAttribute('data-accent', accent);
  }, [accent]);

  /* Font scale ---------------------------------------------------------- */
  useEffect(() => {
    if (typeof document === 'undefined') return;
    document.documentElement.style.fontSize = FONT_SCALE[fontScale] ?? '16px';
  }, [fontScale]);

  /* Motion -------------------------------------------------------------- */
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    const systemReduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (reducedMotion || systemReduced) {
      root.setAttribute('data-motion', 'off');
      return;
    }
    root.setAttribute('data-motion', animation === 'full' ? 'full' : animation);
  }, [animation, reducedMotion]);

  return (
    <ToastProvider>
      <div className="flex min-h-dvh flex-col">{children}</div>
    </ToastProvider>
  );
}
