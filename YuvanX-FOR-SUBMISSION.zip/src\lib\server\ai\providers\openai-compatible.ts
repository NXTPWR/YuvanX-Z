import { getFallbackProviderConfig } from '@/lib/server/env';
import {
  AIProviderError,
  type AIProvider,
  type ProviderCallbacks,
  type ProviderRequest,
  type ProviderResult,
} from '@/lib/server/ai/types';

/**
 * Secondary provider adapter.
 *
 * Talks to any OpenAI-compatible `/chat/completions` endpoint. It is used only
 * as a failover for plain-text requests: attachments and web-search grounding
 * are Gemini-specific and are never faked here.
 */
export const openAICompatibleProvider: AIProvider = {
  id: 'openai-compatible',
  label: 'OpenAI-compatible fallback',
  supportsAttachments: false,
  supportsSearch: false,

  async stream(
    request: ProviderRequest,
    callbacks: ProviderCallbacks,
  ): Promise<ProviderResult> {
    const config = getFallbackProviderConfig();
    if (!config) {
      throw new AIProviderError('unavailable', 'No fallback provider is configured.', false);
    }

    if (request.turns.some((turn) => (turn.attachments ?? []).length > 0)) {
      throw new AIProviderError(
        'invalid_request',
        'The fallback provider cannot analyse attachments.',
        false,
      );
    }
    if (request.webSearch) {
      throw new AIProviderError(
        'invalid_request',
        'The fallback provider does not support web search.',
        false,
      );
    }

    const messages = [
      { role: 'system', content: request.system },
      ...request.turns.map((turn) => ({ role: turn.role, content: turn.content })),
    ];

    const timeoutController = new AbortController();
    // Groq-friendly default, tightened by the caller. A fallback exists to be
    // fast, so waiting anywhere near the Gemini timeout defeats the purpose.
    const timeoutMs = Math.min(request.timeoutMs || 90_000, 60_000);
    const timer = setTimeout(() => timeoutController.abort(), timeoutMs);
    const signal = AbortSignal.any([request.signal, timeoutController.signal]);

    try {
      const response = await fetch(`${config.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({
          model: config.model,
          messages,
          stream: true,
          max_tokens: request.maxOutputTokens,
        }),
        signal,
        cache: 'no-store',
      });

      if (!response.ok || !response.body) {
        const body = await response.text().catch(() => '');
        const status = response.status;
        if (status === 401 || status === 403) {
          throw new AIProviderError('auth', 'The fallback provider rejected the API key.', false, status);
        }
        if (status === 429) {
          throw new AIProviderError('rate_limit', 'The fallback provider is rate limited.', true, status);
        }
        if (status >= 500) {
          throw new AIProviderError('unavailable', 'The fallback provider is unavailable.', true, status);
        }
        throw new AIProviderError('invalid_request', body || 'Fallback request failed.', false, status);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let text = '';

      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        buffer = buffer.replace(/\r\n/g, '\n');
        let index = buffer.indexOf('\n\n');
        while (index !== -1) {
          const raw = buffer.slice(0, index);
          buffer = buffer.slice(index + 2);
          const payload = extractContent(raw);
          if (payload) {
            text += payload;
            callbacks.onText(payload);
          }
          index = buffer.indexOf('\n\n');
        }
      }

      return { text, sources: [], model: config.model, searchQueries: [] };
    } catch (error) {
      if (error instanceof AIProviderError) throw error;
      if (request.signal.aborted) {
        throw new AIProviderError('aborted', 'The request was cancelled.', false);
      }
      if (timeoutController.signal.aborted) {
        throw new AIProviderError('timeout', 'The fallback provider timed out.', true);
      }
      throw new AIProviderError(
        'unavailable',
        error instanceof Error ? error.message : 'Fallback provider network error.',
        true,
      );
    } finally {
      clearTimeout(timer);
    }
  },
};

function extractContent(raw: string): string | null {
  let payload = '';
  for (const line of raw.split('\n')) {
    if (line.startsWith('data:')) payload += line.slice(5).trim();
  }
  if (!payload || payload === '[DONE]') return null;
  try {
    const parsed = JSON.parse(payload) as {
      choices?: Array<{ delta?: { content?: string } }>;
    };
    return parsed.choices?.[0]?.delta?.content ?? null;
  } catch {
    return null;
  }
}
