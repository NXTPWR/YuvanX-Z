import { NextResponse } from 'next/server';
import { getSupabaseConfig } from '@/lib/server/env';
import { getAuthClient, getServiceClient, readJsonBody } from '@/lib/server/supabase';
import { checkRateLimit } from '@/lib/server/rate-limit';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * Account creation.
 *
 * Supabase projects ship with "Confirm email" switched on, which means a new
 * account cannot sign in until it clicks a link that arrives by email. Most
 * self-hosted deployments have no working SMTP provider, so that link never
 * arrives and accounts look broken.
 *
 * This route creates the account through the Admin API with the address
 * already confirmed, then signs the user in and hands the browser a ready
 * session. Set `SUPABASE_AUTO_CONFIRM=false` to fall back to Supabase's own
 * confirmation flow (use this once a real SMTP provider is configured).
 */

const SIGNUP_LIMIT = 5;
const SIGNUP_WINDOW_MS = 60 * 60 * 1000;
const MIN_PASSWORD_LENGTH = 8;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

interface SignupBody {
  email?: string;
  password?: string;
}

export async function POST(request: Request) {
  const config = getSupabaseConfig();
  if (!config?.serviceRoleKey) {
    return NextResponse.json(
      { error: 'Accounts are not enabled on this deployment.', code: 'not_configured' },
      { status: 404 },
    );
  }

  const body = await readJsonBody<SignupBody>(request, 4096);
  const email = (body?.email ?? '').trim().toLowerCase();
  const password = body?.password ?? '';

  if (!EMAIL_PATTERN.test(email)) {
    return NextResponse.json({ error: 'Enter a valid email address.' }, { status: 400 });
  }
  if (password.length < MIN_PASSWORD_LENGTH) {
    return NextResponse.json(
      { error: `Use a password of at least ${MIN_PASSWORD_LENGTH} characters.` },
      { status: 400 },
    );
  }

  const clientId = request.headers.get('x-yuvanx-client') ?? 'anonymous';
  const limit = checkRateLimit(`signup:${clientId}`, SIGNUP_LIMIT, SIGNUP_WINDOW_MS);
  if (!limit.allowed) {
    return NextResponse.json(
      { error: 'Too many sign-up attempts from this browser. Please try again later.' },
      { status: 429 },
    );
  }

  const service = getServiceClient();
  if (!service) {
    return NextResponse.json(
      { error: 'Accounts are not enabled on this deployment.', code: 'not_configured' },
      { status: 404 },
    );
  }

  const { error: createError } = await service.auth.admin.createUser({
    email,
    password,
    email_confirm: config.autoConfirmSignup,
  });

  if (createError) {
    const message = createError.message.toLowerCase();
    if (
      message.includes('already') ||
      message.includes('registered') ||
      message.includes('exists')
    ) {
      return NextResponse.json(
        { error: 'An account already exists for that email. Try signing in instead.' },
        { status: 409 },
      );
    }
    return NextResponse.json(
      { error: 'Could not create that account. Please try again.' },
      { status: 400 },
    );
  }

  if (!config.autoConfirmSignup) {
    // The deployment asked for the standard Supabase flow: the user has to
    // confirm the address by email before they can sign in.
    return NextResponse.json({ needsEmailConfirmation: true });
  }

  const auth = getAuthClient();
  if (!auth) {
    return NextResponse.json(
      { error: 'Accounts are not enabled on this deployment.', code: 'not_configured' },
      { status: 404 },
    );
  }

  const { data, error: signInError } = await auth.auth.signInWithPassword({ email, password });
  if (signInError || !data.session) {
    return NextResponse.json(
      { error: 'Account created, but signing in failed. Please sign in with your new password.' },
      { status: 500 },
    );
  }

  const session = data.session;
  return NextResponse.json({
    session: {
      access_token: session.access_token,
      refresh_token: session.refresh_token,
      expires_in: session.expires_in,
      expires_at: session.expires_at,
      token_type: session.token_type,
      user: session.user,
    },
  });
}
