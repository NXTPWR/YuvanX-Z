'use client';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { createPortal } from 'react-dom';
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useHydrated } from '@/lib/use-hydrated';

export type ToastTone = 'success' | 'error' | 'info';

export interface ToastItem {
  id: string;
  tone: ToastTone;
  message: string;
}

interface ToastApi {
  toast: (message: string, tone?: ToastTone) => void;
  success: (message: string) => void;
  error: (message: string) => void;
  info: (message: string) => void;
}

const ToastContext = createContext<ToastApi | null>(null);

export function useToast(): ToastApi {
  const context = useContext(ToastContext);
  if (!context) {
    // Safe fallback so components never crash outside the provider.
    return {
      toast: () => undefined,
      success: () => undefined,
      error: () => undefined,
      info: () => undefined,
    };
  }
  return context;
}

const TONE_STYLES: Record<ToastTone, { border: string; icon: ReactNode }> = {
  success: {
    border: 'border-[rgb(var(--success)/0.35)]',
    icon: <CheckCircle2 size={16} className="text-success" />,
  },
  error: {
    border: 'border-[rgb(var(--danger)/0.4)]',
    icon: <AlertCircle size={16} className="text-danger" />,
  },
  info: {
    border: 'border-[rgb(var(--accent)/0.35)]',
    icon: <Info size={16} className="text-accent" />,
  },
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const timers = useRef(new Map<string, number>());
  const hydrated = useHydrated();

  const dismiss = useCallback((id: string) => {
    setItems((current) => current.filter((item) => item.id !== id));
    const timer = timers.current.get(id);
    if (timer) {
      window.clearTimeout(timer);
      timers.current.delete(id);
    }
  }, []);

  const toast = useCallback(
    (message: string, tone: ToastTone = 'info') => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      setItems((current) => [...current.slice(-3), { id, tone, message }]);
      const timer = window.setTimeout(() => dismiss(id), tone === 'error' ? 7000 : 4200);
      timers.current.set(id, timer);
    },
    [dismiss],
  );

  useEffect(() => {
    const map = timers.current;
    return () => {
      map.forEach((timer) => window.clearTimeout(timer));
      map.clear();
    };
  }, []);

  const api = useMemo<ToastApi>(
    () => ({
      toast,
      success: (message: string) => toast(message, 'success'),
      error: (message: string) => toast(message, 'error'),
      info: (message: string) => toast(message, 'info'),
    }),
    [toast],
  );

  return (
    <ToastContext.Provider value={api}>
      {children}
      {hydrated
        ? createPortal(
            <div
              className="pointer-events-none fixed inset-x-0 bottom-4 z-[200] flex flex-col items-center gap-2 px-4 sm:bottom-6"
              role="status"
              aria-live="polite"
            >
              {items.map((item) => (
                <div
                  key={item.id}
                  className={cn(
                    'glass-strong shadow-lifted pointer-events-auto flex max-w-md items-start gap-2.5',
                    'animate-fade-up rounded-[var(--radius-md)] border px-3.5 py-2.5 text-sm',
                    TONE_STYLES[item.tone].border,
                  )}
                >
                  <span className="mt-0.5 shrink-0">{TONE_STYLES[item.tone].icon}</span>
                  <span className="text-ink leading-snug">{item.message}</span>
                  <button
                    type="button"
                    aria-label="Dismiss notification"
                    onClick={() => dismiss(item.id)}
                    className="-mr-1 ml-1 shrink-0 rounded p-0.5 text-subtle transition-colors hover:text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                  >
                    <X size={13} />
                  </button>
                </div>
              ))}
            </div>,
            document.body,
          )
        : null}
    </ToastContext.Provider>
  );
}
