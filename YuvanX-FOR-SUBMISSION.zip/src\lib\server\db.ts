import type {
  AttachmentMeta,
  Conversation,
  Memory,
  MemoryCategory,
  Message,
  Source,
} from '@/lib/types';
import { getServiceClient } from '@/lib/server/supabase';

/**
 * Server-side persistence for authenticated users.
 *
 * Every query is explicitly scoped by `user_id` — the service-role key
 * bypasses RLS, so ownership is enforced here in addition to the row level
 * security policies in supabase/schema.sql.
 */

function nowIso(): string {
  return new Date().toISOString();
}

interface ConversationRow {
  id: string;
  title: string;
  auto_title: boolean;
  pinned: boolean;
  archived: boolean;
  saved: boolean;
  model: string | null;
  created_at: string;
  updated_at: string;
}

interface MessageRow {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant';
  content: string;
  attachments: AttachmentMeta[] | null;
  sources: Source[] | null;
  status: string;
  error: string | null;
  model: string | null;
  created_at: string;
}

interface MemoryRow {
  id: string;
  content: string;
  category: string;
  source: string;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

interface AttachmentRow {
  id: string;
  name: string;
  mime_type: string;
  size: number;
  kind: string;
  analyzable: boolean;
  note: string | null;
  storage_key: string | null;
  extracted_text: string | null;
}

function mapConversation(row: ConversationRow): Conversation {
  return {
    id: row.id,
    title: row.title,
    autoTitle: row.auto_title,
    pinned: row.pinned,
    archived: row.archived,
    saved: row.saved,
    model: row.model ?? undefined,
    createdAt: new Date(row.created_at).getTime(),
    updatedAt: new Date(row.updated_at).getTime(),
  };
}

function mapMessage(row: MessageRow): Message {
  return {
    id: row.id,
    conversationId: row.conversation_id,
    role: row.role,
    content: row.content,
    attachments: Array.isArray(row.attachments) ? row.attachments : [],
    sources: Array.isArray(row.sources) ? row.sources : [],
    status: (row.status as Message['status']) ?? 'complete',
    error: row.error ?? undefined,
    model: row.model ?? undefined,
    createdAt: new Date(row.created_at).getTime(),
  };
}

function mapMemory(row: MemoryRow): Memory {
  return {
    id: row.id,
    content: row.content,
    category: (row.category as MemoryCategory) ?? 'note',
    source: (row.source as Memory['source']) ?? 'manual',
    enabled: row.enabled,
    createdAt: new Date(row.created_at).getTime(),
    updatedAt: new Date(row.updated_at).getTime(),
  };
}

function mapAttachment(row: AttachmentRow): AttachmentMeta {
  return {
    id: row.id,
    name: row.name,
    mimeType: row.mime_type,
    size: Number(row.size),
    kind: row.kind as AttachmentMeta['kind'],
    analyzable: row.analyzable,
    note: row.note ?? undefined,
    storageKey: row.storage_key ?? undefined,
    text: row.extracted_text ?? undefined,
  };
}

/* -------------------------------------------------------------------------- */
/* Conversations                                                                */
/* -------------------------------------------------------------------------- */

export async function listConversations(
  userId: string,
  options: { archived?: boolean; limit?: number } = {},
): Promise<Conversation[]> {
  const client = getServiceClient();
  if (!client) return [];
  let query = client
    .from('conversations')
    .select('*')
    .eq('user_id', userId)
    .order('pinned', { ascending: false })
    .order('updated_at', { ascending: false });
  if (options.archived !== undefined) query = query.eq('archived', options.archived);
  if (options.limit) query = query.limit(options.limit);
  const { data, error } = await query;
  if (error) throw new Error(error.message);
  return (data as ConversationRow[]).map(mapConversation);
}

export async function getConversation(
  userId: string,
  conversationId: string,
): Promise<Conversation | null> {
  const client = getServiceClient();
  if (!client) return null;
  const { data, error } = await client
    .from('conversations')
    .select('*')
    .eq('id', conversationId)
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data ? mapConversation(data as ConversationRow) : null;
}

export async function createConversation(
  userId: string,
  data: Partial<Conversation> = {},
): Promise<Conversation> {
  const client = getServiceClient();
  if (!client) throw new Error('Persistence is not configured.');
  const timestamp = nowIso();
  const { data: row, error } = await client
    .from('conversations')
    .insert({
      user_id: userId,
      title: data.title ?? 'New chat',
      auto_title: data.autoTitle ?? false,
      pinned: data.pinned ?? false,
      archived: data.archived ?? false,
      saved: data.saved ?? false,
      model: data.model ?? null,
      created_at: timestamp,
      updated_at: timestamp,
    })
    .select('*')
    .single();
  if (error) throw new Error(error.message);
  return mapConversation(row as ConversationRow);
}

export async function updateConversation(
  userId: string,
  conversationId: string,
  patch: Partial<
    Pick<Conversation, 'title' | 'pinned' | 'archived' | 'saved' | 'autoTitle' | 'model'>
  >,
): Promise<Conversation | null> {
  const client = getServiceClient();
  if (!client) return null;
  const update: Record<string, unknown> = { updated_at: nowIso() };
  if (patch.title !== undefined) update.title = patch.title;
  if (patch.pinned !== undefined) update.pinned = patch.pinned;
  if (patch.archived !== undefined) update.archived = patch.archived;
  if (patch.saved !== undefined) update.saved = patch.saved;
  if (patch.autoTitle !== undefined) update.auto_title = patch.autoTitle;
  if (patch.model !== undefined) update.model = patch.model;
  const { data, error } = await client
    .from('conversations')
    .update(update)
    .eq('id', conversationId)
    .eq('user_id', userId)
    .select('*')
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data ? mapConversation(data as ConversationRow) : null;
}

/** Bump the updated_at timestamp so the chat moves to the top of the list. */
export async function touchConversation(userId: string, conversationId: string): Promise<void> {
  const client = getServiceClient();
  if (!client) return;
  await client
    .from('conversations')
    .update({ updated_at: nowIso() })
    .eq('id', conversationId)
    .eq('user_id', userId);
}

export async function deleteConversation(userId: string, conversationId: string): Promise<boolean> {
  const client = getServiceClient();
  if (!client) return false;
  const { error } = await client
    .from('conversations')
    .delete()
    .eq('id', conversationId)
    .eq('user_id', userId);
  if (error) throw new Error(error.message);
  return true;
}

/* -------------------------------------------------------------------------- */
/* Messages                                                                     */
/* -------------------------------------------------------------------------- */

export async function listMessages(
  userId: string,
  conversationId: string,
): Promise<Message[]> {
  const client = getServiceClient();
  if (!client) return [];
  const { data, error } = await client
    .from('messages')
    .select('*')
    .eq('conversation_id', conversationId)
    .eq('user_id', userId)
    .order('created_at', { ascending: true });
  if (error) throw new Error(error.message);
  return (data as MessageRow[]).map(mapMessage);
}

export async function addMessage(
  userId: string,
  conversationId: string,
  message: Omit<Message, 'conversationId' | 'createdAt'> & { createdAt?: number },
): Promise<Message> {
  const client = getServiceClient();
  if (!client) throw new Error('Persistence is not configured.');
  const createdAt = message.createdAt ? new Date(message.createdAt).toISOString() : nowIso();
  const { data, error } = await client
    .from('messages')
    .insert({
      id: message.id,
      conversation_id: conversationId,
      user_id: userId,
      role: message.role,
      content: message.content,
      attachments: message.attachments ?? [],
      sources: message.sources ?? [],
      status: message.status ?? 'complete',
      error: message.error ?? null,
      model: message.model ?? null,
      created_at: createdAt,
    })
    .select('*')
    .single();
  if (error) throw new Error(error.message);
  await touchConversation(userId, conversationId);
  return mapMessage(data as MessageRow);
}

export async function updateMessage(
  userId: string,
  messageId: string,
  patch: Partial<Pick<Message, 'content' | 'status' | 'error' | 'sources'>>,
): Promise<void> {
  const client = getServiceClient();
  if (!client) return;
  const update: Record<string, unknown> = {};
  if (patch.content !== undefined) update.content = patch.content;
  if (patch.status !== undefined) update.status = patch.status;
  if (patch.error !== undefined) update.error = patch.error;
  if (patch.sources !== undefined) update.sources = patch.sources;
  if (Object.keys(update).length === 0) return;
  await client.from('messages').update(update).eq('id', messageId).eq('user_id', userId);
}

/** Remove a message and every message after it (used by edit + resend). */
export async function deleteMessagesAfter(
  userId: string,
  conversationId: string,
  beforeTimestamp: number,
): Promise<void> {
  const client = getServiceClient();
  if (!client) return;
  await client
    .from('messages')
    .delete()
    .eq('conversation_id', conversationId)
    .eq('user_id', userId)
    .gt('created_at', new Date(beforeTimestamp).toISOString());
}

/** Delete a specific set of messages belonging to the user. */
export async function deleteMessagesById(userId: string, messageIds: string[]): Promise<void> {
  const client = getServiceClient();
  if (!client || messageIds.length === 0) return;
  await client
    .from('messages')
    .delete()
    .eq('user_id', userId)
    .in('id', messageIds);
}

/* -------------------------------------------------------------------------- */
/* Memories                                                                     */
/* -------------------------------------------------------------------------- */

export async function listMemories(userId: string): Promise<Memory[]> {
  const client = getServiceClient();
  if (!client) return [];
  const { data, error } = await client
    .from('memories')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data as MemoryRow[]).map(mapMemory);
}

export async function createMemory(
  userId: string,
  data: { content: string; category?: MemoryCategory; source?: Memory['source']; enabled?: boolean },
): Promise<Memory> {
  const client = getServiceClient();
  if (!client) throw new Error('Persistence is not configured.');
  const timestamp = nowIso();
  const { data: row, error } = await client
    .from('memories')
    .insert({
      user_id: userId,
      content: data.content,
      category: data.category ?? 'note',
      source: data.source ?? 'manual',
      enabled: data.enabled ?? true,
      created_at: timestamp,
      updated_at: timestamp,
    })
    .select('*')
    .single();
  if (error) throw new Error(error.message);
  return mapMemory(row as MemoryRow);
}

export async function updateMemory(
  userId: string,
  memoryId: string,
  patch: Partial<Pick<Memory, 'content' | 'category' | 'enabled'>>,
): Promise<Memory | null> {
  const client = getServiceClient();
  if (!client) return null;
  const update: Record<string, unknown> = { updated_at: nowIso() };
  if (patch.content !== undefined) update.content = patch.content;
  if (patch.category !== undefined) update.category = patch.category;
  if (patch.enabled !== undefined) update.enabled = patch.enabled;
  const { data, error } = await client
    .from('memories')
    .update(update)
    .eq('id', memoryId)
    .eq('user_id', userId)
    .select('*')
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data ? mapMemory(data as MemoryRow) : null;
}

export async function deleteMemory(userId: string, memoryId: string): Promise<boolean> {
  const client = getServiceClient();
  if (!client) return false;
  const { error } = await client.from('memories').delete().eq('id', memoryId).eq('user_id', userId);
  if (error) throw new Error(error.message);
  return true;
}

export async function clearMemories(userId: string): Promise<void> {
  const client = getServiceClient();
  if (!client) return;
  const { error } = await client.from('memories').delete().eq('user_id', userId);
  if (error) throw new Error(error.message);
}

/* -------------------------------------------------------------------------- */
/* Attachments                                                                  */
/* -------------------------------------------------------------------------- */

export async function createAttachmentRecord(
  userId: string,
  data: Omit<AttachmentMeta, 'id'> & { id?: string; conversationId?: string | null },
): Promise<AttachmentMeta> {
  const client = getServiceClient();
  if (!client) throw new Error('Persistence is not configured.');
  const { data: row, error } = await client
    .from('attachments')
    .insert({
      id: data.id,
      user_id: userId,
      conversation_id: data.conversationId ?? null,
      name: data.name,
      mime_type: data.mimeType,
      size: data.size,
      kind: data.kind,
      analyzable: data.analyzable,
      note: data.note ?? null,
      storage_key: data.storageKey ?? null,
      extracted_text: data.text ?? null,
    })
    .select('*')
    .single();
  if (error) throw new Error(error.message);
  return mapAttachment(row as unknown as AttachmentRow);
}

export async function getAttachmentRecord(
  userId: string,
  attachmentId: string,
): Promise<AttachmentMeta | null> {
  const client = getServiceClient();
  if (!client) return null;
  const { data, error } = await client
    .from('attachments')
    .select('*')
    .eq('id', attachmentId)
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data ? mapAttachment(data as AttachmentRow) : null;
}

export async function listAttachmentRecords(
  userId: string,
  conversationId: string,
): Promise<AttachmentMeta[]> {
  const client = getServiceClient();
  if (!client) return [];
  const { data, error } = await client
    .from('attachments')
    .select('*')
    .eq('conversation_id', conversationId)
    .eq('user_id', userId)
    .order('created_at', { ascending: true });
  if (error) throw new Error(error.message);
  return (data as AttachmentRow[]).map(mapAttachment);
}

/* -------------------------------------------------------------------------- */
/* Profiles                                                                     */
/* -------------------------------------------------------------------------- */

export async function getProfile(
  userId: string,
): Promise<{ email: string | null; displayName: string | null; settings: unknown } | null> {
  const client = getServiceClient();
  if (!client) return null;
  const { data, error } = await client
    .from('profiles')
    .select('email, display_name, settings')
    .eq('id', userId)
    .maybeSingle();
  if (error) return null;
  const row = data as { email: string | null; display_name: string | null; settings: unknown } | null;
  if (!row) return null;
  return { email: row.email, displayName: row.display_name, settings: row.settings };
}

export async function saveProfileSettings(
  userId: string,
  settings: Record<string, unknown>,
): Promise<void> {
  const client = getServiceClient();
  if (!client) return;
  await client
    .from('profiles')
    .upsert({ id: userId, settings, updated_at: nowIso() }, { onConflict: 'id' })
    .select('id')
    .maybeSingle();
}

/* -------------------------------------------------------------------------- */
/* Private usage accounting                                                    */
/* -------------------------------------------------------------------------- */

export async function getDailyUsage(
  userId: string,
): Promise<{ requests: number; inputTokens: number; outputTokens: number }> {
  const client = getServiceClient();
  if (!client) return { requests: 0, inputTokens: 0, outputTokens: 0 };
  const day = new Date().toISOString().slice(0, 10);
  const { data } = await client
    .from('usage_daily')
    .select('requests, input_tokens, output_tokens')
    .eq('user_id', userId)
    .eq('day', day)
    .maybeSingle();
  if (!data) return { requests: 0, inputTokens: 0, outputTokens: 0 };
  const row = data as { requests: number; input_tokens: number; output_tokens: number };
  return {
    requests: Number(row.requests ?? 0),
    inputTokens: Number(row.input_tokens ?? 0),
    outputTokens: Number(row.output_tokens ?? 0),
  };
}

export async function incrementDailyUsage(
  userId: string,
  tokens: { inputTokens?: number; outputTokens?: number } = {},
): Promise<void> {
  const client = getServiceClient();
  if (!client) return;
  const day = new Date().toISOString().slice(0, 10);
  const { error } = await client.rpc('increment_usage', {
    p_user_id: userId,
    p_day: day,
    p_requests: 1,
    p_input_tokens: tokens.inputTokens ?? 0,
    p_output_tokens: tokens.outputTokens ?? 0,
  });
  if (error) {
    // The RPC is optional — fall back to a read-modify-write upsert.
    const { data: existing } = await client
      .from('usage_daily')
      .select('requests, input_tokens, output_tokens')
      .eq('user_id', userId)
      .eq('day', day)
      .maybeSingle();
    const current = (existing as
      | { requests: number; input_tokens: number; output_tokens: number }
      | null) ?? { requests: 0, input_tokens: 0, output_tokens: 0 };
    await client.from('usage_daily').upsert({
      user_id: userId,
      day,
      requests: Number(current.requests ?? 0) + 1,
      input_tokens: Number(current.input_tokens ?? 0) + (tokens.inputTokens ?? 0),
      output_tokens: Number(current.output_tokens ?? 0) + (tokens.outputTokens ?? 0),
    });
  }
}
