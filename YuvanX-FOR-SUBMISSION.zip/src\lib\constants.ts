/** Product-level constants: models, prompts, accents and supported files. */

export interface ModelOption {
  id: string;
  name: string;
  description: string;
  badge?: string;
}

/**
 * Currently supported Gemini models. Keep this list in sync with
 * https://ai.google.dev/gemini-api/docs/models
 */
export const MODELS: ModelOption[] = [
  {
    id: 'gemini-3.8-flash',
    name: 'YuvanX Flash',
    description: 'Fast, capable and cost-efficient. Great for everyday work.',
    badge: 'Recommended',
  },
  {
    id: 'gemini-3.6-flash',
    name: 'YuvanX Swift',
    description: 'Previous-generation Flash model — very stable and quick.',
  },
  {
    id: 'gemini-3.5-flash-lite',
    name: 'YuvanX Lite',
    description: 'Fastest and cheapest option for simple tasks.',
  },
];

export const DEFAULT_MODEL = 'gemini-3.8-flash';

export function modelLabel(id: string): string {
  return MODELS.find((m) => m.id === id)?.name ?? id;
}

/**
 * The model's real provider name, shown beneath the friendly label so the
 * choice is honest about what is actually answering.
 */
export function modelRealName(id: string): string | null {
  return MODELS.some((m) => m.id === id) ? id : null;
}

export interface SuggestedPrompt {
  label: string;
  prompt: string;
  category: 'coding' | 'research' | 'learning' | 'writing' | 'brainstorm';
}

export const SUGGESTED_PROMPTS: SuggestedPrompt[] = [
  {
    label: 'Debug this function',
    category: 'coding',
    prompt:
      'I have a function that throws an unexpected error. Here is the code:\n\n```js\n// paste your code\n```\n\nExplain what is wrong and give me a corrected version.',
  },
  {
    label: 'Research a topic',
    category: 'research',
    prompt:
      'Give me a thorough, well-structured briefing on the current state of solid-state battery technology. Cover the main chemistry approaches, what is actually shipping today, and the biggest unsolved problems. Include citations for the key claims.',
  },
  {
    label: 'Explain quantum computing',
    category: 'learning',
    prompt:
      'Explain quantum computing to me as if I am a curious software engineer. Use one concrete analogy, then walk through a small worked example, and finish with what it is genuinely good and bad at.',
  },
  {
    label: 'Write a launch announcement',
    category: 'writing',
    prompt:
      'Write a launch announcement for a small developer tool called "Ember" that turns a messy CSV into a clean, documented API. Keep it under 200 words, confident but not hype-driven, and end with a single clear call to action.',
  },
  {
    label: 'Brainstorm side projects',
    category: 'brainstorm',
    prompt:
      'Brainstorm ten side projects I could build with the APIs I already know (Python, TypeScript, Postgres). For each: what it does, who it is for, and an honest difficulty rating out of 5.',
  },
];

export interface AccentOption {
  id: 'aurora' | 'violet' | 'cyan' | 'ember' | 'mint';
  name: string;
  /** rgb triplet used to build the CSS accent variables. */
  rgb: [number, number, number];
}

export const ACCENTS: AccentOption[] = [
  { id: 'aurora', name: 'Aurora', rgb: [124, 138, 255] },
  { id: 'violet', name: 'Violet', rgb: [167, 116, 255] },
  { id: 'cyan', name: 'Cyan', rgb: [56, 189, 248] },
  { id: 'ember', name: 'Ember', rgb: [251, 146, 60] },
  { id: 'mint', name: 'Mint', rgb: [52, 211, 153] },
];

export interface FileTypeSpec {
  /** Comma separated accept attribute. */
  accept: string;
  extensions: string[];
  label: string;
  kind: 'image' | 'pdf' | 'text' | 'markdown' | 'code' | 'csv' | 'docx' | 'xlsx';
}

export const SUPPORTED_FILES: FileTypeSpec[] = [
  {
    accept: 'image/png,image/jpeg,image/webp',
    extensions: ['.png', '.jpg', '.jpeg', '.webp'],
    label: 'Images (PNG, JPG, WEBP)',
    kind: 'image',
  },
  {
    accept: 'application/pdf',
    extensions: ['.pdf'],
    label: 'PDF documents',
    kind: 'pdf',
  },
  {
    accept: 'text/plain,text/markdown',
    extensions: ['.txt', '.md'],
    label: 'Text & Markdown',
    kind: 'text',
  },
  {
    accept: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    extensions: ['.docx'],
    label: 'Word documents',
    kind: 'docx',
  },
  {
    accept: 'text/csv',
    extensions: ['.csv'],
    label: 'CSV spreadsheets',
    kind: 'csv',
  },
  {
    accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    extensions: ['.xlsx'],
    label: 'Excel spreadsheets',
    kind: 'xlsx',
  },
  {
    accept:
      '.js,.jsx,.ts,.tsx,.py,.java,.go,.rs,.rb,.php,.c,.h,.cpp,.cs,.swift,.kt,.html,.css,.scss,.json,.yaml,.yml,.xml,.sql,.sh,.toml,.ini',
    extensions: [
      '.js',
      '.jsx',
      '.ts',
      '.tsx',
      '.py',
      '.java',
      '.go',
      '.rs',
      '.rb',
      '.php',
      '.c',
      '.h',
      '.cpp',
      '.cs',
      '.swift',
      '.kt',
      '.html',
      '.css',
      '.scss',
      '.json',
      '.yaml',
      '.yml',
      '.xml',
      '.sql',
      '.sh',
      '.toml',
      '.ini',
    ],
    label: 'Source code',
    kind: 'code',
  },
];

export const ACCEPT_ATTRIBUTE = SUPPORTED_FILES.map((f) => f.accept).join(',');

export const MAX_ATTACHMENTS = 5;
export const MAX_FILE_BYTES = 8 * 1024 * 1024; // 8 MB per file
export const MAX_TEXT_CHARS = 200_000; // extracted text budget per file
export const MAX_MESSAGE_CHARS = 32_000;
