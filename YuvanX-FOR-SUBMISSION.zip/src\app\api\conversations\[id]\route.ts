import { NextResponse } from 'next/server';
import { resolveIdentity } from '@/lib/server/supabase';
import {
  deleteConversation,
  getConversation,
  listMessages,
  updateConversation,
} from '@/lib/server/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Context = { params: Promise<{ id: string }> };

export async function GET(_request: Request, context: Context) {
  const identity = await resolveIdentity(_request);
  if (!identity.userId) {
    return NextResponse.json({ error: 'Not signed in.', code: 'unauthenticated' }, { status: 401 });
  }
  const { id } = await context.params;
  try {
    const conversation = await getConversation(identity.userId, id);
    if (!conversation) {
      return NextResponse.json({ error: 'Not found.', code: 'not_found' }, { status: 404 });
    }
    const messages = await listMessages(identity.userId, id);
    return NextResponse.json({ conversation, messages });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not load the conversation.' },
      { status: 500 },
    );
  }
}

export async function PATCH(request: Request, context: Context) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json({ error: 'Not signed in.', code: 'unauthenticated' }, { status: 401 });
  }
  const { id } = await context.params;
  const body = (await request.json().catch(() => ({}))) as {
    title?: string;
    pinned?: boolean;
    archived?: boolean;
    saved?: boolean;
    model?: string;
  };

  try {
    const conversation = await updateConversation(identity.userId, id, {
      title: body.title !== undefined ? body.title.slice(0, 120) : undefined,
      pinned: body.pinned,
      archived: body.archived,
      saved: body.saved,
      model: body.model,
    });
    if (!conversation) {
      return NextResponse.json({ error: 'Not found.', code: 'not_found' }, { status: 404 });
    }
    return NextResponse.json({ conversation });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not update the conversation.' },
      { status: 500 },
    );
  }
}

export async function DELETE(request: Request, context: Context) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json({ error: 'Not signed in.', code: 'unauthenticated' }, { status: 401 });
  }
  const { id } = await context.params;
  try {
    const existing = await getConversation(identity.userId, id);
    if (!existing) {
      return NextResponse.json({ error: 'Not found.', code: 'not_found' }, { status: 404 });
    }
    await deleteConversation(identity.userId, id);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not delete the conversation.' },
      { status: 500 },
    );
  }
}
