'use client';

import { useSyncExternalStore } from 'react';

const emptySubscribe = () => () => {};

/**
 * `false` while rendering on the server and during the very first client
 * render, `true` afterwards.
 *
 * `useSyncExternalStore` is used instead of a `useEffect` + `useState` pair
 * because it lets React render the server markup first and then re-render on
 * the client — which keeps hydration free of mismatches without triggering
 * a cascading render.
 */
export function useHydrated(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false,
  );
}
