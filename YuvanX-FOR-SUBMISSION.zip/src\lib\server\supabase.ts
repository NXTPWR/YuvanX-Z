import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { getSupabaseConfig } from '@/lib/server/env';

let serviceClient: SupabaseClient | null = null;
let anonClient: SupabaseClient | null = null;

/**
 * Service-role client. Server-only: it bypasses RLS and MUST only ever be
 * used together with an explicit ownership check.
 */
export function getServiceClient(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config?.serviceRoleKey) return null;
  if (!serviceClient) {
    serviceClient = createClient(config.url, config.serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
  }
  return serviceClient;
}

/** Anon client — used for verifying a user access token. */
export function getAuthClient(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config) return null;
  if (!anonClient) {
    anonClient = createClient(config.url, config.anonKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
  }
  return anonClient;
}

export interface Identity {
  /** Authenticated Supabase user id, or null in guest mode. */
  userId: string | null;
  email: string | null;
  name: string | null;
  /** Stable per-browser id used for guest-mode rate limiting. */
  clientId: string;
  isGuest: boolean;
}

function readClientId(request: Request): string {
  const header = request.headers.get('x-yuvanx-client');
  if (header && /^[a-zA-Z0-9_-]{8,64}$/.test(header)) return header;
  return 'anonymous';
}

/**
 * Resolve who is making the request.
 *
 * The user id is ALWAYS derived from a verified access token — it is never
 * read from a client-supplied field — so a user can never act on another
 * user's records.
 */
export async function resolveIdentity(request: Request): Promise<Identity> {
  const clientId = readClientId(request);
  const authorization = request.headers.get('authorization') ?? '';
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7).trim() : '';

  if (!token) {
    return { userId: null, email: null, name: null, clientId, isGuest: true };
  }

  const client = getAuthClient();
  if (!client) {
    return { userId: null, email: null, name: null, clientId, isGuest: true };
  }

  try {
    const { data, error } = await client.auth.getUser(token);
    if (error || !data?.user) {
      return { userId: null, email: null, name: null, clientId, isGuest: true };
    }
    const user = data.user;
    const name =
      (user.user_metadata?.full_name as string | undefined) ??
      (user.user_metadata?.name as string | undefined) ??
      (user.email ? user.email.split('@')[0] : null);
    return {
      userId: user.id,
      email: user.email ?? null,
      name: name ?? null,
      clientId,
      isGuest: false,
    };
  } catch {
    return { userId: null, email: null, name: null, clientId, isGuest: true };
  }
}

/** Parse a JSON body with a size guard, returning null when invalid. */
export async function readJsonBody<T>(request: Request, maxBytes = 8 * 1024 * 1024): Promise<T | null> {
  try {
    const text = await request.text();
    if (text.length > maxBytes) return null;
    if (!text.trim()) return null;
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}
