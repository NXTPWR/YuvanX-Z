-- ===========================================================================
-- YuvanX — Supabase schema
-- Run this in the Supabase SQL Editor (Dashboard → SQL → New query).
-- It is safe to run more than once (all statements are idempotent).
-- ===========================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- Profiles (one per authenticated user)
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id           uuid primary key references auth.users on delete cascade,
  email        text,
  display_name text,
  settings     jsonb not null default '{}'::jsonb,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Conversations
-- ---------------------------------------------------------------------------
create table if not exists public.conversations (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users on delete cascade,
  title      text not null default 'New chat',
  auto_title boolean not null default false,
  pinned     boolean not null default false,
  archived   boolean not null default false,
  saved      boolean not null default false,
  model      text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists conversations_user_updated_idx
  on public.conversations (user_id, updated_at desc);

-- ---------------------------------------------------------------------------
-- Messages
-- ---------------------------------------------------------------------------
create table if not exists public.messages (
  -- Message ids are opaque strings chosen by the browser (for example
  -- "m_9f1c2b7e"), so the column is text and not a uuid. The server reuses the
  -- browser id when it stores a row, which is what lets an edited message be
  -- replaced instead of duplicated.
  id              text primary key,
  conversation_id uuid not null references public.conversations on delete cascade,
  user_id         uuid not null references auth.users on delete cascade,
  role            text not null check (role in ('user', 'assistant')),
  content         text not null default '',
  attachments     jsonb not null default '[]'::jsonb,
  sources         jsonb not null default '[]'::jsonb,
  status          text not null default 'complete',
  error           text,
  model           text,
  created_at      timestamptz not null default now()
);

create index if not exists messages_conversation_created_idx
  on public.messages (conversation_id, created_at asc);

-- Migrate databases that were created before message ids became text.
do $$
begin
  if exists (
    select 1
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'messages'
      and column_name = 'id'
      and data_type = 'uuid'
  ) then
    alter table public.messages drop constraint if exists messages_pkey;
    alter table public.messages alter column id drop default;
    alter table public.messages alter column id type text using id::text;
    alter table public.messages add primary key (id);
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- Attachments (metadata; the bytes live in a private Storage bucket)
-- ---------------------------------------------------------------------------
create table if not exists public.attachments (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references auth.users on delete cascade,
  conversation_id uuid references public.conversations on delete cascade,
  name            text not null,
  mime_type       text not null,
  size            bigint not null default 0,
  kind            text not null default 'unknown',
  analyzable      boolean not null default false,
  note            text,
  storage_key     text,
  extracted_text  text,
  created_at      timestamptz not null default now()
);

create index if not exists attachments_conversation_idx
  on public.attachments (conversation_id);

-- ---------------------------------------------------------------------------
-- Memories (long-lived facts and preferences, scoped per user)
-- ---------------------------------------------------------------------------
create table if not exists public.memories (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users on delete cascade,
  content    text not null,
  category   text not null default 'note',
  source     text not null default 'manual',
  enabled    boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists memories_user_created_idx
  on public.memories (user_id, created_at desc);

-- ---------------------------------------------------------------------------
-- Private usage accounting (server-side cost protection — never shown to users)
-- ---------------------------------------------------------------------------
create table if not exists public.usage_daily (
  user_id       text not null,
  day           date not null,
  requests      integer not null default 0,
  input_tokens  bigint not null default 0,
  output_tokens bigint not null default 0,
  primary key (user_id, day)
);

-- ---------------------------------------------------------------------------
-- Row Level Security
-- Every record is readable/writable only by its owner.
-- ---------------------------------------------------------------------------
alter table public.profiles    enable row level security;
alter table public.conversations enable row level security;
alter table public.messages    enable row level security;
alter table public.attachments enable row level security;
alter table public.memories    enable row level security;
alter table public.usage_daily enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
drop policy if exists "profiles_insert_own" on public.profiles;
drop policy if exists "profiles_update_own" on public.profiles;

create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles
  for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "conversations_owner_all" on public.conversations;
create policy "conversations_owner_all" on public.conversations
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "messages_owner_all" on public.messages;
create policy "messages_owner_all" on public.messages
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "attachments_owner_all" on public.attachments;
create policy "attachments_owner_all" on public.attachments
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "memories_owner_all" on public.memories;
create policy "memories_owner_all" on public.memories
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "usage_owner_all" on public.usage_daily;
create policy "usage_owner_all" on public.usage_daily
  for all using (auth.uid()::text = user_id) with check (auth.uid()::text = user_id);

-- ---------------------------------------------------------------------------
-- Auto-create a profile row when a user signs up
-- ---------------------------------------------------------------------------
drop trigger if exists on_auth_user_created on auth.users;
drop function if exists public.handle_new_user();
create function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(coalesce(new.email, ''), '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- Atomic usage counter (server-side cost protection)
-- ---------------------------------------------------------------------------
drop function if exists public.increment_usage(
  p_user_id text,
  p_day date,
  p_requests integer,
  p_input_tokens bigint,
  p_output_tokens bigint
);
create function public.increment_usage(
  p_user_id text,
  p_day date,
  p_requests integer,
  p_input_tokens bigint,
  p_output_tokens bigint
)
returns void
language sql
security definer set search_path = public
as $$
  insert into public.usage_daily (user_id, day, requests, input_tokens, output_tokens)
  values (p_user_id, p_day, p_requests, p_input_tokens, p_output_tokens)
  on conflict (user_id, day) do update
    set requests = usage_daily.requests + excluded.requests,
        input_tokens = usage_daily.input_tokens + excluded.input_tokens,
        output_tokens = usage_daily.output_tokens + excluded.output_tokens;
$$;

-- ---------------------------------------------------------------------------
-- Private storage bucket for uploaded files.
-- Create it in Dashboard → Storage → New bucket, name it `yuvanx-files`
-- and turn OFF "Public bucket". The policies below are added automatically
-- by the app on first upload, but you can also paste them here.
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('yuvanx-files', 'yuvanx-files', false)
on conflict (id) do nothing;

drop policy if exists "yuvanx_files_owner_all" on storage.objects;
create policy "yuvanx_files_owner_all" on storage.objects
  for all
  using (
    bucket_id = 'yuvanx-files'
    and auth.role() = 'authenticated'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    bucket_id = 'yuvanx-files'
    and auth.role() = 'authenticated'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
