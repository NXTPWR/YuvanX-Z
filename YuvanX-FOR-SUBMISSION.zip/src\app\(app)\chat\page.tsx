import { redirect } from 'next/navigation';
import { isProviderConfigured } from '@/lib/server/env';
import { ChatPanel } from '@/components/chat-panel';

export const dynamic = 'force-dynamic';

export default function NewChatPage() {
  if (!isProviderConfigured()) redirect('/setup');
  return <ChatPanel conversationId={null} />;
}
