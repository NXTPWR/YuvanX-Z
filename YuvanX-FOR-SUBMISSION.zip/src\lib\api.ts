'use client';

import { getSupabaseBrowserClient } from '@/lib/supabase-client';
import type { AttachmentMeta } from '@/lib/types';

const CLIENT_ID_KEY = 'yuvanx.client.id';

/** A stable, random per-browser id used for guest-mode rate limiting. */
export function getClientId(): string {
  if (typeof window === 'undefined') return 'server';
  try {
    const existing = window.localStorage.getItem(CLIENT_ID_KEY);
    if (existing) return existing;
    const generated =
      typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID().replace(/-/g, '').slice(0, 24)
        : Math.random().toString(36).slice(2, 14) + Date.now().toString(36);
    window.localStorage.setItem(CLIENT_ID_KEY, generated);
    return generated;
  } catch {
    return 'anonymous';
  }
}

/** Headers for every call to our own API. */
export async function buildHeaders(extra?: Record<string, string>): Promise<Record<string, string>> {
  const headers: Record<string, string> = {
    'content-type': 'application/json',
    'x-yuvanx-client': getClientId(),
    ...extra,
  };

  const supabase = getSupabaseBrowserClient();
  if (supabase) {
    try {
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;
      if (token) headers.authorization = `Bearer ${token}`;
    } catch {
      /* unauthenticated is fine */
    }
  }
  return headers;
}

export class ApiError extends Error {
  readonly code: string;
  readonly status: number;
  readonly retryable: boolean;

  constructor(message: string, status: number, code = 'error', retryable = false) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.retryable = retryable;
  }
}

async function parseError(response: Response): Promise<ApiError> {
  let message = `Request failed (${response.status}).`;
  let code = 'error';
  let retryable = false;
  try {
    const payload = (await response.json()) as {
      error?: string;
      code?: string;
      retryable?: boolean;
    };
    if (payload?.error) message = payload.error;
    if (payload?.code) code = payload.code;
    if (typeof payload?.retryable === 'boolean') retryable = payload.retryable;
  } catch {
    /* keep the default message */
  }
  if (response.status === 429 || response.status >= 500) retryable = true;
  return new ApiError(message, response.status, code, retryable);
}

export async function apiRequest<T>(
  path: string,
  init: RequestInit = {},
): Promise<T> {
  const headers = await buildHeaders(
    init.headers as Record<string, string> | undefined,
  );
  const response = await fetch(path, { ...init, headers });
  if (!response.ok) throw await parseError(response);
  if (response.status === 204) return undefined as T;
  const text = await response.text();
  if (!text) return undefined as T;
  return JSON.parse(text) as T;
}

export async function apiGet<T>(path: string): Promise<T> {
  return apiRequest<T>(path, { method: 'GET' });
}

export async function apiSend<T>(
  path: string,
  method: 'POST' | 'PATCH' | 'DELETE' | 'PUT',
  body?: unknown,
): Promise<T> {
  return apiRequest<T>(path, {
    method,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

/** Upload a file to the attachments endpoint. */
export async function uploadAttachment(file: File): Promise<{
  attachment: AttachmentMeta & { persisted: boolean };
}> {
  const form = new FormData();
  form.append('file', file);

  const headers: Record<string, string> = { 'x-yuvanx-client': getClientId() };
  const supabase = getSupabaseBrowserClient();
  if (supabase) {
    try {
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;
      if (token) headers.authorization = `Bearer ${token}`;
    } catch {
      /* unauthenticated is fine */
    }
  }

  const response = await fetch('/api/attachments', { method: 'POST', headers, body: form });
  if (!response.ok) throw await parseError(response);
  return response.json();
}
