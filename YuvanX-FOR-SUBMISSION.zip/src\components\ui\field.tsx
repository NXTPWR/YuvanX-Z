'use client';

import { useId } from 'react';
import { cn } from '@/lib/utils';

export interface SwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  description?: string;
  disabled?: boolean;
}

/** An accessible on/off switch built on a real checkbox input. */
export function Switch({ checked, onChange, label, description, disabled }: SwitchProps) {
  const id = useId();
  const descriptionId = `${id}-description`;

  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <div className="min-w-0">
        <label htmlFor={id} className="block cursor-pointer text-sm font-medium text-ink">
          {label}
        </label>
        {description ? (
          <p id={descriptionId} className="mt-0.5 text-xs leading-relaxed text-muted">
            {description}
          </p>
        ) : null}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        aria-describedby={description ? descriptionId : undefined}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={cn(
          'relative mt-0.5 h-6 w-11 shrink-0 rounded-full border transition-colors duration-200',
          'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
          'disabled:cursor-not-allowed disabled:opacity-50',
          checked
            ? 'border-transparent accent-gradient'
            : 'border-line-strong bg-[rgb(var(--border)/0.12)]',
        )}
      >
        <span
          aria-hidden="true"
          className={cn(
            'absolute top-0.5 h-4.5 w-4.5 rounded-full bg-white shadow transition-transform duration-200',
            checked ? 'translate-x-[22px]' : 'translate-x-0.5',
          )}
          style={{ height: '1.125rem', width: '1.125rem' }}
        />
      </button>
    </div>
  );
}

export interface SelectOption<T extends string = string> {
  value: T;
  label: string;
  description?: string;
}

export interface SelectFieldProps<T extends string = string> {
  label: string;
  description?: string;
  value: T;
  options: SelectOption<T>[];
  onChange: (value: T) => void;
  disabled?: boolean;
}

export function SelectField<T extends string = string>({
  label,
  description,
  value,
  options,
  onChange,
  disabled,
}: SelectFieldProps<T>) {
  const id = useId();
  const descriptionId = `${id}-description`;

  return (
    <div className="py-3">
      <label htmlFor={id} className="block text-sm font-medium text-ink">
        {label}
      </label>
      {description ? (
        <p id={descriptionId} className="mt-0.5 text-xs leading-relaxed text-muted">
          {description}
        </p>
      ) : null}
      <select
        id={id}
        value={value}
        disabled={disabled}
        aria-describedby={description ? descriptionId : undefined}
        onChange={(event) => onChange(event.target.value as T)}
        className={cn(
          'mt-2 h-10 w-full rounded-[var(--radius-md)] border border-line-strong bg-[rgb(var(--panel)/0.6)]',
          'px-3 text-sm text-ink transition-colors hover:border-accent/50',
          'focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30',
          'disabled:cursor-not-allowed disabled:opacity-60',
        )}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value} className="bg-panel-solid text-ink">
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}

export interface TextFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  description?: string;
}

export function TextField({ label, description, id, className, ...props }: TextFieldProps) {
  const generatedId = useId();
  const fieldId = id ?? generatedId;
  const descriptionId = `${fieldId}-description`;

  return (
    <div className="py-3">
      <label htmlFor={fieldId} className="block text-sm font-medium text-ink">
        {label}
      </label>
      {description ? (
        <p id={descriptionId} className="mt-0.5 text-xs leading-relaxed text-muted">
          {description}
        </p>
      ) : null}
      <input
        id={fieldId}
        aria-describedby={description ? descriptionId : undefined}
        className={cn(
          'mt-2 h-10 w-full rounded-[var(--radius-md)] border border-line-strong bg-[rgb(var(--panel)/0.6)]',
          'px-3 text-sm text-ink placeholder:text-subtle transition-colors hover:border-accent/40',
          'focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30',
          'disabled:cursor-not-allowed disabled:opacity-60',
          className,
        )}
        {...props}
      />
    </div>
  );
}
