'use client';

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ArrowDown } from 'lucide-react';
import type { Message } from '@/lib/types';
import { cn } from '@/lib/utils';
import { MessageItem } from '@/components/message-item';

export interface MessageListProps {
  messages: Message[];
  streamingMessageId?: string | null;
  queries?: string[];
  onEdit?: (message: Message, nextText: string) => void;
  onRegenerate?: (message: Message) => void;
  onRetry?: (message: Message) => void;
}

export function MessageList({
  messages,
  streamingMessageId = null,
  queries = [],
  onEdit,
  onRegenerate,
  onRetry,
}: MessageListProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const stickToBottom = useRef(true);
  const [showJump, setShowJump] = useState(false);

  const onScroll = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;
    const distance = container.scrollHeight - container.scrollTop - container.clientHeight;
    const atBottom = distance < 120;
    stickToBottom.current = atBottom;
    // Only touch React state when it actually changes — a wheel gesture can
    // fire dozens of scroll events a second and re-rendering the whole
    // transcript for each of them makes scrolling feel sluggish.
    setShowJump((current) => (current === !atBottom ? current : !atBottom));
  }, []);

  const jumpToBottom = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;
    stickToBottom.current = true;
    setShowJump(false);
    container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
  }, []);

  /* Keep the newest content in view while the response streams. */
  useLayoutEffect(() => {
    if (!stickToBottom.current) return;
    const container = containerRef.current;
    if (!container) return;
    container.scrollTop = container.scrollHeight;
  }, [messages]);

  useEffect(() => {
    const container = containerRef.current;
    const content = contentRef.current;
    if (!container || !content) return;
    const observer = new ResizeObserver(() => {
      if (!stickToBottom.current) return;
      container.scrollTop = container.scrollHeight;
    });
    observer.observe(content);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="relative min-h-0 flex-1">
      <div
        ref={containerRef}
        onScroll={onScroll}
        // No `scroll-smooth` here on purpose: a smooth scroll container makes
        // the browser animate every programmatic scroll, which fights the mouse
        // wheel and swallows fast flicks. The wheel stays instant; only the
        // explicit "jump to latest" button animates.
        className="h-full overflow-y-auto overscroll-contain px-4 pb-6 pt-2 sm:px-6"
      >
        <div ref={contentRef} className="mx-auto flex w-full max-w-3xl flex-col gap-6">
          {messages.map((message) => (
            <MessageItem
              key={message.id}
              message={message}
              streaming={message.id === streamingMessageId}
              queries={message.id === streamingMessageId ? queries : []}
              onEdit={onEdit}
              onRegenerate={onRegenerate}
              onRetry={onRetry}
            />
          ))}
          <div ref={bottomRef} />
        </div>
      </div>

      <button
        type="button"
        onClick={jumpToBottom}
        aria-label="Scroll to the latest message"
        className={cn(
          'glass-strong shadow-lifted absolute bottom-4 left-1/2 z-10 flex h-9 w-9 -translate-x-1/2 items-center justify-center',
          'rounded-full text-ink transition-all duration-200',
          'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
          showJump ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-2 opacity-0',
        )}
      >
        <ArrowDown size={16} />
      </button>
    </div>
  );
}
