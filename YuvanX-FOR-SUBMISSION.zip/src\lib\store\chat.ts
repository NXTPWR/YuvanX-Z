'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Conversation, Memory, Message } from '@/lib/types';
import { uid } from '@/lib/utils';

/** Prefix used for conversations that only exist in this browser. */
export const LOCAL_PREFIX = 'local_';

export function isLocalConversationId(id: string | null | undefined): boolean {
  return typeof id === 'string' && id.startsWith(LOCAL_PREFIX);
}

export function createLocalId(): string {
  return `${LOCAL_PREFIX}${uid()}`;
}

/** A portable export of everything a guest keeps in this browser. */
export interface GuestSnapshot {
  version: 1;
  exportedAt: number;
  conversations: Conversation[];
  messagesByConversation: Record<string, Message[]>;
  memories: Memory[];
}

/**
 * The answer that is currently being generated.
 *
 * This lives in the store rather than in component state because the chat
 * panel is remounted whenever the route changes (a new chat becomes
 * `/chat/<id>`), and component state would be lost mid-stream.
 */
export interface StreamingState {
  conversationId: string;
  messageId: string | null;
  /** Identifies the newest run so a late event cannot clear a newer one. */
  runId: number;
}

export interface ChatStore {
  conversations: Conversation[];
  messagesByConversation: Record<string, Message[]>;
  memories: Memory[];
  activeId: string | null;
  /**
   * Which account the cached data belongs to, or `null` for guest data.
   *
   * Persisting this is what stops one account's chats from being shown to a
   * different account on the same browser — even if the tab was closed or
   * crashed instead of signing out cleanly.
   */
  ownerId: string | null;
  hydrated: boolean;
  streaming: StreamingState | null;

  setHydrated(value: boolean): void;
  setActive(id: string | null): void;

  /* Ownership -------------------------------------------------------------- */
  claimOwnership(userId: string | null): void;

  /* Streaming -------------------------------------------------------------- */
  beginStreaming(conversationId: string, messageId: string | null, runId: number): void;
  endStreaming(runId: number): void;
  setStreamingMessage(messageId: string): void;
  retargetStreaming(conversationId: string, runId: number): void;

  /* Conversations ---------------------------------------------------------- */
  createLocalConversation(title?: string): Conversation;
  setConversation(conversation: Conversation): void;
  setConversations(conversations: Conversation[]): void;
  patchConversation(id: string, patch: Partial<Conversation>): void;
  removeConversation(id: string): void;
  removeConversationEntry(id: string): void;

  /* Messages -------------------------------------------------------------- */
  getMessages(conversationId: string): Message[];
  setMessages(conversationId: string, messages: Message[]): void;
  /**
   * Apply a server transcript without throwing away messages the browser
   * created while the request was in flight (a message that is being sent or
   * streamed right now never exists on the server yet).
   */
  mergeMessages(conversationId: string, messages: Message[]): void;
  addMessage(conversationId: string, message: Message): void;
  patchMessage(conversationId: string, messageId: string, patch: Partial<Message>): void;
  removeMessage(conversationId: string, messageId: string): void;
  /** Remove a message and every message after it. */
  removeMessagesFrom(conversationId: string, messageId: string): void;

  /* Memories -------------------------------------------------------------- */
  addMemory(memory: Memory): void;
  /** Replace the whole memory list (cloud sync is authoritative). */
  setMemories(memories: Memory[]): void;
  patchMemory(id: string, patch: Partial<Memory>): void;
  removeMemory(id: string): void;
  clearMemories(): void;

  /* Portability ----------------------------------------------------------- */
  exportSnapshot(): GuestSnapshot;
  importSnapshot(snapshot: GuestSnapshot): void;
  resetLocal(): void;
}

/** Attachments bigger than this are not kept in localStorage (quota safety). */
const PERSISTED_INLINE_LIMIT = 180_000;
/** Overall budget for inline data kept in localStorage. */
const PERSISTED_TOTAL_LIMIT = 1_500_000;

function stripHeavyAttachments(messages: Message[]): Message[] {
  return messages.map((message) => {
    if (!message.attachments?.length) return message;
    let changed = false;
    const attachments = message.attachments.map((attachment) => {
      if (!attachment.dataUrl) return attachment;
      if (attachment.size > PERSISTED_INLINE_LIMIT) {
        changed = true;
        const { dataUrl: _dropped, ...rest } = attachment;
        return rest;
      }
      return attachment;
    });
    return changed ? { ...message, attachments } : message;
  });
}

/** Keep the persisted payload under the storage budget. */
function fitToBudget(
  conversations: Conversation[],
  messagesByConversation: Record<string, Message[]>,
): { conversations: Conversation[]; messagesByConversation: Record<string, Message[]> } {
  let total = 0;
  const next: Record<string, Message[]> = {};
  const ordered = Object.entries(messagesByConversation);
  for (const [conversationId, messages] of ordered) {
    const stripped = stripHeavyAttachments(messages);
    for (const message of stripped) {
      for (const attachment of message.attachments ?? []) {
        total += attachment.dataUrl?.length ?? 0;
      }
    }
    next[conversationId] = stripped;
  }

  if (total <= PERSISTED_TOTAL_LIMIT) {
    return { conversations, messagesByConversation: next };
  }

  // Over budget — drop inline previews entirely, keep every message.
  const strippedAll: Record<string, Message[]> = {};
  for (const [conversationId, messages] of Object.entries(messagesByConversation)) {
    strippedAll[conversationId] = messages.map((message) => ({
      ...message,
      attachments: (message.attachments ?? []).map((attachment) => {
        if (!attachment.dataUrl) return attachment;
        const { dataUrl: _dropped, ...rest } = attachment;
        return rest;
      }),
    }));
  }
  return { conversations, messagesByConversation: strippedAll };
}

const EMPTY_MESSAGES: Message[] = [];

export const useChatStore = create<ChatStore>()(
  persist(
    (set, get) => ({
      conversations: [],
      messagesByConversation: {},
      memories: [],
      activeId: null,
      ownerId: null,
      hydrated: false,
      streaming: null,

      setHydrated: (value) => set({ hydrated: value }),
      setActive: (id) => set({ activeId: id }),

      /**
       * Binds the local cache to an account.
       *
       * - Same owner: nothing happens.
       * - Guest data (`null`) adopted by a new account: kept, so a chat that
       *   started before signing in is never lost.
       * - A different account: the old cache is dropped. Another person must
       *   never see the previous user's chats or memories.
       */
      claimOwnership: (userId) =>
        set((state) => {
          const owner = state.ownerId ?? null;
          if (owner === userId) return state;
          if (owner !== null) {
            return {
              conversations: [],
              messagesByConversation: {},
              memories: [],
              activeId: null,
              streaming: null,
              ownerId: userId,
            };
          }
          return { ownerId: userId };
        }),

      beginStreaming: (conversationId, messageId, runId) =>
        set({ streaming: { conversationId, messageId, runId } }),

      /**
       * Clears the streaming state, but only for the run that owns it. A
       * slower request that finishes late must never unlock a newer answer.
       */
      endStreaming: (runId) =>
        set((state) =>
          state.streaming && state.streaming.runId !== runId ? state : { streaming: null },
        ),

      setStreamingMessage: (messageId) =>
        set((state) =>
          state.streaming ? { streaming: { ...state.streaming, messageId } } : state,
        ),

      /** Points the streaming state at the conversation the answer now lives in. */
      retargetStreaming: (conversationId, runId) =>
        set((state) =>
          state.streaming && state.streaming.runId === runId
            ? { streaming: { ...state.streaming, conversationId } }
            : state,
        ),

      createLocalConversation: (title = 'New chat') => {
        const now = Date.now();
        const conversation: Conversation = {
          id: createLocalId(),
          title,
          pinned: false,
          archived: false,
          saved: false,
          autoTitle: false,
          createdAt: now,
          updatedAt: now,
        };
        set((state) => ({
          conversations: [conversation, ...state.conversations],
          activeId: conversation.id,
        }));
        return conversation;
      },

      setConversation: (conversation) =>
        set((state) => {
          const index = state.conversations.findIndex((c) => c.id === conversation.id);
          const conversations =
            index === -1
              ? [conversation, ...state.conversations]
              : state.conversations.map((c) => (c.id === conversation.id ? { ...c, ...conversation } : c));
          return { conversations };
        }),

      setConversations: (conversations) =>
        set((state) => {
          // Keep any local-only conversations the server does not know about.
          const serverIds = new Set(conversations.map((c) => c.id));
          const localOnly = state.conversations.filter(
            (c) => isLocalConversationId(c.id) && !serverIds.has(c.id),
          );
          return { conversations: [...conversations, ...localOnly] };
        }),

      patchConversation: (id, patch) =>
        set((state) => ({
          conversations: state.conversations.map((c) =>
            c.id === id ? { ...c, ...patch, updatedAt: patch.updatedAt ?? Date.now() } : c,
          ),
        })),

      removeConversation: (id) =>
        set((state) => {
          const { [id]: _removed, ...rest } = state.messagesByConversation;
          return {
            conversations: state.conversations.filter((c) => c.id !== id),
            messagesByConversation: rest,
            activeId: state.activeId === id ? null : state.activeId,
          };
        }),

      /**
       * Removes a conversation from the list but keeps its messages, so a
       * thread that just moved to the cloud can keep rendering while the
       * browser catches up with the new id.
       */
      removeConversationEntry: (id) =>
        set((state) => ({
          conversations: state.conversations.filter((c) => c.id !== id),
          activeId: state.activeId === id ? null : state.activeId,
        })),

      getMessages: (conversationId) => get().messagesByConversation[conversationId] ?? EMPTY_MESSAGES,

      setMessages: (conversationId, messages) =>
        set((state) => ({
          messagesByConversation: { ...state.messagesByConversation, [conversationId]: messages },
        })),

      mergeMessages: (conversationId, messages) =>
        set((state) => {
          const existing = state.messagesByConversation[conversationId] ?? [];
          if (existing.length === 0) {
            return {
              messagesByConversation: {
                ...state.messagesByConversation,
                [conversationId]: messages,
              },
            };
          }

          const serverIds = new Set(messages.map((message) => message.id));
          const newestServer = messages.reduce(
            (max, message) => Math.max(max, message.createdAt ?? 0),
            0,
          );
          // Anything the browser knows about but the server does not, and that
          // is newer than the newest server message, is still in flight.
          const inFlight = existing.filter(
            (message) => !serverIds.has(message.id) && (message.createdAt ?? 0) >= newestServer,
          );
          if (inFlight.length === 0) {
            return {
              messagesByConversation: {
                ...state.messagesByConversation,
                [conversationId]: messages,
              },
            };
          }

          return {
            messagesByConversation: {
              ...state.messagesByConversation,
              [conversationId]: [...messages, ...inFlight],
            },
          };
        }),

      addMessage: (conversationId, message) =>
        set((state) => {
          const existing = state.messagesByConversation[conversationId] ?? [];
          const index = existing.findIndex((m) => m.id === message.id);
          const messages =
            index === -1
              ? [...existing, message]
              : existing.map((m) => (m.id === message.id ? { ...m, ...message } : m));
          return {
            messagesByConversation: { ...state.messagesByConversation, [conversationId]: messages },
            conversations: state.conversations.map((c) =>
              c.id === conversationId ? { ...c, updatedAt: Date.now() } : c,
            ),
          };
        }),

      patchMessage: (conversationId, messageId, patch) =>
        set((state) => {
          const existing = state.messagesByConversation[conversationId];
          if (!existing) return state;
          let changed = false;
          const messages = existing.map((m) => {
            if (m.id !== messageId) return m;
            changed = true;
            return { ...m, ...patch };
          });
          if (!changed) return state;
          return { messagesByConversation: { ...state.messagesByConversation, [conversationId]: messages } };
        }),

      removeMessage: (conversationId, messageId) =>
        set((state) => {
          const existing = state.messagesByConversation[conversationId];
          if (!existing) return state;
          return {
            messagesByConversation: {
              ...state.messagesByConversation,
              [conversationId]: existing.filter((m) => m.id !== messageId),
            },
          };
        }),

      removeMessagesFrom: (conversationId, messageId) =>
        set((state) => {
          const existing = state.messagesByConversation[conversationId];
          if (!existing) return state;
          const index = existing.findIndex((m) => m.id === messageId);
          if (index === -1) return state;
          return {
            messagesByConversation: {
              ...state.messagesByConversation,
              [conversationId]: existing.slice(0, index),
            },
          };
        }),

      addMemory: (memory) =>
        set((state) => ({ memories: [memory, ...state.memories] })),

      setMemories: (memories) => set({ memories }),

      patchMemory: (id, patch) =>
        set((state) => ({
          memories: state.memories.map((m) => (m.id === id ? { ...m, ...patch } : m)),
        })),

      removeMemory: (id) => set((state) => ({ memories: state.memories.filter((m) => m.id !== id) })),

      clearMemories: () => set({ memories: [] }),

      exportSnapshot: () => ({
        version: 1,
        exportedAt: Date.now(),
        conversations: get().conversations,
        messagesByConversation: get().messagesByConversation,
        memories: get().memories,
      }),

      importSnapshot: (snapshot) =>
        set((state) => {
          const conversations = [...snapshot.conversations, ...state.conversations.filter((c) => isLocalConversationId(c.id))];
          return {
            conversations,
            messagesByConversation: { ...state.messagesByConversation, ...snapshot.messagesByConversation },
            memories: [...snapshot.memories, ...state.memories],
          };
        }),

      resetLocal: () =>
        set({
          conversations: [],
          messagesByConversation: {},
          memories: [],
          activeId: null,
          // An answer that is still arriving has nowhere left to write to, and
          // leaving the flag set would lock the composer forever.
          streaming: null,
        }),
    }),
    {
      name: 'yuvanx.data.v1',
      version: 1,
      partialize: (state) => {
        const messagesByConversation: Record<string, Message[]> = {};
        for (const [conversationId, messages] of Object.entries(state.messagesByConversation)) {
          // Never persist an in-flight message — it would come back as a ghost.
          messagesByConversation[conversationId] = messages.filter((m) => m.status !== 'streaming');
        }
        const fitted = fitToBudget(state.conversations, messagesByConversation);
        return {
          conversations: fitted.conversations,
          messagesByConversation: fitted.messagesByConversation,
          memories: state.memories,
          activeId: state.activeId,
          ownerId: state.ownerId ?? null,
        };
      },
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    },
  ),
);

/** Selectors — stable references keep components from re-rendering needlessly. */
export const selectConversations = (state: ChatStore) => state.conversations;
export const selectMemories = (state: ChatStore) => state.memories;
export const selectActiveId = (state: ChatStore) => state.activeId;
