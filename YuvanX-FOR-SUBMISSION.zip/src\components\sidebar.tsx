'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Archive,
  ArchiveRestore,
  Bookmark,
  BookmarkCheck,
  Download,
  LogIn,
  LogOut,
  MoreHorizontal,
  Pencil,
  Pin,
  PinOff,
  Plus,
  PanelLeftClose,
  PanelLeftOpen,
  Search,
  Settings as SettingsIcon,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { Logo } from '@/components/logo';
import { Button, IconButton } from '@/components/ui/button';
import { Modal } from '@/components/ui/modal';
import { useToast } from '@/components/ui/toast';
import { useChatStore, isLocalConversationId } from '@/lib/store/chat';
import { useAuthStore } from '@/lib/store/auth';
import {
  deleteRemoteConversation,
  patchRemoteConversation,
} from '@/lib/cloud';
import { cn, downloadTextFile, formatRelativeTime, truncate } from '@/lib/utils';
import type { Conversation, Message } from '@/lib/types';

export interface SidebarProps {
  /** Mobile drawer visibility. */
  open: boolean;
  onClose: () => void;
  collapsed: boolean;
  onToggleCollapsed: () => void;
  activeId: string | null;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  onRequestAuth: (reason?: 'sync' | 'files' | 'account') => void;
}

type MenuAction = 'rename' | 'pin' | 'save' | 'archive' | 'export' | 'delete';

export function Sidebar({
  open,
  onClose,
  collapsed,
  onToggleCollapsed,
  activeId,
  onSelect,
  onNewChat,
  onRequestAuth,
}: SidebarProps) {
  const router = useRouter();
  const toast = useToast();

  const conversations = useChatStore((state) => state.conversations);
  const messagesByConversation = useChatStore((state) => state.messagesByConversation);
  const patchConversation = useChatStore((state) => state.patchConversation);
  const removeConversation = useChatStore((state) => state.removeConversation);

  const user = useAuthStore((state) => state.user);
  const signOut = useAuthStore((state) => state.signOut);

  const [query, setQuery] = useState('');
  const [menuFor, setMenuFor] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<Conversation | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [deleting, setDeleting] = useState<Conversation | null>(null);
  const [showArchived, setShowArchived] = useState(false);

  const menuRefs = useRef(new Map<string, HTMLDivElement>());
  const renameInputRef = useRef<HTMLInputElement>(null);

  /* Close the row menu when clicking elsewhere. */
  useEffect(() => {
    if (!menuFor) return;
    const onPointerDown = (event: PointerEvent) => {
      const node = menuRefs.current.get(menuFor);
      if (node && !node.contains(event.target as Node)) {
        setMenuFor(null);
      }
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenuFor(null);
    };
    document.addEventListener('pointerdown', onPointerDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('pointerdown', onPointerDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [menuFor]);

  useEffect(() => {
    if (renaming) {
      renameInputRef.current?.focus();
      renameInputRef.current?.select();
    }
  }, [renaming]);

  /* Escape closes the mobile drawer, just like every other overlay. */
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const list = needle
      ? conversations.filter(
          (conversation) =>
            conversation.title.toLowerCase().includes(needle) ||
            (messagesByConversation[conversation.id] ?? []).some((message) =>
              message.content.toLowerCase().includes(needle),
            ),
        )
      : conversations;
    return [...list].sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return b.updatedAt - a.updatedAt;
    });
  }, [conversations, messagesByConversation, query]);

  const pinned = filtered.filter((c) => c.pinned && !c.archived);
  const saved = filtered.filter((c) => c.saved && !c.archived && !c.pinned);
  const recent = filtered.filter((c) => !c.pinned && !c.saved && !c.archived);
  const archived = filtered.filter((c) => c.archived);

  /* ---------------------------------------------------------------------- */
  /* Actions                                                                  */
  /* ---------------------------------------------------------------------- */
  const persistPatch = useCallback(
    async (conversation: Conversation, patch: Partial<Conversation>) => {
      patchConversation(conversation.id, patch);
      if (user && !isLocalConversationId(conversation.id)) {
        const remote = await patchRemoteConversation(conversation.id, patch);
        if (!remote) {
          toast.error('That change could not be saved to the cloud.');
          return;
        }
        patchConversation(conversation.id, remote);
      }
    },
    [patchConversation, toast, user],
  );

  const handleAction = useCallback(
    async (conversation: Conversation, action: MenuAction) => {
      setMenuFor(null);

      switch (action) {
        case 'rename':
          setRenaming(conversation);
          setRenameValue(conversation.title);
          break;
        case 'pin':
          await persistPatch(conversation, { pinned: !conversation.pinned });
          break;
        case 'save':
          await persistPatch(conversation, { saved: !conversation.saved });
          toast.success(conversation.saved ? 'Removed from saved.' : 'Saved for later.');
          break;
        case 'archive':
          await persistPatch(conversation, { archived: !conversation.archived });
          if (!conversation.archived && activeId === conversation.id) {
            router.push('/chat');
          }
          break;
        case 'export':
          exportConversation(conversation, messagesByConversation[conversation.id] ?? []);
          toast.success('Conversation exported as Markdown.');
          break;
        case 'delete':
          setDeleting(conversation);
          break;
        default:
          break;
      }
    },
    [activeId, messagesByConversation, persistPatch, router, toast],
  );

  const commitRename = useCallback(async () => {
    if (!renaming) return;
    const title = renameValue.trim().slice(0, 120);
    setRenaming(null);
    if (!title || title === renaming.title) return;
    await persistPatch(renaming, { title, autoTitle: false });
  }, [persistPatch, renameValue, renaming]);

  const confirmDelete = useCallback(async () => {
    if (!deleting) return;
    const target = deleting;
    setDeleting(null);
    removeConversation(target.id);
    if (user && !isLocalConversationId(target.id)) {
      const ok = await deleteRemoteConversation(target.id);
      if (!ok) toast.error('That conversation could not be deleted from the cloud.');
    }
    if (activeId === target.id) router.push('/chat');
    toast.success('Conversation deleted.');
  }, [activeId, deleting, removeConversation, router, toast, user]);

  /* ---------------------------------------------------------------------- */
  /* Render                                                                   */
  /* ---------------------------------------------------------------------- */
  const renderGroup = (title: string, items: Conversation[]) => {
    if (items.length === 0) return null;
    return (
      <section className="mt-4">
        <h3 className="px-3 pb-1 text-[0.66rem] font-semibold uppercase tracking-wider text-subtle">
          {title}
        </h3>
        <ul className="space-y-0.5">
          {items.map((conversation) => (
            <li key={conversation.id} className="group/item relative">
              <button
                type="button"
                onClick={() => {
                  onSelect(conversation.id);
                  onClose();
                }}
                className={cn(
                  'flex w-full items-center gap-2 rounded-[var(--radius-sm)] px-3 py-2 text-left transition-colors',
                  'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
                  activeId === conversation.id
                    ? 'bg-[rgb(var(--accent)/0.13)] text-ink'
                    : 'text-muted hover:bg-[rgb(var(--border)/0.07)] hover:text-ink',
                )}
              >
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[0.82rem] font-medium">
                    {conversation.title || 'Untitled chat'}
                  </span>
                  <span className="block truncate text-[0.68rem] text-subtle">
                    {formatRelativeTime(conversation.updatedAt)}
                  </span>
                </span>

                {conversation.pinned ? (
                  <Pin size={11} className="shrink-0 text-accent" aria-label="Pinned" />
                ) : null}
                {conversation.saved ? (
                  <Bookmark size={11} className="shrink-0 text-accent-2" aria-label="Saved" />
                ) : null}
              </button>

              <div
                ref={(node) => {
                  if (node) menuRefs.current.set(conversation.id, node);
                  else menuRefs.current.delete(conversation.id);
                }}
                className="absolute right-1.5 top-1/2 -translate-y-1/2"
                onClick={(event) => event.stopPropagation()}
              >
                <IconButton
                  label={`Options for ${conversation.title || 'conversation'}`}
                  onClick={() => setMenuFor(menuFor === conversation.id ? null : conversation.id)}
                  className="h-7 w-7 opacity-0 transition-opacity focus-visible:opacity-100 group-hover/item:opacity-100"
                  size="icon"
                >
                  <MoreHorizontal size={14} />
                </IconButton>

                {menuFor === conversation.id ? (
                  <div
                    role="menu"
                    className="glass-strong shadow-lifted absolute right-0 top-8 z-50 w-48 animate-scale-in overflow-hidden rounded-[var(--radius-md)] p-1"
                    style={{ transformOrigin: 'top right' }}
                  >
                    <MenuButton
                      icon={<Pencil size={13} />}
                      label="Rename"
                      onClick={() => void handleAction(conversation, 'rename')}
                    />
                    <MenuButton
                      icon={conversation.pinned ? <PinOff size={13} /> : <Pin size={13} />}
                      label={conversation.pinned ? 'Unpin' : 'Pin to top'}
                      onClick={() => void handleAction(conversation, 'pin')}
                    />
                    <MenuButton
                      icon={conversation.saved ? <BookmarkCheck size={13} /> : <Bookmark size={13} />}
                      label={conversation.saved ? 'Remove from saved' : 'Save for later'}
                      onClick={() => void handleAction(conversation, 'save')}
                    />
                    <MenuButton
                      icon={conversation.archived ? <ArchiveRestore size={13} /> : <Archive size={13} />}
                      label={conversation.archived ? 'Restore from archive' : 'Archive'}
                      onClick={() => void handleAction(conversation, 'archive')}
                    />
                    <MenuButton
                      icon={<Download size={13} />}
                      label="Export as Markdown"
                      onClick={() => void handleAction(conversation, 'export')}
                    />
                    <div className="my-1 h-px bg-[rgb(var(--border)/0.12)]" />
                    <MenuButton
                      icon={<Trash2 size={13} />}
                      label="Delete"
                      danger
                      onClick={() => void handleAction(conversation, 'delete')}
                    />
                  </div>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      </section>
    );
  };

  /**
   * The sidebar body. Rendered once for the desktop rail and once inside the
   * mobile drawer. `variant` picks the chrome controls that make sense for
   * that layout.
   */
  const renderSidebarContent = (variant: 'rail' | 'drawer') => (
    <>
      <div className="flex items-center gap-2 px-3 pb-3 pt-3.5">
        <button
          type="button"
          onClick={() => {
            router.push('/chat');
            onClose();
          }}
          className="group flex min-w-0 flex-1 items-center rounded-[var(--radius-sm)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          aria-label="YuvanX home"
        >
          <Logo size={28} className="transition-transform duration-200 ease-out group-hover:scale-[1.04]" />
        </button>

        {variant === 'drawer' ? (
          <IconButton label="Close sidebar" onClick={onClose} size="icon">
            <X size={16} />
          </IconButton>
        ) : (
          <IconButton
            label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            onClick={onToggleCollapsed}
            size="icon"
          >
            {collapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}
          </IconButton>
        )}
      </div>

      <div className="px-3">
        <Button
          variant="primary"
          className="w-full justify-center"
          onClick={() => {
            onNewChat();
            onClose();
          }}
        >
          <Plus size={15} />
          New chat
        </Button>
      </div>

      <div className="px-3 pt-3">
        <div className="relative">
          <Search
            size={13}
            className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-subtle"
          />
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search chats"
            aria-label="Search conversations"
            className={cn(
              'h-9 w-full rounded-[var(--radius-sm)] border border-line bg-[rgb(var(--panel)/0.5)] pl-8 pr-2.5',
              'text-[0.8rem] text-ink placeholder:text-subtle',
              'focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/25',
            )}
          />
        </div>
      </div>

      <nav className="min-h-0 flex-1 overflow-y-auto px-3 pb-4" aria-label="Conversations">
        {filtered.length === 0 ? (
          <p className="px-1 py-6 text-center text-xs leading-relaxed text-subtle">
            {query ? 'No chats match that search.' : 'Your conversations will appear here.'}
          </p>
        ) : (
          <>
            {renderGroup('Pinned', pinned)}
            {renderGroup('Saved', saved)}
            {renderGroup('Recent', recent)}

            {archived.length > 0 ? (
              <section className="mt-4">
                <button
                  type="button"
                  onClick={() => setShowArchived((value) => !value)}
                  aria-expanded={showArchived}
                  className="flex w-full items-center gap-1.5 rounded-[var(--radius-sm)] px-3 py-1.5 text-[0.66rem] font-semibold uppercase tracking-wider text-subtle transition-colors hover:text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                >
                  <Archive size={11} />
                  Archived ({archived.length})
                </button>
                {showArchived ? renderGroup('Archived', archived) : null}
              </section>
            ) : null}
          </>
        )}
      </nav>

      <div className="border-t border-line p-3">
        <nav className="space-y-0.5" aria-label="Application">
          <SidebarLink
            icon={<Sparkles size={14} />}
            label="Memories"
            onClick={() => {
              router.push('/memories');
              onClose();
            }}
          />
          <SidebarLink
            icon={<SettingsIcon size={14} />}
            label="Settings"
            onClick={() => {
              router.push('/settings');
              onClose();
            }}
          />
        </nav>

        <div className="mt-3 border-t border-line pt-3">
          {user ? (
            <div className="flex items-center gap-2.5">
              <span className="accent-gradient flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[0.7rem] font-bold text-accent-contrast">
                {(user.name ?? user.email ?? '?').charAt(0).toUpperCase()}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.8rem] font-medium text-ink">
                  {user.name ?? 'Signed in'}
                </span>
                <span className="block truncate text-[0.68rem] text-subtle">{user.email}</span>
              </span>
              <IconButton label="Sign out" onClick={() => void signOut()} size="icon" className="h-8 w-8">
                <LogOut size={14} />
              </IconButton>
            </div>
          ) : (
            <Button
              variant="outline"
              className="w-full justify-center"
              onClick={() => {
                onRequestAuth('sync');
                onClose();
              }}
            >
              <LogIn size={14} />
              Sign in
            </Button>
          )}
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile drawer */}
      <div
        className={cn(
          'fixed inset-0 z-[90] lg:hidden',
          open ? 'pointer-events-auto' : 'pointer-events-none',
        )}
        aria-hidden={!open}
        inert={!open}
      >
        <div
          className={cn(
            'absolute inset-0 bg-[rgb(var(--bg-deep)/0.65)] backdrop-blur-sm transition-opacity duration-200',
            open ? 'opacity-100' : 'opacity-0',
          )}
          onClick={onClose}
        />
        <aside
          className={cn(
            'glass-strong shadow-lifted absolute inset-y-0 left-0 flex w-[17.5rem] flex-col',
            'transition-transform duration-250 ease-out',
            open ? 'translate-x-0' : '-translate-x-full',
          )}
          role="dialog"
          aria-label="Sidebar"
          aria-modal={open ? 'true' : undefined}
        >
          {renderSidebarContent('drawer')}
        </aside>
      </div>

      {/* Desktop rail */}
      <aside
        className={cn(
          'hidden shrink-0 flex-col border-r border-line bg-[rgb(var(--panel)/0.28)] backdrop-blur-xl lg:flex',
          'transition-[width] duration-250 ease-out',
          collapsed ? 'w-0 overflow-hidden border-r-0' : 'w-[17.5rem]',
        )}
      >
        <div className="flex h-full w-[17.5rem] flex-col">
          {renderSidebarContent('rail')}
        </div>
      </aside>

      <Modal
        open={Boolean(renaming)}
        onClose={() => setRenaming(null)}
        title="Rename conversation"
        description="Pick a title you will recognise later."
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setRenaming(null)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={() => void commitRename()}>
              Save
            </Button>
          </>
        }
      >
        <input
          ref={renameInputRef}
          value={renameValue}
          onChange={(event) => setRenameValue(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.preventDefault();
              void commitRename();
            }
          }}
          maxLength={120}
          aria-label="Conversation title"
          className="h-10 w-full rounded-[var(--radius-md)] border border-line-strong bg-[rgb(var(--panel)/0.6)] px-3 text-sm text-ink placeholder:text-subtle focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30"
        />
      </Modal>

      <Modal
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        title="Delete this conversation?"
        description="This removes the conversation and every message in it. It cannot be undone."
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setDeleting(null)}>
              Keep it
            </Button>
            <Button variant="danger" onClick={() => void confirmDelete()}>
              <Trash2 size={14} />
              Delete
            </Button>
          </>
        }
      >
        <p className="text-sm leading-relaxed text-muted">
          <span className="font-medium text-ink">{deleting?.title || 'Untitled chat'}</span> will be
          removed from your history.
        </p>
      </Modal>
    </>
  );
}

/* -------------------------------------------------------------------------- */

function MenuButton({
  icon,
  label,
  onClick,
  danger = false,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      role="menuitem"
      onClick={onClick}
      className={cn(
        'flex w-full items-center gap-2.5 rounded-[var(--radius-sm)] px-2.5 py-1.5 text-left text-[0.8rem]',
        'transition-colors focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-accent',
        danger
          ? 'text-danger hover:bg-[rgb(var(--danger)/0.1)]'
          : 'text-muted hover:bg-[rgb(var(--border)/0.08)] hover:text-ink',
      )}
    >
      <span className="shrink-0">{icon}</span>
      {label}
    </button>
  );
}

function SidebarLink({
  icon,
  label,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex w-full items-center gap-2.5 rounded-[var(--radius-sm)] px-3 py-2 text-[0.82rem]',
        'text-muted transition-colors hover:bg-[rgb(var(--border)/0.07)] hover:text-ink',
        'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
      )}
    >
      {icon}
      {label}
    </button>
  );
}

/** Export a conversation as a readable Markdown document. */
function exportConversation(conversation: Conversation, messages: Message[]): void {
  const lines: string[] = [`# ${conversation.title || 'Untitled chat'}`, ''];
  lines.push(`_Exported from YuvanX on ${new Date().toLocaleString()}_`, '');

  for (const message of messages) {
    lines.push(message.role === 'user' ? '## You' : '## YuvanX');
    if (message.attachments.length > 0) {
      lines.push('');
      lines.push(
        `*Attachments: ${message.attachments.map((a) => a.name).join(', ')}*`,
      );
    }
    lines.push('');
    lines.push(message.content || '_(no content)_');
    if (message.sources.length > 0) {
      lines.push('');
      lines.push('**Sources**');
      for (const source of message.sources) {
        lines.push(`- [${truncate(source.title || source.url, 70)}](${source.url})`);
      }
    }
    lines.push('');
  }

  const slug = (conversation.title || 'conversation')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 50);
  downloadTextFile(`yuvanx-${slug || 'conversation'}.md`, lines.join('\n'), 'text/markdown');
}
