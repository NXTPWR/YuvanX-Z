/**
 * Shared domain types for YuvanX.
 * These types are used by both the browser and the server, so they must stay
 * free of any server-only imports.
 */

export type Role = 'user' | 'assistant';

export type AttachmentKind =
  | 'image'
  | 'pdf'
  | 'text'
  | 'markdown'
  | 'code'
  | 'csv'
  | 'docx'
  | 'xlsx'
  | 'unknown';

/** Metadata describing a file that was attached to a message. */
export interface AttachmentMeta {
  id: string;
  name: string;
  mimeType: string;
  size: number;
  kind: AttachmentKind;
  /** True only when the pipeline can genuinely read the content. */
  analyzable: boolean;
  /** Human readable explanation when the file could not be analyzed. */
  note?: string;
  /** Storage object key (Supabase Storage) when the file is persisted server-side. */
  storageKey?: string;
  /** Plain-text extraction, used when the file is analysed through the text pipeline. */
  text?: string;
  /** Inline data URL for image previews (guest mode). */
  dataUrl?: string;
}

/** A web source that grounded part of an answer. */
export interface Source {
  title: string;
  url: string;
}

export type MessageStatus = 'complete' | 'streaming' | 'error' | 'stopped';

export interface Message {
  id: string;
  conversationId: string;
  role: Role;
  content: string;
  attachments: AttachmentMeta[];
  sources: Source[];
  status: MessageStatus;
  error?: string;
  errorCode?: string;
  createdAt: number;
  model?: string;
}

export interface Conversation {
  id: string;
  title: string;
  pinned: boolean;
  archived: boolean;
  saved: boolean;
  autoTitle: boolean;
  createdAt: number;
  updatedAt: number;
  model?: string;
}

export type MemoryCategory = 'preference' | 'project' | 'instruction' | 'fact' | 'note';

export interface Memory {
  id: string;
  content: string;
  category: MemoryCategory;
  source: 'manual' | 'auto';
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
}

export type ThemeMode = 'light' | 'dark' | 'system';
export type AccentName = 'aurora' | 'violet' | 'cyan' | 'ember' | 'mint';
export type FontScale = 'sm' | 'md' | 'lg' | 'xl';
export type AnimationLevel = 'full' | 'reduced' | 'off';

export interface Settings {
  theme: ThemeMode;
  accent: AccentName;
  fontScale: FontScale;
  enterToSend: boolean;
  sound: boolean;
  animation: AnimationLevel;
  reducedMotion: boolean;
  /** Master memory switch — when off nothing is stored or recalled. */
  memoryEnabled: boolean;
  /** Automatic memory extraction (still requires memoryEnabled). */
  autoMemory: boolean;
  /** Default web-search behaviour for new conversations. */
  webSearch: boolean;
  /** Preferred model id. */
  model: string;
}

export const DEFAULT_SETTINGS: Settings = {
  theme: 'dark',
  accent: 'aurora',
  fontScale: 'md',
  enterToSend: true,
  sound: false,
  animation: 'full',
  reducedMotion: false,
  memoryEnabled: true,
  autoMemory: false,
  webSearch: false,
  model: '',
};

/** Server -> client streaming protocol (SSE payload shapes). */
export type ChatStreamEvent =
  | { type: 'start'; messageId: string; model: string }
  /**
   * The server moved the thread to a different conversation id. This happens
   * when a guest signs in mid-conversation: the browser-only thread is
   * promoted to a real cloud conversation and the client follows the new id.
   */
  | { type: 'conversation'; conversationId: string }
  | { type: 'delta'; text: string }
  /**
   * The server discarded the text streamed so far (a retry or a failover to
   * another model). The client drops what it has rendered so the answer is
   * never a mix of two attempts.
   */
  | { type: 'reset' }
  | { type: 'sources'; sources: Source[] }
  | { type: 'search'; queries: string[] }
  | { type: 'title'; title: string }
  | { type: 'memory'; memories: Memory[] }
  | { type: 'done'; message: Message }
  | { type: 'error'; message: string; code: string; retryable: boolean };
