import { redirect } from 'next/navigation';
import { isProviderConfigured } from '@/lib/server/env';
import { ChatPanel } from '@/components/chat-panel';

export const dynamic = 'force-dynamic';

export default async function ChatConversationPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  if (!isProviderConfigured()) redirect('/setup');
  const { id } = await params;
  return <ChatPanel conversationId={id} />;
}
