'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { DEFAULT_SETTINGS, type Settings } from '@/lib/types';

export interface SettingsStore extends Settings {
  /** True once the persisted state has been read back from storage. */
  hydrated: boolean;
  set: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  merge: (patch: Partial<Settings>) => void;
  reset: () => void;
  setHydrated: (hydrated: boolean) => void;
}

export const useSettingsStore = create<SettingsStore>()(
  persist(
    (set) => ({
      ...DEFAULT_SETTINGS,
      hydrated: false,
      set: (key, value) => set({ [key]: value } as Partial<SettingsStore>),
      merge: (patch) => set(patch as Partial<SettingsStore>),
      reset: () => set({ ...DEFAULT_SETTINGS }),
      setHydrated: (hydrated) => set({ hydrated }),
    }),
    {
      name: 'yuvanx.settings.v1',
      partialize: (state) => ({
        theme: state.theme,
        accent: state.accent,
        fontScale: state.fontScale,
        enterToSend: state.enterToSend,
        sound: state.sound,
        animation: state.animation,
        reducedMotion: state.reducedMotion,
        memoryEnabled: state.memoryEnabled,
        autoMemory: state.autoMemory,
        webSearch: state.webSearch,
        model: state.model,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    },
  ),
);

/** Convenience selector — avoids re-rendering on unrelated state changes. */
export const selectSetting = <K extends keyof Settings>(key: K) => (s: SettingsStore) => s[key];
