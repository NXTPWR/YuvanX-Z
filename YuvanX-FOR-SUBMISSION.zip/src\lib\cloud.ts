'use client';

import { apiGet, apiSend } from '@/lib/api';
import type { Conversation, Memory, Message } from '@/lib/types';

/**
 * Thin wrapper around the persistence API.
 *
 * Every call is a no-op-friendly request: the caller decides what to do when
 * the deployment has no database configured (guest mode).
 */

export interface ConversationWithMessages {
  conversation: Conversation;
  messages: Message[];
}

export async function fetchConversations(): Promise<Conversation[]> {
  const payload = await apiGet<{ conversations: Conversation[] }>('/api/conversations');
  return payload.conversations ?? [];
}

export async function createRemoteConversation(input: {
  title?: string;
  model?: string;
}): Promise<Conversation> {
  const payload = await apiSend<{ conversation: Conversation }>('/api/conversations', 'POST', input);
  return payload.conversation;
}

export async function fetchConversation(id: string): Promise<ConversationWithMessages | null> {
  try {
    return await apiGet<ConversationWithMessages>(`/api/conversations/${id}`);
  } catch {
    return null;
  }
}

export async function patchRemoteConversation(
  id: string,
  patch: Partial<
    Pick<Conversation, 'title' | 'pinned' | 'archived' | 'saved' | 'model'>
  >,
): Promise<Conversation | null> {
  try {
    const payload = await apiSend<{ conversation: Conversation }>(
      `/api/conversations/${id}`,
      'PATCH',
      patch,
    );
    return payload.conversation;
  } catch {
    return null;
  }
}

export async function deleteRemoteConversation(id: string): Promise<boolean> {
  try {
    await apiSend<{ ok: boolean }>(`/api/conversations/${id}`, 'DELETE');
    return true;
  } catch {
    return false;
  }
}

/* Memories ---------------------------------------------------------------- */

export async function fetchMemories(): Promise<Memory[]> {
  const payload = await apiGet<{ memories: Memory[] }>('/api/memories');
  return payload.memories ?? [];
}

export async function createRemoteMemory(input: {
  content: string;
  category?: Memory['category'];
}): Promise<Memory | null> {
  try {
    const payload = await apiSend<{ memory: Memory }>('/api/memories', 'POST', input);
    return payload.memory;
  } catch {
    return null;
  }
}

export async function patchRemoteMemory(
  id: string,
  patch: Partial<Pick<Memory, 'content' | 'category' | 'enabled'>>,
): Promise<Memory | null> {
  try {
    const payload = await apiSend<{ memory: Memory }>(`/api/memories/${id}`, 'PATCH', patch);
    return payload.memory;
  } catch {
    return null;
  }
}

export async function deleteRemoteMemory(id: string): Promise<boolean> {
  try {
    await apiSend<{ ok: boolean }>(`/api/memories/${id}`, 'DELETE');
    return true;
  } catch {
    return false;
  }
}

export async function clearRemoteMemories(): Promise<boolean> {
  try {
    await apiSend<{ ok: boolean }>('/api/memories', 'DELETE');
    return true;
  } catch {
    return false;
  }
}
