import type { AttachmentKind } from '@/lib/types';
import { MAX_TEXT_CHARS } from '@/lib/constants';

/**
 * File validation and text extraction.
 *
 * Every format advertised in the UI is genuinely handled here. Formats that
 * cannot be parsed are reported as "not analyzable" instead of being faked.
 */

const EXTENSION_KIND: Record<string, AttachmentKind> = {
  '.png': 'image',
  '.jpg': 'image',
  '.jpeg': 'image',
  '.webp': 'image',
  '.pdf': 'pdf',
  '.txt': 'text',
  '.log': 'text',
  '.md': 'markdown',
  '.markdown': 'markdown',
  '.csv': 'csv',
  '.tsv': 'csv',
  '.docx': 'docx',
  '.xlsx': 'xlsx',
  '.js': 'code',
  '.jsx': 'code',
  '.mjs': 'code',
  '.cjs': 'code',
  '.ts': 'code',
  '.tsx': 'code',
  '.py': 'code',
  '.java': 'code',
  '.go': 'code',
  '.rs': 'code',
  '.rb': 'code',
  '.php': 'code',
  '.c': 'code',
  '.h': 'code',
  '.cpp': 'code',
  '.hpp': 'code',
  '.cs': 'code',
  '.swift': 'code',
  '.kt': 'code',
  '.html': 'code',
  '.htm': 'code',
  '.css': 'code',
  '.scss': 'code',
  '.json': 'code',
  '.yaml': 'code',
  '.yml': 'code',
  '.xml': 'code',
  '.sql': 'code',
  '.sh': 'code',
  '.bash': 'code',
  '.toml': 'code',
  '.ini': 'code',
  '.env': 'code',
};

const MIME_KIND: Record<string, AttachmentKind> = {
  'image/png': 'image',
  'image/jpeg': 'image',
  'image/jpg': 'image',
  'image/webp': 'image',
  'application/pdf': 'pdf',
  'text/plain': 'text',
  'text/markdown': 'markdown',
  'text/x-markdown': 'markdown',
  'text/csv': 'csv',
  'application/csv': 'csv',
  'application/vnd.ms-excel': 'csv',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
  'application/json': 'code',
  'application/xml': 'code',
  'text/xml': 'code',
  'application/x-yaml': 'code',
  'text/yaml': 'code',
  'text/html': 'code',
  'text/css': 'code',
  'text/javascript': 'code',
  'application/javascript': 'code',
  'text/x-python': 'code',
  'application/x-sh': 'code',
};

/**
 * Blocked outright — never accepted, never stored.
 *
 * These are executable or binary payloads. Plain-text scripts (`.js`, `.sh`,
 * `.bash`) are deliberately *not* here: the product analyses source code, so
 * blocking them would contradict the formats we advertise.
 */
const DANGEROUS_EXTENSIONS = new Set([
  '.exe', '.dll', '.bat', '.cmd', '.com', '.msi', '.scr', '.pif', '.ps1', '.vbs',
  '.jar', '.apk', '.app', '.deb', '.rpm', '.dmg', '.pkg', '.so', '.bin',
]);

const DANGEROUS_MIME_PREFIXES = ['application/x-msdownload', 'application/x-executable'];

export function getExtension(name: string): string {
  const index = name.lastIndexOf('.');
  if (index === -1) return '';
  return name.slice(index).toLowerCase();
}

export function detectKind(name: string, mimeType: string): AttachmentKind {
  const normalized = (mimeType || '').split(';')[0].trim().toLowerCase();
  const byMime = MIME_KIND[normalized];
  const extension = getExtension(name);
  const byExtension = EXTENSION_KIND[extension];
  if (byExtension) return byExtension;
  if (byMime) return byMime;
  if (normalized.startsWith('text/')) return 'text';
  return 'unknown';
}

export function isDangerousFile(name: string, mimeType: string): boolean {
  const extension = getExtension(name);
  const normalized = (mimeType || '').split(';')[0].trim().toLowerCase();
  if (DANGEROUS_EXTENSIONS.has(extension)) return true;
  if (DANGEROUS_MIME_PREFIXES.some((prefix) => normalized.startsWith(prefix))) return true;
  if (normalized === 'application/x-msdownload' || normalized === 'application/vnd.microsoft.portable-executable') {
    return true;
  }
  return false;
}

/** Human readable file-type label used in the UI. */
export function kindLabel(kind: AttachmentKind): string {
  switch (kind) {
    case 'image':
      return 'Image';
    case 'pdf':
      return 'PDF';
    case 'text':
      return 'Text';
    case 'markdown':
      return 'Markdown';
    case 'code':
      return 'Source code';
    case 'csv':
      return 'CSV';
    case 'docx':
      return 'Word document';
    case 'xlsx':
      return 'Spreadsheet';
    default:
      return 'File';
  }
}

export interface ExtractionResult {
  text?: string;
  analyzable: boolean;
  note?: string;
}

function decodeText(bytes: Uint8Array): string {
  const buffer = Buffer.from(bytes);
  // Strip a UTF-8 BOM if present.
  if (buffer.length >= 3 && buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) {
    return buffer.subarray(3).toString('utf8');
  }
  return buffer.toString('utf8');
}

function capText(text: string): { text: string; truncated: boolean } {
  if (text.length <= MAX_TEXT_CHARS) return { text, truncated: false };
  return {
    text: `${text.slice(0, MAX_TEXT_CHARS)}\n\n[...content truncated at ${MAX_TEXT_CHARS.toLocaleString()} characters...]`,
    truncated: true,
  };
}

/** Extract readable text from a file. */
export async function extractText(
  bytes: Uint8Array,
  kind: AttachmentKind,
  name: string,
): Promise<ExtractionResult> {
  switch (kind) {
    case 'text':
    case 'markdown':
    case 'code':
    case 'csv': {
      const raw = decodeText(bytes);
      if (!raw.trim()) {
        return { analyzable: true, text: '', note: 'The file is empty.' };
      }
      const { text } = capText(raw);
      return { analyzable: true, text };
    }

    case 'docx': {
      try {
        const mammoth = (await import('mammoth')).default;
        const buffer = Buffer.from(bytes);
        const result = await mammoth.extractRawText({ buffer });
        const text = (result.value ?? '').trim();
        if (!text) {
          return {
            analyzable: false,
            note: 'No readable text was found in this Word document.',
          };
        }
        const capped = capText(text);
        return { analyzable: true, text: capped.text };
      } catch {
        return {
          analyzable: false,
          note: 'This Word document could not be parsed. Try converting it to PDF or text.',
        };
      }
    }

    case 'xlsx': {
      try {
        const text = await extractSpreadsheet(bytes);
        if (!text.trim()) {
          return { analyzable: false, note: 'This spreadsheet contains no readable rows.' };
        }
        const capped = capText(text);
        return { analyzable: true, text: capped.text };
      } catch {
        return {
          analyzable: false,
          note: 'This spreadsheet could not be parsed. Try uploading it as CSV instead.',
        };
      }
    }

    case 'pdf':
      // PDFs are passed to the model as native documents — no local extraction.
      return { analyzable: true };

    case 'image':
      // Images are passed to the model as native vision input.
      return { analyzable: true };

    default:
      return {
        analyzable: false,
        note: `YuvanX cannot analyse ${name.split('.').pop()?.toUpperCase() ?? 'this'} files.`,
      };
  }
}

async function extractSpreadsheet(bytes: Uint8Array): Promise<string> {
  const ExcelJS = (await import('exceljs')).default;
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(Buffer.from(bytes) as unknown as ArrayBuffer);

  const parts: string[] = [];
  workbook.eachSheet((sheet) => {
    parts.push(`## Sheet: ${sheet.name}`);
    const rows: string[] = [];
    sheet.eachRow({ includeEmpty: false }, (row) => {
      const values = row.values as unknown[];
      const cells = values.slice(1).map((value) => {
        if (value === null || value === undefined) return '';
        if (typeof value === 'object') {
          const record = value as { text?: string; result?: unknown; richText?: Array<{ text: string }> };
          if (typeof record.text === 'string') return record.text;
          if (Array.isArray(record.richText)) return record.richText.map((t) => t.text).join('');
          if (record.result !== undefined) return String(record.result);
          return JSON.stringify(value);
        }
        return String(value);
      });
      rows.push(cells.map((cell) => (/[",\n]/.test(cell) ? `"${cell.replace(/"/g, '""')}"` : cell)).join(', '));
    });
    parts.push(rows.join('\n'));
  });

  return parts.join('\n\n');
}
