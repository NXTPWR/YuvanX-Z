# YuvanX

A premium AI assistant web app built on **Next.js 16**, **TypeScript**, **Tailwind v4** and the
**Google Gemini Interactions API** — with real streaming answers, secure file analysis,
persistent memory, full conversation management, optional Supabase accounts and cloud sync.

YuvanX never fabricates answers, citations or file contents. If the AI provider is not
configured or unreachable, the app says so plainly instead of pretending.

---

## Table of contents

- [Highlights](#highlights)
- [Tech stack](#tech-stack)
- [Quick start](#quick-start)
- [Environment variables](#environment-variables)
- [Supabase setup (optional)](#supabase-setup-optional)
- [Deploying to Vercel](#deploying-to-vercel)
- [How it works](#how-it-works)
- [Project structure](#project-structure)
- [Security & privacy](#security--privacy)
- [Manual verification checklist](#manual-verification-checklist)
- [Troubleshooting](#troubleshooting)

---

## Highlights

**Real AI, genuinely streamed**
- Server-side-only Gemini integration through the Interactions API (`POST /v1beta/interactions?alt=sse`).
- Tokens are relayed to the browser over SSE and batched per animation frame, so typing stays smooth.
- Stop mid-answer, regenerate, edit a previous prompt and resend, or retry a failed turn.
- Automatic conversation titles generated from the first exchange.

**Files that are actually analysed**
- PNG / JPG / WEBP images, PDF, TXT, MD, DOCX, CSV, XLSX and source code.
- Server-side validation: MIME sniffing, extension allow-list, size caps, per-file and total budgets.
- Text is extracted server-side (PDF, Word, Excel, CSV, code) and injected into the prompt.
- Authenticated uploads land in a **private** Supabase Storage bucket; the browser never receives a
  storage key and the server resolves attachments from their database id.

**Memory that persists**
- Cross-chat facts and preferences, stored per account.
- Explicit consent, a global on/off switch, per-memory enable/disable, edit, delete and clear-all.
- Secret-shaped strings (API keys, tokens, passwords) are filtered out before anything is stored.

**Complete conversation management**
- New chat, rename, delete with confirmation, search, pin, archive, save/bookmark and export.
- Pinned / saved / archived conversations are grouped separately in the sidebar.
- Guest chats live in the browser; signed-in chats sync to the cloud.

**Accountable but not gamified**
- Supabase email+password, magic-link OTP and Google sign-in.
- Row Level Security on every table; the service-role key is only ever used server-side.
- There is **no visible credits, coins, balance or quota system anywhere in the UI.** Usage
  protection is entirely private and server-side.

**Crafted interface**
- Light / dark / system themes, five accent palettes, four font sizes.
- Optional entrance sound, animation control and reduced-motion support.
- Responsive down to small phones, keyboard navigable, ARIA-labelled, visible focus rings.

---

## Tech stack

| Layer | Choice |
| --- | --- |
| Framework | Next.js 16 (App Router, Turbopack) |
| Language | TypeScript 5.9 (strict) |
| Styling | Tailwind CSS v4 (CSS-first `@theme`), custom design tokens |
| AI | Google Gemini — Interactions API with SSE streaming |
| Auth + data | Supabase (Postgres, Auth, Storage, RLS) — optional |
| State | Zustand 5 (with `persist` middleware for local storage) |
| Markdown | react-markdown + remark-gfm + rehype-highlight |
| Validation | Zod (request bodies), custom server-side file validation |
| Lint | ESLint 9 flat config (`eslint-config-next` v16) |

---

## Quick start

### 1. Requirements

- **Node.js ≥ 20.9** (Node 22 recommended — the app uses `AbortSignal.any` / `AbortSignal.timeout`).
- A **Google Gemini API key** — the only thing you strictly need.

### 2. Install

```bash
npm install
```

### 3. Configure

```bash
cp .env.example .env.local     # Windows: copy .env.example .env.local
```

Open `.env.local` and set at least:

```dotenv
GEMINI_API_KEY=your_key_here
```

Create a key for free at <https://aistudio.google.com/app/apikey>.

> The key is read only inside Next.js server code. It is never prefixed with `NEXT_PUBLIC_`,
> so it is never bundled into the browser.

### 4. Run

```bash
npm run dev
```

Open <http://localhost:3000>. YuvanX redirects to `/setup` when no provider key is present; with a
key configured it drops you straight into `/chat`.

### 5. Production build

```bash
npm run typecheck   # tsc --noEmit
npm run lint        # eslint .
npm run build       # next build
npm start           # next start
```

All three checks pass on a clean checkout.

---

## Environment variables

Every variable is documented in [`.env.example`](./.env.example). Nothing below is required
except `GEMINI_API_KEY`.

### AI provider

| Variable | Default | Purpose |
| --- | --- | --- |
| `GEMINI_API_KEY` | — | **Required.** Server-side Gemini key. |
| `GEMINI_MODEL` | `gemini-3.8-flash` | Default model. Also selectable in the UI header. |
| `GEMINI_API_BASE` | `https://generativelanguage.googleapis.com/v1beta` | Override the API base URL (proxy, gateway or local test double). |
| `GEMINI_FALLBACK_MODELS` | — | Comma-separated models tried in order when the primary fails. |
| `GEMINI_TIMEOUT_MS` | `90000` | Per-request server timeout. |
| `GEMINI_MAX_OUTPUT_TOKENS` | `8192` | Maximum tokens per reply. |
| `GEMINI_THINKING_LEVEL` | `low` | `low` \| `medium` \| `high` reasoning effort. |
| `GEMINI_STORE` | `true` | Set `false` to ask Google not to retain interactions. |

Supported model ids (as of this build): `gemini-3.8-flash`, `gemini-3.6-flash`,
`gemini-3.5-flash-lite`. Older 2.5-era models are intentionally avoided — their access is
restricted for new projects.

#### Free tier vs paid key — read this

A **free** Gemini key allows roughly **20 requests per day, per model**. YuvanX uses one request
per answer (plus one short request for the title of a new conversation), so a few conversations can
use up a model for the whole day. When that happens the app does not fail: it parks the exhausted
model for the rest of the window, immediately fails over to the next model in
`GEMINI_FALLBACK_MODELS`, and only reports a problem when *every* model is rate limited:

> Every available model is rate limited right now. The next one frees up in about 16h.

Free-tier capacity is also **congested**, so the first token can take 10–25 seconds even when the
request succeeds. For a genuinely fast assistant, attach a billing account to the Google Cloud
project and use the paid quota — no code or configuration change is needed, the same
`GEMINI_API_KEY` simply stops being rate limited. Bind it in
*Google AI Studio → API keys → the key → Billing*, or
*Google Cloud Console → APIs & Services → Generative Language API → Quotas*.

The private `DAILY_REQUEST_LIMIT` / `REQUESTS_PER_MINUTE` caps are separate from Google's quota and
never appear in the UI.

### Secondary (failover) provider — optional

| Variable | Default | Purpose |
| --- | --- | --- |
| `FALLBACK_API_KEY` | — | Key for an OpenAI-compatible endpoint. |
| `FALLBACK_BASE_URL` | — | e.g. `https://api.example.com/v1` (a `/chat/completions` URL is appended). |
| `FALLBACK_MODEL` | — | Model id to request from that endpoint. |

The secondary provider is only engaged for plain-text turns (no attachments, no web search) after
every Gemini model in the chain has failed.

### Supabase — optional

| Variable | Default | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | — | Project URL. Safe for the browser. |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | — | Anon key. Safe for the browser. |
| `SUPABASE_SERVICE_ROLE_KEY` | — | **Server only.** Verifies tokens and enforces ownership. |
| `SUPABASE_STORAGE_BUCKET` | `yuvanx-files` | Name of the private upload bucket. |
| `SUPABASE_AUTO_CONFIRM` | `true` | Create accounts already confirmed, so sign-up works without SMTP. |

Without Supabase the app runs in **guest mode**: chats, memories and settings persist in the
browser, and the UI says so honestly instead of pretending to sync.

`SUPABASE_AUTO_CONFIRM=true` uses the Admin API (`POST /api/auth/signup`) to create the account
with the address already confirmed and returns a ready session. Set it to `false` once a real SMTP
provider is configured if you would rather verify addresses.

### Private usage controls — optional, never shown to customers

| Variable | Default | Purpose |
| --- | --- | --- |
| `DAILY_REQUEST_LIMIT` | `120` | Per-user daily request cap (server-side only). |
| `REQUESTS_PER_MINUTE` | `20` | Per-client sliding-window cap. |

### Other

| Variable | Default | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | `http://localhost:3000` | Used for auth email redirects. |

---

## Supabase setup (optional)

Supabase unlocks accounts, cloud-synced conversations, cross-device memory and private file
storage. Everything works without it.

### 1. Create the project

1. Create a project at <https://supabase.com>.
2. Copy the **Project URL**, **anon key** and **service_role key** from
   *Project Settings → API* into `.env.local`.
3. Set `NEXT_PUBLIC_SITE_URL` to your real deployment origin (needed for auth redirects).

### 2. Run the schema

Open *SQL Editor → New query*, paste the contents of [`supabase/schema.sql`](./supabase/schema.sql)
and run it. It is fully idempotent — safe to run again.

The script creates:

- `profiles`, `conversations`, `messages`, `attachments`, `memories`, `usage_daily`
- Row Level Security policies on every table (owner-only access)
- A `handle_new_user` trigger that creates a profile on sign-up
- An atomic `increment_usage(...)` RPC for private usage accounting
- The private `yuvanx-files` storage bucket plus its ownership policies

### 3. Configure authentication

In *Authentication → Providers*:

- **Email** — enable *Email signup* and *Email OTP*. Turn **off** *Confirm email* if you want
  instant access, or leave it on (YuvanX detects the confirmation flow and shows a code screen).
- **Google** — enable it and paste the OAuth client id / secret. Add
  `https://<your-domain>/auth/callback` as an authorised redirect and
  `http://localhost:3000/auth/callback` for local development.

### 4. Verify the bucket is private

*Storage → Buckets → `yuvanx-files`* must show **Public = off**. YuvanX also creates the bucket
automatically on first upload if it does not exist, but it can never make it public.

---

## Deploying to Vercel

1. **Push the project** to GitHub, GitLab or Bitbucket.
2. **Import it** into Vercel (*Add New → Project*). The framework preset is detected
   automatically — do not override the build command (`next build`) or output directory.
3. **Add environment variables** in *Project Settings → Environment Variables*:

   | Variable | Environment | Value |
   | --- | --- | --- |
   | `GEMINI_API_KEY` | Production + Preview | your Gemini key |
   | `GEMINI_MODEL` | Production | `gemini-3.8-flash` (optional) |
   | `GEMINI_API_BASE` | Production | leave unset for the public Google endpoint (optional) |
   | `NEXT_PUBLIC_SUPABASE_URL` | Production + Preview | project URL |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Production + Preview | anon key |
   | `SUPABASE_SERVICE_ROLE_KEY` | Production + Preview | service-role key |
   | `SUPABASE_AUTO_CONFIRM` | Production | `true` (or `false` with a real SMTP provider) |
   | `NEXT_PUBLIC_SITE_URL` | Production | `https://your-domain` |

   `SUPABASE_SERVICE_ROLE_KEY` must **not** be exposed to the client — it is only read by server
   code, so marking it server-only in Vercel is enough.

4. **Deploy.** Add a custom domain under *Project Settings → Domains*; Vercel handles TLS.

### Manual steps after the first deploy

- [ ] Visit `https://your-domain/setup` and confirm it reports *YuvanX is ready*.
- [ ] Send a message and confirm the reply streams in token by token.
- [ ] If using Supabase: run `supabase/schema.sql`, then sign up and confirm a `profiles` row
      appears in the dashboard.
- [ ] In Supabase *Authentication → URL Configuration*, add your production origin to
      **Site URL** and **Redirect URLs**.
- [ ] Upload a file while signed in and confirm it appears in the private `yuvanx-files` bucket
      under a folder named after your user id.
- [ ] Confirm `GEMINI_API_KEY` does **not** appear in the client bundle. The grep below should
      only ever match the placeholder text on the setup page and the secret-detection regexes —
      never a real key:

      ```bash
      grep -r "AIza[0-9A-Za-z_-]\{35\}" .next/static   # must return nothing
      grep -r "SUPABASE_SERVICE_ROLE" .next/static       # must return nothing
      ```

---

## How it works

### Request flow

```
Browser ──POST /api/chat──► Next.js route handler
                              │
                              ├─ validate body (Zod) + rate limit
                              ├─ resolve attachments (DB id → private bucket / inline)
                              ├─ build prompt (system + memories + history + files)
                              ├─ Gemini Interactions API  ──SSE──► route handler ──SSE──► browser
                              └─ persist messages, title, memories, usage
```

The browser never talks to Google directly, and never receives a credential.

### Streaming

The route handler reads the Gemini SSE stream and re-emits a small, typed event protocol:

| Event | Purpose |
| --- | --- |
| `start` | Carries the server-assigned assistant message id. |
| `conversation` | The browser-only thread was promoted to a cloud conversation; carries the new id. |
| `delta` | A chunk of answer text. |
| `reset` | A failed attempt streamed something that must be discarded before the retry. |
| `search` | Queries issued by Google Search grounding. |
| `sources` | Citation list (title, url, snippet). |
| `title` | An auto-generated conversation title. |
| `memory` | Memories the model proposed storing. |
| `done` | The final, complete message. |
| `error` | A friendly, actionable error (`code` is machine-readable). |

`done` is sent **as soon as the model finishes**, before usage accounting, persistence, title
generation and memory extraction. The composer unlocks immediately instead of waiting for
bookkeeping that the user cannot see.

A brand-new chat does not wait for a round trip either: the browser assigns a `local_` id, sends
the request with it, and the server creates the matching cloud conversation and announces it with
`conversation`. The transcript is moved to the new id in place, so nothing blinks away.

Citations are fetched **after** the stream completes, from the stored interaction, so the source
list always reflects what Google actually returned — never a fabricated one.

### Reliability

- Up to **3 attempts per model**, exponential backoff (600 ms → 1.2 s → 2.4 s).
- **Model fallback** across `GEMINI_FALLBACK_MODELS` when a model is missing or exhausted.
- **Provider failover** to an OpenAI-compatible endpoint for plain-text turns.
- **Timeouts** on every upstream call; **cancellation** propagates from the browser's stop button
  through to Google, and a stopped answer is persisted as `stopped` rather than lost.
- Errors are normalised into plain-language messages ("busy, try again") instead of raw stack traces.

### Storage model

| Situation | Where data lives |
| --- | --- |
| Guest conversation | Browser (`localStorage` via Zustand persist) — inline attachments, ≤ 2.5 MB per file / 3 MB total. |
| Signed-in conversation | Supabase Postgres + private Storage bucket — up to 8 MB per file. |

Guest conversation ids are prefixed `local_` so the client can tell them apart from server UUIDs
without a round trip. A new signed-in chat also starts with a `local_` id so the answer can begin
immediately; the server creates the cloud row during the same request and the browser adopts the
new id through the `conversation` event.

Message ids are **text**, not UUIDs: the browser generates `m_…` ids and the server adopts them, so
local and cloud copies of a message always agree. That is what makes edit, regenerate and retry
work on a message that was written before the cloud row existed.

---

## Project structure

```
src/
├── app/
│   ├── layout.tsx              Root layout (fonts, providers, metadata)
│   ├── page.tsx                Redirects to /chat
│   ├── setup/page.tsx          Shown when no AI provider key is configured
│   ├── (app)/                  Authenticated shell: sidebar, header, routing
│   │   ├── chat/page.tsx       New chat
│   │   ├── chat/[id]/page.tsx  Existing conversation
│   │   ├── memories/page.tsx   Memory manager
│   │   └── settings/page.tsx   Appearance, behaviour, privacy
│   ├── api/
│   │   ├── chat/route.ts       SSE chat endpoint
│   │   ├── attachments/route.ts Upload + validation
│   │   ├── auth/signup/route.ts Confirmed account creation (SUPABASE_AUTO_CONFIRM)
│   │   ├── conversations/…     List / create / read / update / delete
│   │   ├── memories/…          List / create / update / delete
│   │   └── status/route.ts     Provider + capability probe (no secrets)
│   └── globals.css             Design tokens, themes, accents, motion
├── components/                 UI (chat panel, composer, sidebar, markdown, modals…)
├── lib/
│   ├── server/                 Server-only: env, Supabase, rate limit, AI, file parsing
│   ├── store/                  Zustand stores (chat, settings, auth, ui)
│   ├── api.ts / cloud.ts       Client wrappers over the API routes
│   ├── stream.ts               SSE reader with animation-frame batching
│   └── types.ts / utils.ts     Shared types and helpers
└── supabase/schema.sql         Idempotent schema + RLS + storage policies
```

---

## Security & privacy

- **Secrets stay on the server.** `GEMINI_API_KEY`, `SUPABASE_SERVICE_ROLE_KEY` and
  `FALLBACK_API_KEY` live in `src/lib/server/env.ts`, which is only imported by server modules.
  Only `NEXT_PUBLIC_*` values reach the browser.
- **Ownership is enforced twice** — RLS policies in Postgres *and* an explicit `user_id` filter on
  every query in `src/lib/server/db.ts`.
- **The authenticated user id always comes from the verified token**, never from the request body.
- **Uploads are validated server-side**: MIME sniffing, extension allow-list, size caps, and a
  total-size budget. Files are stored in a private bucket behind signed server-side access.
- **Markdown is rendered without raw HTML** (no `dangerouslySetInnerHTML`); external links get
  `rel="noopener noreferrer nofollow"`.
- **Memory is filtered** for secret-shaped strings before anything is written to the database.
- **The local cache is bound to its account.** Conversations, messages and memories are cached in
  `localStorage` for instant starts, and the cache records which account owns it. Signing out — or
  signing in as someone else — drops it, so the next person on the same browser cannot read the
  previous user's chats. Guest data is kept and adopted by the next sign-in instead of being
  thrown away.
- **No customer-facing credits system.** Usage limits exist only as private server-side counters.

---

## Manual verification checklist

Run through this once after setup — it exercises every feature end to end.

**Chat**
- [ ] The welcome screen shows suggested prompts.
- [ ] Sending a prompt streams the answer token by token.
- [ ] The mouse wheel scrolls the transcript (both directions) without moving the page.
- [ ] The stop button halts generation and keeps the partial answer.
- [ ] Regenerate replaces the answer; editing a prompt resends the thread from that point.
- [ ] The conversation title is generated automatically.
- [ ] Web search shows the queries issued and a clickable list of sources.
- [ ] Ask a question in Hindi, Spanish, German, French or Japanese: the answer comes back in that
      language and script, not in English.

**Files**
- [ ] A `.txt`, `.pdf`, `.csv`, `.xlsx`, `.docx`, a source file (`.ts`, `.js`, `.py`) and an image
      are all accepted.
- [ ] The extracted file content is actually part of the prompt sent to the model.
- [ ] An unsupported type (e.g. `.exe`) is rejected with a clear message.
- [ ] An oversized file is rejected with a clear message.

**Conversations**
- [ ] New chat, rename, pin, archive, save, search and delete (with confirmation) all work.
- [ ] Export produces a readable file.

**Memory**
- [ ] A memory can be added, edited, disabled, deleted, and cleared in bulk.
- [ ] A memory containing an API key or password is refused — in guest mode as well as when
      signed in.
- [ ] With memory off, the model receives no memories.

**Settings**
- [ ] Theme (light/dark/system), accent, font size, enter-to-send, sound, animation and
      reduced motion all apply and persist across a reload.

**Responsive & accessibility**
- [ ] On a narrow viewport the sidebar becomes a drawer with a hamburger trigger.
- [ ] Every control is reachable by keyboard with a visible focus ring.
- [ ] With "reduced motion" enabled, transitions are suppressed.

**Privacy**
- [ ] No credit/coin/balance wording appears anywhere in the interface.
- [ ] The Gemini key does not appear in the client bundle or in any network response.
- [ ] Signing out empties the conversation list in this browser (the account's data stays in the
      cloud and comes back on the next sign-in).

---

## Troubleshooting

**"One step before YuvanX can answer"**
`GEMINI_API_KEY` is missing or empty. Add it to `.env.local` and restart the dev server — Next.js
only reads environment variables at boot.

**"The Gemini API key was rejected"**
The key is wrong, revoked, or restricted. Create a fresh one at
<https://aistudio.google.com/app/apikey> and check that the Generative Language API is enabled
for the project.

**"This conversation lives in the cloud. Sign in…"**
You opened a URL for a conversation that belongs to an account. Sign in with that account, or
start a new chat.

**Answers are cut short or time out**
Raise `GEMINI_TIMEOUT_MS`, lower `GEMINI_THINKING_LEVEL`, or pick a smaller model such as
`gemini-3.5-flash-lite`.

**"Every available model is rate limited right now"**
The free tier allows about **20 requests per day per model**. YuvanX parks an exhausted model and
fails over automatically; the message only appears when every model in
`GEMINI_MODEL` + `GEMINI_FALLBACK_MODELS` is out of quota. Wait for the stated reset, add more
models to `GEMINI_FALLBACK_MODELS`, or attach billing to the Google Cloud project for paid quota
(the key itself does not change).

**Answers feel slow (10–25 s before the first word)**
That is free-tier congestion, not the app: the request is sent immediately, but Google queues it.
A paid key removes the queue. The title of a new chat and memory extraction are the only extra
requests YuvanX makes, and neither blocks the answer.

**The answer stops by itself**
Check the server log for `[yuvanx] chat …` and the SSE body in DevTools. A deliberate stop is
stored as `stopped` (no error), a provider failure as `error` with a friendly explanation.

**Sign-in emails do not arrive**
Check Supabase *Authentication → Providers → Email* and the rate-limit / template settings. In
local development, the confirmation URL must point back at `http://localhost:3000`.

**`npm install` fails with ERESOLVE or ETIMEDOUT**
Retry with a longer timeout and fewer parallel connections:

```bash
npm install --fetch-timeout=600000 --fetch-retries=5 --maxsockets=4
```

**The dev server is slow to paint / the tab seems to reload in a loop**
This is a Turbopack **development-server** artifact, not an application bug. `next dev` compiles each
route lazily and then serves it as a set of separately-compiled chunks alongside the Next.js DevTools
bundle. On a cold load the document can stay in `readyState === "loading"` for a minute or more,
which makes automated browsers and some screen readers re-navigate.

Verify the app against the production build instead:

```bash
npm run build && npm start
```

The production bundle serves a single optimised chunk per route and paints immediately.

---

## Licence

Private project. All rights reserved.
