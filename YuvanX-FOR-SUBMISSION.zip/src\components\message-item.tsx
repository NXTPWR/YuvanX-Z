'use client';

import { memo, useCallback, useState } from 'react';
import {
  Check,
  Copy,
  Pencil,
  RefreshCw,
  RotateCcw,
  TriangleAlert,
} from 'lucide-react';
import type { AttachmentMeta, Message } from '@/lib/types';
import { cn, formatBytes } from '@/lib/utils';
import { Markdown } from '@/components/markdown';
import { Sources } from '@/components/sources';
import { Thinking } from '@/components/thinking';
import { Button, IconButton } from '@/components/ui/button';

export interface MessageItemProps {
  message: Message;
  /** True while this particular message is the one being streamed. */
  streaming?: boolean;
  /** Web-search queries issued for this turn. */
  queries?: string[];
  onEdit?: (message: Message, nextText: string) => void;
  onRegenerate?: (message: Message) => void;
  onRetry?: (message: Message) => void;
}

function AttachmentChip({ attachment }: { attachment: AttachmentMeta }) {
  const isImage = attachment.kind === 'image' && attachment.dataUrl;
  return (
    <span className="inline-flex max-w-full items-center gap-2 rounded-[var(--radius-sm)] border border-line bg-[rgb(var(--panel)/0.6)] px-2 py-1.5">
      {isImage ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={attachment.dataUrl} alt="" className="h-9 w-9 rounded object-cover" />
      ) : (
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded bg-[rgb(var(--accent)/0.12)] text-[0.58rem] font-semibold uppercase text-accent">
          {attachment.name.split('.').pop()?.slice(0, 4) ?? '?'}
        </span>
      )}
      <span className="min-w-0">
        <span className="block max-w-[14rem] truncate text-xs font-medium text-ink">
          {attachment.name}
        </span>
        <span className="block text-[0.68rem] text-subtle">
          {attachment.analyzable
            ? formatBytes(attachment.size)
            : (attachment.note ?? 'Not readable')}
        </span>
      </span>
    </span>
  );
}

function MessageItemComponent({
  message,
  streaming = false,
  queries = [],
  onEdit,
  onRegenerate,
  onRetry,
}: MessageItemProps) {
  const [copied, setCopied] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(message.content);

  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(message.content);
    } catch {
      const area = document.createElement('textarea');
      area.value = message.content;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      try {
        document.execCommand('copy');
      } catch {
        /* nothing else we can do */
      }
      document.body.removeChild(area);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }, [message.content]);

  const isUser = message.role === 'user';
  const hasContent = message.content.trim().length > 0;
  const isError = message.status === 'error';

  return (
    <article
      className={cn(
        'group/message animate-fade-up w-full',
        isUser ? 'pl-auto' : 'pr-auto',
      )}
      aria-label={isUser ? 'Your message' : 'YuvanX response'}
    >
      <div className={cn('flex gap-3', isUser ? 'justify-end' : 'justify-start')}>
        {!isUser ? (
          <div
            aria-hidden="true"
            className="accent-gradient mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-[9px] text-[0.7rem] font-bold text-accent-contrast shadow-soft"
          >
            Y
          </div>
        ) : null}

        <div className={cn('min-w-0 max-w-[min(46rem,88%)]', isUser && 'flex flex-col items-end')}>
          {isUser ? (
            <div className="rounded-[var(--radius-lg)] rounded-tr-md border border-line bg-[rgb(var(--panel)/0.72)] px-4 py-2.5">
              {message.attachments.length > 0 ? (
                <div className="mb-2 flex flex-wrap gap-2">
                  {message.attachments.map((attachment) => (
                    <AttachmentChip key={attachment.id} attachment={attachment} />
                  ))}
                </div>
              ) : null}

              {editing ? (
                <div className="min-w-[16rem] max-w-[34rem]">
                  <textarea
                    value={draft}
                    autoFocus
                    rows={Math.min(10, Math.max(2, draft.split('\n').length + 1))}
                    onChange={(event) => setDraft(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === 'Escape') {
                        event.preventDefault();
                        setDraft(message.content);
                        setEditing(false);
                      }
                      if (event.key === 'Enter' && (event.metaKey || event.ctrlKey)) {
                        event.preventDefault();
                        const next = draft.trim();
                        if (next && next !== message.content) {
                          onEdit?.(message, next);
                        }
                        setEditing(false);
                      }
                    }}
                    aria-label="Edit your message"
                    className={cn(
                      'w-full resize-none rounded-[var(--radius-sm)] border border-line-strong bg-[rgb(var(--panel-solid)/0.9)]',
                      'px-3 py-2 text-[0.9375rem] leading-relaxed text-ink',
                      'focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30',
                    )}
                  />
                  <div className="mt-2 flex items-center justify-end gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setDraft(message.content);
                        setEditing(false);
                      }}
                    >
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      variant="primary"
                      disabled={!draft.trim() || draft.trim() === message.content}
                      onClick={() => {
                        const next = draft.trim();
                        if (next && next !== message.content) {
                          onEdit?.(message, next);
                        }
                        setEditing(false);
                      }}
                    >
                      Save &amp; resend
                    </Button>
                  </div>
                </div>
              ) : hasContent ? (
                <p className="whitespace-pre-wrap break-words text-[0.9375rem] leading-relaxed text-ink">
                  {message.content}
                </p>
              ) : null}
            </div>
          ) : (
            <div className="min-w-0">
              {!hasContent && streaming ? (
                <Thinking key={`live-${message.id}`} queries={queries} />
              ) : null}

              {hasContent ? (
                <Markdown
                  content={message.content}
                  className={streaming ? 'yx-streaming' : undefined}
                />
              ) : null}

              {isError ? (
                <div
                  role="alert"
                  className="mt-2 flex flex-wrap items-center gap-2.5 rounded-[var(--radius-md)] border border-[rgb(var(--danger)/0.35)] bg-[rgb(var(--danger)/0.08)] px-3 py-2.5"
                >
                  <TriangleAlert size={15} className="shrink-0 text-danger" />
                  <p className="min-w-0 flex-1 text-xs leading-relaxed text-ink">
                    {message.error ?? 'Something went wrong while generating this response.'}
                  </p>
                  {onRetry ? (
                    <Button size="sm" variant="outline" onClick={() => onRetry(message)}>
                      <RotateCcw size={12} />
                      Retry
                    </Button>
                  ) : null}
                </div>
              ) : null}

              {message.status === 'stopped' && hasContent ? (
                <p className="mt-2 text-[0.7rem] text-subtle">Generation stopped.</p>
              ) : null}

              <Sources sources={message.sources} />
            </div>
          )}

          {/* Action bar sits outside the user/assistant branches so that the
              edit affordance is reachable on user messages too. */}
          {!streaming && !editing && (hasContent || isError) ? (
            <div
              className={cn(
                'mt-2 flex items-center gap-0.5 opacity-0 transition-opacity',
                'focus-within:opacity-100 group-hover/message:opacity-100',
                isUser && 'justify-end',
              )}
            >
              {hasContent ? (
                <IconButton
                  label={copied ? 'Copied' : isUser ? 'Copy message' : 'Copy response'}
                  onClick={copy}
                  size="icon"
                  className="h-7 w-7"
                >
                  {copied ? (
                    <Check size={13} className="text-success" />
                  ) : (
                    <Copy size={13} />
                  )}
                </IconButton>
              ) : null}

              {isUser && onEdit ? (
                <IconButton
                  label="Edit message"
                  onClick={() => {
                    setDraft(message.content);
                    setEditing(true);
                  }}
                  size="icon"
                  className="h-7 w-7"
                >
                  <Pencil size={13} />
                </IconButton>
              ) : null}

              {!isUser && onRegenerate ? (
                <IconButton
                  label="Regenerate response"
                  onClick={() => onRegenerate(message)}
                  size="icon"
                  className="h-7 w-7"
                >
                  <RefreshCw size={13} />
                </IconButton>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
    </article>
  );
}

export const MessageItem = memo(MessageItemComponent);
