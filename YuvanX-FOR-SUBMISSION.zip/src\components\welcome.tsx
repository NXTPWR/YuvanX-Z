'use client';

import { LogoMark } from '@/components/logo';
import { SUGGESTED_PROMPTS, type SuggestedPrompt } from '@/lib/constants';
import { cn } from '@/lib/utils';

export interface WelcomeProps {
  onSelect: (prompt: string) => void;
  /** True when accounts are available on this deployment. */
  accountsEnabled?: boolean;
  authenticated?: boolean;
  onSignIn?: () => void;
}

const CATEGORY_LABELS: Record<SuggestedPrompt['category'], string> = {
  coding: 'Code',
  research: 'Research',
  learning: 'Learn',
  writing: 'Write',
  brainstorm: 'Ideas',
};

export function Welcome({
  onSelect,
  accountsEnabled = false,
  authenticated = false,
  onSignIn,
}: WelcomeProps) {
  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col items-center px-4 py-10 sm:py-16">
      <div className="animate-fade-up flex flex-col items-center text-center">
        <span className="mb-5 inline-flex">
          <LogoMark size={56} animated className="drop-shadow-[0_10px_30px_rgb(var(--accent)/0.35)]" />
        </span>

        <h1 className="font-display text-2xl font-semibold tracking-tight text-ink sm:text-[1.75rem]">
          What would you like to work on?
        </h1>
        <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">
          YuvanX reads your files, searches the web when you ask it to, and remembers the
          things you want it to remember.
        </p>

        {accountsEnabled && !authenticated && onSignIn ? (
          <button
            type="button"
            onClick={onSignIn}
            className="mt-4 text-sm font-medium text-accent underline-offset-4 transition-colors hover:text-accent-2 hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          >
            Sign in or create a free account
          </button>
        ) : null}
      </div>

      <div className="mt-9 grid w-full gap-2.5 sm:grid-cols-2">
        {SUGGESTED_PROMPTS.map((prompt, index) => (
          <button
            key={prompt.label}
            type="button"
            onClick={() => onSelect(prompt.prompt)}
            style={{ animationDelay: `${index * 45}ms` }}
            className={cn(
              'group animate-fade-up rounded-[var(--radius-md)] border border-line bg-[rgb(var(--panel)/0.5)]',
              'px-3.5 py-3 text-left transition-all duration-200',
              'hover:-translate-y-0.5 hover:border-accent/45 hover:bg-[rgb(var(--panel)/0.8)] hover:shadow-soft',
              'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
            )}
          >
            <span className="mb-1 inline-block rounded-md bg-[rgb(var(--accent)/0.12)] px-1.5 py-0.5 text-[0.62rem] font-semibold uppercase tracking-wider text-accent">
              {CATEGORY_LABELS[prompt.category]}
            </span>
            <span className="block text-sm font-medium text-ink">{prompt.label}</span>
            <span className="mt-1 block line-clamp-2 text-xs leading-relaxed text-muted">
              {prompt.prompt}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
