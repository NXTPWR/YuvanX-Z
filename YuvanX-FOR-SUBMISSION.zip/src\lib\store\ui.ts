'use client';

import { create } from 'zustand';

export type AuthReason = 'sync' | 'files' | 'account';

export interface UiStore {
  /** Whether the sign-in dialog is open. */
  authOpen: boolean;
  authReason: AuthReason;
  openAuth: (reason?: AuthReason) => void;
  closeAuth: () => void;
}

/** Small UI-only state that needs to be reachable from anywhere. */
export const useUiStore = create<UiStore>()((set) => ({
  authOpen: false,
  authReason: 'sync',
  openAuth: (reason = 'sync') => set({ authOpen: true, authReason: reason }),
  closeAuth: () => set({ authOpen: false }),
}));
