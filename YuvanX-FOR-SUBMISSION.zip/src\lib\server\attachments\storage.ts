import { getServiceClient } from '@/lib/server/supabase';
import { getSupabaseConfig } from '@/lib/server/env';

function safeName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80) || 'file';
}

/**
 * Upload a file into the private Supabase Storage bucket.
 * Returns the storage key, or null when cloud storage is not configured.
 */
export async function storeBytes(
  userId: string,
  bytes: Uint8Array,
  name: string,
  mimeType: string,
  conversationId?: string | null,
): Promise<string | null> {
  const config = getSupabaseConfig();
  const client = getServiceClient();
  if (!config?.serviceRoleKey || !client) return null;

  const key = `${userId}/${conversationId ?? 'unfiled'}/${crypto.randomUUID()}-${safeName(name)}`;

  try {
    await client.storage.createBucket(config.bucket, {
      public: false,
      fileSizeLimit: 20 * 1024 * 1024,
    });
  } catch {
    // Bucket already exists (or cannot be created) — the upload below reports
    // the real problem if anything is wrong.
  }

  const { error } = await client.storage.from(config.bucket).upload(key, bytes, {
    contentType: mimeType || 'application/octet-stream',
    upsert: false,
  });
  if (error) throw new Error(`Could not store the uploaded file: ${error.message}`);
  return key;
}

/** Download a previously stored file. Returns null when it is unavailable. */
export async function loadBytes(userId: string, storageKey: string): Promise<Uint8Array | null> {
  const config = getSupabaseConfig();
  const client = getServiceClient();
  if (!config?.serviceRoleKey || !client) return null;
  // Ownership check: the key must live under the requesting user's folder.
  if (!storageKey.startsWith(`${userId}/`)) return null;
  try {
    const { data, error } = await client.storage.from(config.bucket).download(storageKey);
    if (error || !data) return null;
    const buffer = Buffer.from(await data.arrayBuffer());
    return new Uint8Array(buffer);
  } catch {
    return null;
  }
}

/** Remove a stored file. */
export async function removeBytes(userId: string, storageKey: string): Promise<void> {
  const config = getSupabaseConfig();
  const client = getServiceClient();
  if (!config?.serviceRoleKey || !client) return;
  if (!storageKey.startsWith(`${userId}/`)) return;
  try {
    await client.storage.from(config.bucket).remove([storageKey]);
  } catch {
    // Best effort — orphaned files are harmless.
  }
}
