/**
 * Server-only environment access.
 *
 * IMPORTANT: this module must never be imported from a client component.
 * It reads secrets that must stay on the server (GEMINI_API_KEY,
 * SUPABASE_SERVICE_ROLE_KEY, FALLBACK_API_KEY).
 */

export interface GeminiConfig {
  apiKey: string;
  model: string;
  fallbackModels: string[];
  timeoutMs: number;
  maxOutputTokens: number;
  /** Token budget for the secondary provider, which may cap it much lower. */
  fallbackMaxOutputTokens: number;
  thinkingLevel: 'low' | 'medium' | 'high';
  store: boolean;
  /** Base URL of the Generative Language API — overridable for gateways. */
  baseUrl: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  serviceRoleKey: string;
  bucket: string;
  /**
   * Create accounts already confirmed so sign-up works without an email
   * provider. Set to "false" to use Supabase's standard confirmation email.
   */
  autoConfirmSignup: boolean;
}

export interface FallbackProviderConfig {
  apiKey: string;
  baseUrl: string;
  model: string;
}

export interface ServerConfig {
  gemini: GeminiConfig | null;
  supabase: SupabaseConfig | null;
  fallback: FallbackProviderConfig | null;
  dailyRequestLimit: number;
  requestsPerMinute: number;
  siteUrl: string;
}

function clean(value: string | undefined): string {
  return (value ?? '').trim();
}

/** The public Generative Language API endpoint. */
export const DEFAULT_GEMINI_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta';

export function getGeminiConfig(): GeminiConfig | null {
  const apiKey = clean(process.env.GEMINI_API_KEY);
  if (!apiKey) return null;
  const model = clean(process.env.GEMINI_MODEL) || 'gemini-3.8-flash';
  const fallbackModels = clean(process.env.GEMINI_FALLBACK_MODELS)
    .split(',')
    .map((m) => m.trim())
    .filter(Boolean)
    .filter((m) => m !== model);
  const timeoutMs = Number.parseInt(clean(process.env.GEMINI_TIMEOUT_MS) || '90000', 10);
  const maxOutputTokens = Number.parseInt(
    clean(process.env.GEMINI_MAX_OUTPUT_TOKENS) || '8192',
    10,
  );
  const rawLevel = clean(process.env.GEMINI_THINKING_LEVEL).toLowerCase();
  const thinkingLevel: 'low' | 'medium' | 'high' =
    rawLevel === 'medium' || rawLevel === 'high' ? rawLevel : 'low';
  const store = clean(process.env.GEMINI_STORE).toLowerCase() !== 'false';
  const fallbackMaxOutputTokens = Number.parseInt(
    clean(process.env.FALLBACK_MAX_OUTPUT_TOKENS) || '900',
    10,
  );
  const baseUrl = (clean(process.env.GEMINI_API_BASE) || DEFAULT_GEMINI_BASE_URL).replace(
    /\/+$/,
    '',
  );
  return {
    apiKey,
    model,
    fallbackModels,
    timeoutMs: Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : 90_000,
    maxOutputTokens:
      Number.isFinite(maxOutputTokens) && maxOutputTokens > 0 ? maxOutputTokens : 8192,
    fallbackMaxOutputTokens:
      Number.isFinite(fallbackMaxOutputTokens) && fallbackMaxOutputTokens > 0
        ? fallbackMaxOutputTokens
        : 900,
    thinkingLevel,
    store,
    baseUrl,
  };
}

export function getSupabaseConfig(): SupabaseConfig | null {
  const url = clean(process.env.NEXT_PUBLIC_SUPABASE_URL);
  const anonKey = clean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
  const serviceRoleKey = clean(process.env.SUPABASE_SERVICE_ROLE_KEY);
  if (!url || !anonKey) return null;
  return {
    url,
    anonKey,
    serviceRoleKey,
    bucket: clean(process.env.SUPABASE_STORAGE_BUCKET) || 'yuvanx-files',
    autoConfirmSignup: clean(process.env.SUPABASE_AUTO_CONFIRM).toLowerCase() !== 'false',
  };
}

/** True when Supabase is configured well enough to persist data server-side. */
export function hasCloudPersistence(): boolean {
  const cfg = getSupabaseConfig();
  return Boolean(cfg && cfg.serviceRoleKey);
}

export function getFallbackProviderConfig(): FallbackProviderConfig | null {
  // Accept either the generic FALLBACK_* names or Groq's own names, so a free
  // Groq key can be dropped in without a rename.
  const apiKey = clean(process.env.FALLBACK_API_KEY) || clean(process.env.GROQ_API_KEY);
  const baseUrl =
    clean(process.env.FALLBACK_BASE_URL) ||
    (clean(process.env.GROQ_API_KEY) ? 'https://api.groq.com/openai/v1' : '');
  const model =
    clean(process.env.FALLBACK_MODEL) ||
    (clean(process.env.GROQ_API_KEY) ? 'qwen/qwen3.8-27b' : '');
  if (!apiKey || !baseUrl || !model) return null;
  return { apiKey, baseUrl: baseUrl.replace(/\/+$/, ''), model };
}

export function getServerConfig(): ServerConfig {
  return {
    gemini: getGeminiConfig(),
    supabase: getSupabaseConfig(),
    fallback: getFallbackProviderConfig(),
    dailyRequestLimit: Number.parseInt(clean(process.env.DAILY_REQUEST_LIMIT) || '120', 10),
    requestsPerMinute: Number.parseInt(clean(process.env.REQUESTS_PER_MINUTE) || '20', 10),
    siteUrl: clean(process.env.NEXT_PUBLIC_SITE_URL) || 'http://localhost:3000',
  };
}

/**
 * True when the AI provider is ready to serve requests.
 * The UI uses this to show a helpful setup screen instead of failing silently.
 */
export function isProviderConfigured(): boolean {
  return getGeminiConfig() !== null;
}
