import { getGeminiConfig } from '@/lib/server/env';
import {
  AIProviderError,
  type AIProvider,
  type ProviderCallbacks,
  type ProviderRequest,
  type ProviderResult,
  type ResolvedAttachment,
  type TokenUsage,
} from '@/lib/server/ai/types';
import type { Source } from '@/lib/types';

interface SseBlock {
  event: string;
  data: string;
}

/**
 * How long to wait for response headers / the first streamed byte before
 * giving up on a model. A healthy Gemini start is well under a second; a
 * stalled one used to hold the whole request for the full 90-second deadline.
 */
const CONNECT_TIMEOUT_MS = 10_000;

/** How long a stream may go completely silent before it is abandoned. */
const IDLE_TIMEOUT_MS = 20_000;

function parseSseBlock(raw: string): SseBlock | null {
  let event = 'message';
  const dataLines: string[] = [];
  for (const line of raw.split('\n')) {
    if (!line || line.startsWith(':')) continue;
    const colon = line.indexOf(':');
    const field = colon === -1 ? line : line.slice(0, colon);
    let value = colon === -1 ? '' : line.slice(colon + 1);
    if (value.startsWith(' ')) value = value.slice(1);
    if (field === 'event') event = value;
    else if (field === 'data') dataLines.push(value);
  }
  if (dataLines.length === 0) return null;
  return { event, data: dataLines.join('\n') };
}

async function* readSse(response: Response): AsyncGenerator<SseBlock> {
  const body = response.body;
  if (!body) return;
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    buffer = buffer.replace(/\r\n/g, '\n');
    let index = buffer.indexOf('\n\n');
    while (index !== -1) {
      const raw = buffer.slice(0, index);
      buffer = buffer.slice(index + 2);
      const block = parseSseBlock(raw);
      if (block) yield block;
      index = buffer.indexOf('\n\n');
    }
  }
  const tail = buffer.trim();
  if (tail) {
    const block = parseSseBlock(tail);
    if (block) yield block;
  }
}

function toBase64(bytes: Uint8Array): string {
  return Buffer.from(bytes).toString('base64');
}

interface GeminiContent {
  type: 'text' | 'image' | 'document';
  text?: string;
  data?: string;
  mime_type?: string;
}

interface GeminiStep {
  type: 'user_input' | 'model_output';
  content: GeminiContent[];
}

function buildSteps(turns: ProviderRequest['turns']): GeminiStep[] {
  const steps: GeminiStep[] = [];

  for (const turn of turns) {
    if (turn.role === 'assistant') {
      if (!turn.content) continue;
      steps.push({
        type: 'model_output',
        content: [{ type: 'text', text: turn.content }],
      });
      continue;
    }

    const content: GeminiContent[] = [];
    if (turn.content.trim()) content.push({ type: 'text', text: turn.content });

    for (const attachment of turn.attachments ?? []) {
      const part = toContentPart(attachment);
      if (part) content.push(part);
    }

    if (content.length > 0) {
      steps.push({ type: 'user_input', content });
    }
  }

  return steps;
}

function toContentPart(attachment: ResolvedAttachment): GeminiContent | null {
  if (attachment.bytes && attachment.kind === 'image') {
    return {
      type: 'image',
      data: toBase64(attachment.bytes),
      mime_type: attachment.mimeType || 'image/png',
    };
  }
  if (attachment.bytes && attachment.kind === 'pdf') {
    return {
      type: 'document',
      data: toBase64(attachment.bytes),
      mime_type: 'application/pdf',
    };
  }
  if (attachment.text) {
    return {
      type: 'text',
      text: `\n\n--- Attachment: ${attachment.name} ---\n${attachment.text}`,
    };
  }
  return null;
}

function mapHttpError(status: number, body: string): AIProviderError {
  let message = `Gemini request failed (${status}).`;

  try {
    const parsed = JSON.parse(body) as { error?: { message?: string; status?: string } };
    if (parsed?.error?.message) message = parsed.error.message;
  } catch {
    if (body && body.length < 400) message = body;
  }

  if (status === 401 || status === 403) {
    return new AIProviderError(
      'auth',
      'The Gemini API key was rejected. Check GEMINI_API_KEY in your environment.',
      false,
      status,
    );
  }
  if (status === 429) {
    // The free tier only allows a small number of requests per day. When the
    // daily allowance is spent the provider tells us when it resets — that is
    // a different situation from a short burst limit.
    if (/per day|daily/i.test(message)) {
      return new AIProviderError('quota_exceeded', message, false, status);
    }
    // Google also returns a bare "You exceeded your current quota, please
    // check your plan and billing details." with no reset time when a feature
    // such as Google Search grounding is not available on the free tier.
    // Treat it as a spent allowance rather than a throttle — parking for a few
    // seconds would only produce the same error again.
    if (/exceeded your current quota|check your (plan|billing)|billing details/i.test(message)) {
      return new AIProviderError(
        'quota_exceeded',
        'This API key has used up its free-tier allowance, or the requested feature (web search) is not included in the free tier. It resets on Google\u2019s schedule — try again later, or use a paid Gemini API key.',
        false,
        status,
      );
    }
    // Pass along the provider's own retry hint when it gives one, in words a
    // person can act on. Falling back to "a minute" keeps it friendly.
    const hint = /retry in\s+([\d.]+)\s*s/i.exec(message)?.[1];
    const seconds = hint ? Math.max(1, Math.ceil(Number(hint))) : null;
    return new AIProviderError(
      'rate_limit',
      seconds
        ? `Gemini is asking us to slow down — the free tier allows only a few messages per minute. Try again in about ${seconds} seconds.`
        : 'Gemini is asking us to slow down — the free tier allows only a few messages per minute. Try again in about a minute.',
      true,
      status,
    );
  }
  if (status === 404 || /not found|not supported|is not supported for/i.test(message)) {
    return new AIProviderError('model_not_found', message, false, status);
  }
  if (status === 400) {
    return new AIProviderError('invalid_request', message, false, status);
  }
  if (status === 503 || /service_unavailable|high demand|currently experiencing/i.test(message)) {
    // The model is at capacity. Retrying it straight away only burns the
    // user's time, so this is reported separately and failed over quickly.
    return new AIProviderError(
      'overloaded',
      message || 'The Gemini service is temporarily unavailable.',
      false,
      status,
    );
  }
  if (status >= 500) {
    return new AIProviderError(
      'unavailable',
      'The Gemini service is temporarily unavailable.',
      true,
      status,
    );
  }
  return new AIProviderError('unknown', message, false, status);
}

interface GeminiInteraction {
  id?: string;
  status?: string;
  usage?: {
    total_input_tokens?: number;
    total_output_tokens?: number;
    total_thought_tokens?: number;
    total_tokens?: number;
  };
}

export const geminiProvider: AIProvider = {
  id: 'gemini',
  label: 'Google Gemini',
  supportsAttachments: true,
  supportsSearch: true,

  async stream(
    request: ProviderRequest,
    callbacks: ProviderCallbacks,
  ): Promise<ProviderResult> {
    const config = getGeminiConfig();
    if (!config) {
      throw new AIProviderError(
        'auth',
        'GEMINI_API_KEY is not configured on the server.',
        false,
      );
    }

    const steps = buildSteps(request.turns);
    if (steps.length === 0) {
      throw new AIProviderError('invalid_request', 'Nothing to send to the model.', false);
    }

    const body: Record<string, unknown> = {
      model: request.model,
      input: steps,
      system_instruction: request.system,
      stream: true,
    };

    if (request.webSearch) body.tools = [{ type: 'google_search' }];

    const generationConfig: Record<string, unknown> = {};
    if (request.maxOutputTokens > 0) {
      generationConfig.max_output_tokens = request.maxOutputTokens;
    }
    generationConfig.thinking_level = request.thinkingLevel;
    body.generation_config = generationConfig;

    if (!request.store) body.store = false;

    const timeoutController = new AbortController();
    const startedAt = Date.now();
    const totalMs = request.timeoutMs;
    const remaining = () => Math.max(1_000, totalMs - (Date.now() - startedAt));
    let watchdog: ReturnType<typeof setTimeout> | undefined;
    let timedOutOn: 'connect' | 'idle' | null = null;
    /**
     * A single 90-second deadline is far too coarse: a stalled connection and
     * a stalled stream both look like "the user is waiting with no answer".
     * Arm a short budget for the first byte, then a longer one between chunks.
     */
    const arm = (ms: number, reason: 'connect' | 'idle') => {
      if (watchdog) clearTimeout(watchdog);
      timedOutOn = reason;
      watchdog = setTimeout(() => timeoutController.abort(), ms);
    };
    arm(Math.min(CONNECT_TIMEOUT_MS, totalMs), 'connect');
    const signal = AbortSignal.any([request.signal, timeoutController.signal]);

    let interactionId: string | undefined;
    let usage: TokenUsage | undefined;
    let text = '';
    const searchQueries: string[] = [];
    let streamError: AIProviderError | null = null;

    try {
      const response = await fetch(`${config.baseUrl}/interactions?alt=sse`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-goog-api-key': config.apiKey,
        },
        body: JSON.stringify(body),
        signal,
        cache: 'no-store',
      });

      if (!response.ok) {
        const errorBody = await response.text().catch(() => '');
        throw mapHttpError(response.status, errorBody);
      }

      arm(Math.min(IDLE_TIMEOUT_MS, remaining()), 'idle');

      for await (const block of readSse(response)) {
        // Any traffic means the connection is alive: restart the idle clock.
        arm(Math.min(IDLE_TIMEOUT_MS, remaining()), 'idle');
        if (block.data === '[DONE]') break;
        let payload: Record<string, unknown>;
        try {
          payload = JSON.parse(block.data) as Record<string, unknown>;
        } catch {
          continue;
        }

        const eventType = (payload.event_type as string) || block.event;

        if (eventType === 'error') {
          const error = payload.error as { message?: string; code?: string } | undefined;
          const message = error?.message ?? '';
          const overloaded =
            error?.code === 'service_unavailable' ||
            /high demand|currently experiencing/i.test(message);
          const quota = /per day|daily/i.test(message);
          streamError = new AIProviderError(
            overloaded ? 'overloaded' : quota ? 'quota_exceeded' : 'unavailable',
            message || 'The model stream reported an error.',
            !overloaded && !quota,
          );
          break;
        }

        if (eventType === 'interaction.created') {
          const interaction = payload.interaction as GeminiInteraction | undefined;
          interactionId = interaction?.id;
          continue;
        }

        if (eventType === 'interaction.completed') {
          const interaction = payload.interaction as GeminiInteraction | undefined;
          interactionId = interaction?.id ?? interactionId;
          if (interaction?.usage) {
            usage = {
              inputTokens: interaction.usage.total_input_tokens,
              outputTokens: interaction.usage.total_output_tokens,
              thoughtTokens: interaction.usage.total_thought_tokens,
              totalTokens: interaction.usage.total_tokens,
            };
          }
          continue;
        }

        if (eventType === 'step.delta') {
          const delta = payload.delta as
            | {
                type?: string;
                text?: string;
                arguments?: { queries?: string[] };
              }
            | undefined;
          if (!delta) continue;
          if (delta.type === 'text' && typeof delta.text === 'string' && delta.text) {
            text += delta.text;
            callbacks.onText(delta.text);
          } else if (delta.type === 'google_search_call') {
            const queries = delta.arguments?.queries ?? [];
            for (const query of queries) {
              if (query && !searchQueries.includes(query)) searchQueries.push(query);
            }
            if (queries.length) callbacks.onSearch?.([...searchQueries]);
          }
        }
      }
    } catch (error) {
      if (error instanceof AIProviderError) throw error;
      if (request.signal.aborted) {
        throw new AIProviderError('aborted', 'The request was cancelled.', false);
      }
      if (timeoutController.signal.aborted) {
        throw new AIProviderError(
          'timeout',
          timedOutOn === 'connect'
            ? 'The model did not start answering in time.'
            : 'The model stopped sending its answer and the request timed out.',
          true,
        );
      }
      throw new AIProviderError(
        'unavailable',
        error instanceof Error ? error.message : 'Network error while contacting Gemini.',
        true,
      );
    } finally {
      if (watchdog) clearTimeout(watchdog);
    }

    if (streamError) throw streamError;

    let sources: Source[] = [];
    // Citations can only exist for a grounded answer. Looking them up after an
    // ordinary reply used to add ~2 seconds to every message for nothing.
    if (interactionId && request.store && request.webSearch) {
      sources = await fetchCitations(config.apiKey, interactionId, config.baseUrl);
    }

    return { text, sources, model: request.model, usage, searchQueries };
  },
};

/**
 * Retrieve the finished interaction to extract real citation metadata.
 * This is best-effort: if the lookup fails the answer is still returned, it
 * simply has no clickable sources attached.
 */
async function fetchCitations(
  apiKey: string,
  interactionId: string,
  baseUrl: string,
): Promise<Source[]> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 6000);
  try {
    const response = await fetch(`${baseUrl}/interactions/${encodeURIComponent(interactionId)}`, {
      headers: { 'x-goog-api-key': apiKey },
      signal: controller.signal,
      cache: 'no-store',
    });
    if (!response.ok) return [];
    const payload = (await response.json()) as {
      steps?: Array<{
        type?: string;
        content?: Array<{
          type?: string;
          text?: string;
          annotations?: Array<{
            type?: string;
            url?: string;
            title?: string;
          }>;
        }>;
      }>;
    };
    const sources: Source[] = [];
    const seen = new Set<string>();
    for (const step of payload.steps ?? []) {
      if (step.type !== 'model_output') continue;
      for (const block of step.content ?? []) {
        for (const annotation of block.annotations ?? []) {
          if (annotation.type !== 'url_citation') continue;
          const url = annotation.url;
          if (!url || seen.has(url)) continue;
          seen.add(url);
          sources.push({ url, title: annotation.title || new URL(url).hostname });
        }
      }
    }
    return sources;
  } catch {
    return [];
  } finally {
    clearTimeout(timer);
  }
}
