/**
 * Memory helpers that are safe to run in the browser.
 *
 * Both the server routes and the client store use these, so a guest never
 * ends up with a credential saved locally that a signed-in user would have
 * been blocked from storing in the cloud.
 */

/**
 * Patterns that indicate a secret. Anything matching these is never written
 * to the memory store, even if the user explicitly asks for it.
 */
const SENSITIVE_PATTERNS: RegExp[] = [
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/i,
  /\bAKIA[0-9A-Z]{16}\b/,
  /\bASIA[0-9A-Z]{16}\b/,
  /\bAIza[0-9A-Za-z\-_]{35}\b/,
  /\bsk-[A-Za-z0-9_-]{8,}\b/,
  /\bgh[pousr]_[A-Za-z0-9]{20,}\b/,
  /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/,
  /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}\b/,
  // "password: hunter2", "api key = …", "my password is hunter2", "the token is abc123"
  /\b(?:password|passwd|pwd|passphrase|secret|api[_-]?key|access[_-]?key|access[_-]?token|auth[_-]?token|refresh[_-]?token|private[_-]?key|client[_-]?secret|credential|token)\b\s*(?:[:=]|\bis\b|\bare\b|\bwas\b)\s*\S{3,}/i,
  // Bare "my password is …" phrasing without the keywords above.
  /\b(?:my|the|our)\s+(?:new\s+)?(?:password|passcode|pin|api\s+key|secret)\b/i,
  /\bbearer\s+[A-Za-z0-9\-._~+/]{20,}=*/i,
  /\b(?:0x)?[0-9a-f]{64}\b(?=[^\n]*(wallet|seed|mnemonic|private))/i,
  // Card-like and government-id-like numbers.
  /\b(?:\d[ -]?){13,19}\b/,
  /\b\d{3}-\d{2}-\d{4}\b/,
];

/** True when the text looks like it contains a credential or secret. */
export function containsSensitiveData(text: string): boolean {
  if (!text) return false;
  return SENSITIVE_PATTERNS.some((pattern) => pattern.test(text));
}

/** Normalise a memory so it stores as one tidy, bounded paragraph. */
export function sanitizeMemoryContent(content: string): string {
  return content
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .trim()
    .slice(0, 600);
}

/** The message shown when a memory is rejected because it contains a secret. */
export const SENSITIVE_MEMORY_MESSAGE =
  'That looks like a password or API key. YuvanX will not store credentials — please remove the secret.';
