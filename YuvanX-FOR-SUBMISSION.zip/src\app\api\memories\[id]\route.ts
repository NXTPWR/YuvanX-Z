import { NextResponse } from 'next/server';
import { resolveIdentity } from '@/lib/server/supabase';
import { deleteMemory, updateMemory } from '@/lib/server/db';
import { containsSensitiveData, sanitizeMemoryContent, SENSITIVE_MEMORY_MESSAGE } from '@/lib/memory';
import type { MemoryCategory } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Context = { params: Promise<{ id: string }> };

const VALID_CATEGORIES: MemoryCategory[] = ['preference', 'project', 'instruction', 'fact', 'note'];

export async function PATCH(request: Request, context: Context) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json({ error: 'Not signed in.', code: 'unauthenticated' }, { status: 401 });
  }
  const { id } = await context.params;
  const body = (await request.json().catch(() => ({}))) as {
    content?: string;
    category?: MemoryCategory;
    enabled?: boolean;
  };

  try {
    const patch: { content?: string; category?: MemoryCategory; enabled?: boolean } = {};
    if (body.content !== undefined) {
      const content = sanitizeMemoryContent(body.content);
      if (!content) {
        return NextResponse.json({ error: 'A memory needs some content.' }, { status: 400 });
      }
      if (containsSensitiveData(content)) {
        return NextResponse.json(
          { error: SENSITIVE_MEMORY_MESSAGE, code: 'sensitive' },
          { status: 400 },
        );
      }
      patch.content = content;
    }
    if (body.category !== undefined && VALID_CATEGORIES.includes(body.category)) {
      patch.category = body.category;
    }
    if (body.enabled !== undefined) patch.enabled = body.enabled;

    const memory = await updateMemory(identity.userId, id, patch);
    if (!memory) {
      return NextResponse.json({ error: 'Not found.', code: 'not_found' }, { status: 404 });
    }
    return NextResponse.json({ memory });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not update the memory.' },
      { status: 500 },
    );
  }
}

export async function DELETE(request: Request, context: Context) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json({ error: 'Not signed in.', code: 'unauthenticated' }, { status: 401 });
  }
  const { id } = await context.params;
  try {
    await deleteMemory(identity.userId, id);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not delete the memory.' },
      { status: 500 },
    );
  }
}
