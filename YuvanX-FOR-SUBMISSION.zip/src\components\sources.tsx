'use client';

import { useState } from 'react';
import { ExternalLink, Globe } from 'lucide-react';
import type { Source } from '@/lib/types';
import { cn } from '@/lib/utils';

export interface SourcesProps {
  sources: Source[];
  className?: string;
}

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

/** The list of web sources that grounded an answer. */
export function Sources({ sources, className }: SourcesProps) {
  const [expanded, setExpanded] = useState(false);

  if (!sources || sources.length === 0) return null;

  const visible = expanded ? sources : sources.slice(0, 4);

  return (
    <section
      aria-label="Web sources"
      className={cn('mt-3 border-t border-line pt-3', className)}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1.5 text-[0.7rem] font-medium uppercase tracking-wider text-subtle">
          <Globe size={12} />
          Sources
        </span>
        <span className="text-[0.7rem] text-subtle">{sources.length}</span>
      </div>

      <ul className="mt-2 flex flex-wrap gap-1.5">
        {visible.map((source, index) => (
          <li key={`${source.url}-${index}`}>
            <a
              href={source.url}
              target="_blank"
              rel="noopener noreferrer nofollow"
              title={source.title ? `${source.title} — ${source.url}` : source.url}
              className={cn(
                'group inline-flex max-w-[19rem] items-center gap-1.5 rounded-full border border-line',
                'bg-[rgb(var(--panel)/0.6)] px-2.5 py-1 text-[0.72rem] text-muted',
                'transition-colors hover:border-accent/50 hover:text-ink',
                'focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent',
              )}
            >
              <span className="truncate">{source.title?.trim() || hostOf(source.url)}</span>
              <ExternalLink
                size={10}
                className="shrink-0 opacity-50 transition-opacity group-hover:opacity-100"
              />
            </a>
          </li>
        ))}
      </ul>

      {sources.length > 4 ? (
        <button
          type="button"
          onClick={() => setExpanded((value) => !value)}
          className="mt-2 text-[0.72rem] font-medium text-accent transition-colors hover:text-accent-2 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
        >
          {expanded ? 'Show fewer' : `Show ${sources.length - 4} more`}
        </button>
      ) : null}
    </section>
  );
}
