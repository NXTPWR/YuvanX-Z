'use client';

import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  alpha: number;
}

const PARTICLE_COUNT = 46;

/**
 * The ambient backdrop: drifting light blobs, a subtle particle field and a
 * cursor-follow glow.
 *
 * The canvas animation is fully torn down on unmount, pauses when the tab is
 * hidden and is disabled entirely when the user asks for reduced motion.
 */
export function Background() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext('2d');
    if (!context) return;

    const root = document.documentElement;
    let width = 0;
    let height = 0;
    let ratio = 1;
    let particles: Particle[] = [];
    let frame = 0;
    let running = true;
    let visible = true;
    let reduced = false;

    const readAccent = () => {
      const accent = getComputedStyle(root).getPropertyValue('--accent').trim();
      const [r = 124, g = 138, b = 255] = accent.split(/\s+/).map((value) => Number(value) || 0);
      return `rgba(${r}, ${g}, ${b},`;
    };

    const seed = () => {
      particles = Array.from({ length: PARTICLE_COUNT }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.16,
        vy: (Math.random() - 0.5) * 0.16,
        r: Math.random() * 1.6 + 0.5,
        alpha: Math.random() * 0.32 + 0.08,
      }));
    };

    const resize = () => {
      ratio = Math.min(window.devicePixelRatio || 1, 2);
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = Math.floor(width * ratio);
      canvas.height = Math.floor(height * ratio);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      seed();
    };

    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const syncMotion = () => {
      reduced =
        motionQuery.matches ||
        root.getAttribute('data-motion') === 'off' ||
        root.getAttribute('data-motion') === 'reduced';
      if (reduced) {
        context.clearRect(0, 0, width, height);
      }
    };

    const draw = () => {
      if (!running) return;
      frame = window.requestAnimationFrame(draw);
      if (!visible || reduced) return;

      context.clearRect(0, 0, width, height);
      const accent = readAccent();

      for (const particle of particles) {
        particle.x += particle.vx;
        particle.y += particle.vy;

        if (particle.x < -10) particle.x = width + 10;
        if (particle.x > width + 10) particle.x = -10;
        if (particle.y < -10) particle.y = height + 10;
        if (particle.y > height + 10) particle.y = -10;

        context.beginPath();
        context.fillStyle = `${accent}${particle.alpha})`;
        context.arc(particle.x, particle.y, particle.r, 0, Math.PI * 2);
        context.fill();
      }
    };

    const onVisibility = () => {
      visible = document.visibilityState === 'visible';
    };

    const onPointerMove = (event: PointerEvent) => {
      const glow = glowRef.current;
      if (!glow) return;
      glow.style.transform = `translate3d(${event.clientX - 320}px, ${event.clientY - 320}px, 0)`;
    };

    resize();
    syncMotion();
    frame = window.requestAnimationFrame(draw);

    window.addEventListener('resize', resize);
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    document.addEventListener('visibilitychange', onVisibility);
    motionQuery.addEventListener('change', syncMotion);

    const observer = new MutationObserver(syncMotion);
    observer.observe(root, { attributes: true, attributeFilter: ['data-motion'] });

    return () => {
      running = false;
      window.cancelAnimationFrame(frame);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onPointerMove);
      document.removeEventListener('visibilitychange', onVisibility);
      motionQuery.removeEventListener('change', syncMotion);
      observer.disconnect();
    };
  }, []);

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="aurora-layer">
        <div className="aurora-blob aurora-blob--one" />
        <div className="aurora-blob aurora-blob--two" />
        <div className="aurora-blob aurora-blob--three" />
      </div>
      <div className="grid-overlay" />
      <canvas ref={canvasRef} className="fixed inset-0 h-full w-full" />
      <div
        ref={glowRef}
        className="fixed left-0 top-0 h-[640px] w-[640px] rounded-full opacity-[0.16] transition-transform duration-500 ease-out will-change-transform"
        style={{
          background:
            'radial-gradient(circle, rgb(var(--accent) / 0.5) 0%, rgb(var(--accent) / 0.14) 38%, transparent 68%)',
          filter: 'blur(28px)',
        }}
      />
      <div className="vignette" />
    </div>
  );
}
