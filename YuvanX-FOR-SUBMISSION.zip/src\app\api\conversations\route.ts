import { NextResponse } from 'next/server';
import { resolveIdentity } from '@/lib/server/supabase';
import { createConversation, listConversations } from '@/lib/server/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json(
      { error: 'Sign in to sync your conversations across devices.', code: 'unauthenticated' },
      { status: 401 },
    );
  }
  try {
    const conversations = await listConversations(identity.userId);
    return NextResponse.json({ conversations });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not load conversations.' },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  const identity = await resolveIdentity(request);
  if (!identity.userId) {
    return NextResponse.json(
      { error: 'Sign in to sync your conversations across devices.', code: 'unauthenticated' },
      { status: 401 },
    );
  }
  try {
    const body = (await request.json().catch(() => ({}))) as { title?: string; model?: string };
    const conversation = await createConversation(identity.userId, {
      title: body.title?.slice(0, 120) || 'New chat',
      model: body.model,
    });
    return NextResponse.json({ conversation });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Could not create the conversation.' },
      { status: 500 },
    );
  }
}
