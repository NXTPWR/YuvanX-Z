'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import {
  ArrowRight,
  CheckCircle2,
  CircleDashed,
  Cloud,
  KeyRound,
  RefreshCw,
  Terminal,
  TriangleAlert,
} from 'lucide-react';
import { Logo } from '@/components/logo';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface Status {
  ok: boolean;
  providerConfigured: boolean;
  provider: string;
  model: string | null;
  fallbackModels: string[];
  failoverConfigured: boolean;
  cloudPersistence: boolean;
  accountsEnabled: boolean;
  guestMode: boolean;
}

export default function SetupPage() {
  const [status, setStatus] = useState<Status | null>(null);
  const [checking, setChecking] = useState(false);

  const load = useCallback(async (): Promise<Status> => {
    const response = await fetch('/api/status', { cache: 'no-store' });
    return (await response.json()) as Status;
  }, []);

  /** Manual refresh — triggered by a click, so the state updates are fine. */
  const check = useCallback(async () => {
    setChecking(true);
    try {
      setStatus(await load());
    } catch {
      setStatus(null);
    } finally {
      setChecking(false);
    }
  }, [load]);

  /* Initial probe. The state is only touched after the request settles. */
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const data = await load();
        if (!cancelled) setStatus(data);
      } catch {
        if (!cancelled) setStatus(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [load]);

  const ready = status?.providerConfigured ?? false;

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col px-5 py-10 sm:py-16">
      <Logo size={30} />

      <div className="mt-8">
        <span
          className={cn(
            'mb-4 flex h-11 w-11 items-center justify-center rounded-xl text-accent-contrast shadow-soft',
            ready ? 'accent-gradient' : 'bg-[rgb(var(--warning)/0.18)] text-warning',
          )}
        >
          {ready ? <CheckCircle2 size={20} /> : <TriangleAlert size={20} />}
        </span>

        <h1 className="font-display text-2xl font-semibold tracking-tight text-ink sm:text-3xl">
          {ready ? 'YuvanX is ready' : 'One step before YuvanX can answer'}
        </h1>

        <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted">
          {ready
            ? 'The AI provider is configured and reachable. Head to the chat to start a conversation.'
            : 'YuvanX needs a server-side Gemini API key before it can produce real answers. It will never fake a reply — it asks you to finish the setup first.'}
        </p>
      </div>

      {!ready ? (
        <div className="mt-7 space-y-3">
          <Step
            index={1}
            icon={<KeyRound size={16} />}
            title="Create a Gemini API key"
            body={
              <>
                Open the Google AI Studio key page, create a key and copy it. The key stays on the
                server — it is never sent to the browser.
              </>
            }
            action={
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-medium text-accent transition-colors hover:text-accent-2"
              >
                Open AI Studio
                <ArrowRight size={12} />
              </a>
            }
          />

          <Step
            index={2}
            icon={<Terminal size={16} />}
            title="Add it to your environment"
            body={
              <>
                Create <code className="rounded bg-[rgb(var(--accent)/0.12)] px-1 py-0.5 font-mono text-[0.72rem] text-accent">.env.local</code>{' '}
                in the project root with:
                <pre className="mt-2 overflow-x-auto rounded-[var(--radius-sm)] border border-line bg-[rgb(var(--bg-deep)/0.7)] px-3 py-2 font-mono text-[0.72rem] leading-relaxed text-muted">
{`GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash`}
                </pre>
                Then restart the development server.
              </>
            }
          />

          <Step
            index={3}
            icon={<Cloud size={16} />}
            title="Optional: add Supabase"
            body={
              <>
                Run <code className="rounded bg-[rgb(var(--accent)/0.12)] px-1 py-0.5 font-mono text-[0.72rem] text-accent">supabase/schema.sql</code>{' '}
                in your Supabase project to enable accounts, cloud sync and private file storage.
                Without it YuvanX runs honestly in guest mode.
              </>
            }
            optional
          />
        </div>
      ) : null}

      <div className="mt-8 flex flex-wrap items-center gap-3">
        <Button
          variant="primary"
          onClick={() => {
            void check();
          }}
          loading={checking}
        >
          <RefreshCw size={14} />
          Check again
        </Button>

        {ready ? (
          <Link href="/chat">
            <Button variant="outline">
              Open YuvanX
              <ArrowRight size={14} />
            </Button>
          </Link>
        ) : null}
      </div>

      {status ? (
        <dl className="mt-9 grid gap-2.5 sm:grid-cols-2">
          <StatusRow
            label="AI provider"
            ok={status.providerConfigured}
            detail={status.providerConfigured ? (status.model ?? 'configured') : 'not configured'}
          />
          <StatusRow
            label="Failover provider"
            ok={status.failoverConfigured}
            detail={status.failoverConfigured ? 'configured' : 'not configured'}
          />
          <StatusRow
            label="Accounts"
            ok={status.accountsEnabled}
            detail={status.accountsEnabled ? 'enabled' : 'guest mode only'}
          />
          <StatusRow
            label="Cloud persistence"
            ok={status.cloudPersistence}
            detail={status.cloudPersistence ? 'enabled' : 'browser only'}
          />
        </dl>
      ) : null}
    </div>
  );
}

function Step({
  index,
  icon,
  title,
  body,
  action,
  optional = false,
}: {
  index: number;
  icon: React.ReactNode;
  title: string;
  body: React.ReactNode;
  action?: React.ReactNode;
  optional?: boolean;
}) {
  return (
    <section className="glass flex gap-3.5 rounded-[var(--radius-lg)] p-4">
      <span
        aria-hidden="true"
        className="accent-gradient flex h-8 w-8 shrink-0 items-center justify-center rounded-[10px] text-accent-contrast"
      >
        {icon}
      </span>
      <div className="min-w-0 flex-1">
        <h2 className="flex flex-wrap items-center gap-2 text-sm font-semibold text-ink">
          <span className="text-subtle">{index}.</span>
          {title}
          {optional ? (
            <span className="rounded-md bg-[rgb(var(--border)/0.12)] px-1.5 py-0.5 text-[0.6rem] font-semibold uppercase tracking-wider text-subtle">
              Optional
            </span>
          ) : null}
        </h2>
        <div className="mt-1.5 text-xs leading-relaxed text-muted">{body}</div>
        {action ? <div className="mt-2">{action}</div> : null}
      </div>
    </section>
  );
}

function StatusRow({
  label,
  ok,
  detail,
}: {
  label: string;
  ok: boolean;
  detail: string;
}) {
  return (
    <div className="glass flex items-center gap-2.5 rounded-[var(--radius-md)] px-3 py-2.5">
      {ok ? (
        <CheckCircle2 size={15} className="shrink-0 text-success" />
      ) : (
        <CircleDashed size={15} className="shrink-0 text-subtle" />
      )}
      <span className="text-xs font-medium text-ink">{label}</span>
      <span className="ml-auto truncate text-[0.7rem] text-subtle">{detail}</span>
    </div>
  );
}
