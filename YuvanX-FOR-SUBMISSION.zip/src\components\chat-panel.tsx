'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { AlertTriangle, WifiOff } from 'lucide-react';
import { DEFAULT_MODEL } from '@/lib/constants';
import { streamChat, type ChatRequestPayload } from '@/lib/stream';
import { fetchConversation } from '@/lib/cloud';
import { useChatStore, isLocalConversationId } from '@/lib/store/chat';
import { useAuthStore } from '@/lib/store/auth';
import { useSettingsStore } from '@/lib/store/settings';
import { useUiStore } from '@/lib/store/ui';
import { uid } from '@/lib/utils';
import { playCompletionChime } from '@/lib/sound';
import type { AttachmentMeta, Message } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/toast';
import { Composer } from '@/components/composer';
import { MessageList } from '@/components/message-list';
import { Welcome } from '@/components/welcome';

export interface ChatPanelProps {
  /** The conversation being shown, or null for a brand-new chat. */
  conversationId: string | null;
}

/** Inline payloads are capped so a long thread never blows the request size. */
const HISTORY_INLINE_BUDGET = 2_500_000;

/**
 * Run ids identify a single streamed answer.
 *
 * The counter lives outside the component: the panel is remounted when the
 * route changes and a component scoped counter would hand out the same id
 * twice, letting a late event unlock a newer answer.
 */
let runCounter = 0;
function nextRunId(): number {
  runCounter += 1;
  return runCounter;
}

/**
 * The controller of the answer that is currently streaming.
 *
 * It is kept outside the component for the same reason as the run id: after a
 * new chat is sent the route changes and the panel is remounted, but the
 * "Stop" button of the new panel still has to be able to cancel the answer
 * that the old instance is streaming.
 */
let activeController: AbortController | null = null;

/** Tracks which conversation the last load attempt belonged to. */
interface LoadState {
  key: string | null;
  status: 'idle' | 'ready' | 'error';
  message?: string;
}

/**
 * Keep only as much inline file data as the request budget allows, newest
 * first, so the model can still re-read recent images.
 */
function buildHistory(messages: Message[]): ChatRequestPayload['history'] {
  const prepared = messages
    .filter((message) => message.role === 'user' || message.role === 'assistant')
    .filter((message) => message.content.trim().length > 0 || message.attachments.length > 0)
    .map((message) => ({
      role: message.role,
      content: message.content,
      attachments: message.attachments.map((attachment) => ({ ...attachment })),
    }));

  let budget = HISTORY_INLINE_BUDGET;
  for (let index = prepared.length - 1; index >= 0; index -= 1) {
    const attachments = prepared[index].attachments ?? [];
    let used = 0;
    for (const attachment of attachments) {
      if (!attachment.dataUrl) continue;
      const cost = Math.ceil((attachment.dataUrl.length * 3) / 4);
      if (used + cost > budget) {
        attachment.dataUrl = undefined;
        continue;
      }
      used += cost;
      budget -= cost;
    }
  }

  return prepared;
}

export function ChatPanel({ conversationId }: ChatPanelProps) {
  const router = useRouter();
  const toast = useToast();
  const openAuth = useUiStore((state) => state.openAuth);

  const messagesByConversation = useChatStore((state) => state.messagesByConversation);
  const conversations = useChatStore((state) => state.conversations);
  const memories = useChatStore((state) => state.memories);
  const createLocalConversation = useChatStore((state) => state.createLocalConversation);
  const setConversation = useChatStore((state) => state.setConversation);

  const user = useAuthStore((state) => state.user);
  const authStatus = useAuthStore((state) => state.status);
  const accountsEnabled = useAuthStore((state) => state.accountsEnabled);

  const model = useSettingsStore((state) => state.model);
  const webSearch = useSettingsStore((state) => state.webSearch);
  const memoryEnabled = useSettingsStore((state) => state.memoryEnabled);
  const autoMemory = useSettingsStore((state) => state.autoMemory);
  const sound = useSettingsStore((state) => state.sound);
  const setSetting = useSettingsStore((state) => state.set);

  const [queries, setQueries] = useState<string[]>([]);
  const [loadState, setLoadState] = useState<LoadState>({ key: null, status: 'idle' });

  // The streaming state lives in the store: the panel is remounted when the
  // route changes (a new chat becomes /chat/<id>) and component state would
  // be lost while the answer is still coming in.
  //
  // YuvanX streams one answer at a time, so the lock does not depend on the
  // conversation: the id of the conversation changes while an answer is on
  // its way (a new chat is promoted to the cloud), and the composer must stay
  // locked until the answer is finished.
  const streaming = useChatStore((state) => state.streaming);
  const pending = streaming !== null;
  const streamingMessageId = streaming?.messageId ?? null;

  const conversationRef = useRef<string | null>(conversationId);

  /** Cancel the in-flight answer. The partial text is kept. */
  const stop = useCallback(() => {
    activeController?.abort();
  }, []);

  useEffect(() => {
    conversationRef.current = conversationId;
  }, [conversationId]);

  const messages = useMemo(
    () => (conversationId ? (messagesByConversation[conversationId] ?? []) : []),
    [messagesByConversation, conversationId],
  );

  const activeModel =
    model || conversations.find((c) => c.id === conversationId)?.model || DEFAULT_MODEL;

  /* ---------------------------------------------------------------------- */
  /* Load a conversation                                                      */
  /* ---------------------------------------------------------------------- */
  useEffect(() => {
    if (!conversationId) return;
    if (isLocalConversationId(conversationId)) return;
    if (authStatus !== 'authenticated') return;

    let cancelled = false;

    void (async () => {
      const result = await fetchConversation(conversationId);
      if (cancelled) return;
      if (!result) {
        setLoadState({
          key: conversationId,
          status: 'error',
          message: 'That conversation could not be loaded. It may have been deleted.',
        });
        return;
      }
      setConversation(result.conversation);
      // Merge instead of replace: a message that is still being sent or
      // streamed does not exist on the server yet and must not be wiped.
      useChatStore.getState().mergeMessages(result.conversation.id, result.messages);
      setLoadState({ key: conversationId, status: 'ready' });
    })();

    return () => {
      cancelled = true;
    };
  }, [conversationId, authStatus, setConversation]);

  /* Derived load status — no effect needed to flip a spinner on or off. */
  const isRemoteConversation =
    conversationId !== null && !isLocalConversationId(conversationId);

  const loading =
    isRemoteConversation &&
    (authStatus === 'loading' ||
      (authStatus === 'authenticated' && loadState.key !== conversationId));

  const loadError =
    isRemoteConversation && authStatus === 'anonymous'
      ? 'This conversation lives in the cloud. Sign in with the account that created it to open it.'
      : isRemoteConversation &&
          authStatus === 'authenticated' &&
          loadState.key === conversationId &&
          loadState.status === 'error'
        ? (loadState.message ?? 'That conversation could not be loaded. It may have been deleted.')
        : null;

  /* ---------------------------------------------------------------------- */
  /* Streaming                                                                */
  /* ---------------------------------------------------------------------- */
  const runStream = useCallback(
    async (options: {
      targetConversationId: string;
      payload: ChatRequestPayload;
      assistantLocalId: string;
    }) => {
      const { targetConversationId, payload, assistantLocalId } = options;
      const controller = new AbortController();
      activeController = controller;
      // A module level counter keeps run ids unique even when the panel is
      // remounted in the middle of a stream.
      const runId = nextRunId();

      // The assistant message id can change when the server adopts its own.
      let assistantId = assistantLocalId;
      let accumulated = '';
      // The conversation the answer belongs to. It changes when the server
      // promotes a browser-only thread to a cloud conversation.
      let activeId = targetConversationId;
      let promotedId: string | null = null;
      // The browser-only id that the cloud conversation replaced.
      let orphanedId: string | null = null;

      const store = useChatStore.getState();
      store.beginStreaming(targetConversationId, assistantLocalId, runId);
      setQueries([]);

      const applyText = (text: string) => {
        accumulated += text;
        store.patchMessage(activeId, assistantId, { content: accumulated });
      };

      try {
        await streamChat(payload, {
          signal: controller.signal,
          onDelta: applyText,
          onEvent: (event) => {
            switch (event.type) {
              case 'start': {
                if (event.messageId && event.messageId !== assistantId) {
                  // Adopt the server id so later edits can delete the row.
                  store.removeMessage(activeId, assistantId);
                  assistantId = event.messageId;
                  store.addMessage(activeId, {
                    id: assistantId,
                    conversationId: activeId,
                    role: 'assistant',
                    content: accumulated,
                    attachments: [],
                    sources: [],
                    status: 'streaming',
                    createdAt: Date.now(),
                    model: event.model,
                  });
                  store.setStreamingMessage(assistantId);
                }
                return;
              }
              case 'conversation': {
                // The server promoted this thread to the cloud under a new id.
                // Move the transcript across so nothing is lost.
                const nextId = event.conversationId;
                if (!nextId || nextId === activeId) return;
                const live = useChatStore.getState();
                const previous = live.getMessages(activeId);
                if (previous.length) {
                  live.mergeMessages(
                    nextId,
                    previous.map((message) => ({ ...message, conversationId: nextId })),
                  );
                }
                // The conversation leaves the sidebar, but its messages stay in
                // the store until the browser follows the new id, so the
                // transcript never blinks away mid-answer.
                live.removeConversationEntry(activeId);
                const now = Date.now();
                live.setConversation({
                  id: nextId,
                  title: 'New chat',
                  pinned: false,
                  archived: false,
                  saved: false,
                  autoTitle: false,
                  createdAt: now,
                  updatedAt: now,
                });
                live.setActive(nextId);
                live.retargetStreaming(nextId, runId);
                orphanedId = activeId;
                activeId = nextId;
                promotedId = nextId;
                conversationRef.current = nextId;
                // Follow the new id right away so the panel keeps showing the
                // transcript while the answer is still coming in.
                router.replace(`/chat/${nextId}`);
                return;
              }
              case 'search': {
                setQueries(event.queries);
                return;
              }
              case 'reset': {
                // The server threw away a partial answer (retry / failover).
                // Drop it so the transcript only shows the final response.
                accumulated = '';
                store.patchMessage(activeId, assistantId, { content: '' });
                return;
              }
              case 'sources': {
                store.patchMessage(activeId, assistantId, { sources: event.sources });
                return;
              }
              case 'title': {
                store.patchConversation(activeId, { title: event.title, autoTitle: true });
                return;
              }
              case 'memory': {
                event.memories.forEach((memory) => store.addMemory(memory));
                return;
              }
              case 'done': {
                store.patchMessage(activeId, event.message.id, {
                  content: event.message.content || accumulated,
                  sources: event.message.sources,
                  status: 'complete',
                  model: event.message.model,
                });
                // The answer is finished — hand the composer back to the user
                // straight away instead of waiting for the server to finish
                // its housekeeping (title, memory extraction).
                store.endStreaming(runId);
                setQueries([]);
                return;
              }
              case 'error': {
                // A deliberate stop is not an error: keep the partial answer
                // and mark it as stopped.
                if (event.code === 'aborted') {
                  store.patchMessage(activeId, assistantId, {
                    status: 'stopped',
                    error: undefined,
                    errorCode: undefined,
                  });
                } else {
                  store.patchMessage(activeId, assistantId, {
                    status: 'error',
                    error: event.message,
                    errorCode: event.code,
                  });
                }
                store.endStreaming(runId);
                setQueries([]);
                return;
              }
              default:
                return;
            }
          },
        });
      } catch (error) {
        const aborted =
          error instanceof DOMException
            ? error.name === 'AbortError'
            : error instanceof Error && error.name === 'AbortError';

        const storeNow = useChatStore.getState();
        const existing = storeNow
          .getMessages(activeId)
          .find((message) => message.id === assistantId);

        if (aborted) {
          if (existing) {
            storeNow.patchMessage(activeId, assistantId, { status: 'stopped' });
          }
        } else {
          const message =
            error instanceof Error ? error.message : 'YuvanX could not reach the AI service.';
          if (existing) {
            storeNow.patchMessage(activeId, assistantId, {
              status: 'error',
              error: message,
            });
          }
          toast.error(message);
        }
      } finally {
        // Only the newest run owns the UI state. A slower stream that is still
        // finishing its bookkeeping must not unlock a newer answer.
        store.endStreaming(runId);
        if (activeController === controller) activeController = null;
        setQueries([]);
        if (sound) playCompletionChime();
        // The thread now lives in the cloud under a new id — the browser-only
        // copy is no longer needed. It is only dropped once the browser has
        // actually followed the new id, so the transcript never blinks away.
        if (orphanedId && !window.location.pathname.includes(orphanedId)) {
          useChatStore.getState().removeConversation(orphanedId);
        }
        // Follow the conversation to its new home once the answer is complete,
        // so the reload picks up the freshly persisted transcript.
        if (promotedId) router.replace(`/chat/${promotedId}`);
      }
    },
    [router, sound, toast],
  );

  /* ---------------------------------------------------------------------- */
  /* Actions                                                                  */
  /* ---------------------------------------------------------------------- */
  const ensureConversation = useCallback(async (): Promise<string> => {
    if (conversationRef.current) return conversationRef.current;

    // A brand new chat gets its id straight away instead of waiting for a
    // round trip to the server. The id travels with the request; the server
    // creates the matching cloud conversation and hands the real id back
    // through the "conversation" event. That way the answer can start
    // immediately instead of a second later.
    const local = createLocalConversation('New chat');
    conversationRef.current = local.id;
    router.replace(`/chat/${local.id}`);
    return local.id;
  }, [createLocalConversation, router]);

  const buildPayload = useCallback(
    (
      text: string,
      attachments: AttachmentMeta[],
      history: ChatRequestPayload['history'],
      extra: Partial<ChatRequestPayload> = {},
    ): ChatRequestPayload => ({
      message: text,
      attachments: attachments as unknown[],
      history,
      model: activeModel,
      webSearch,
      memoryEnabled,
      autoMemory,
      memories: memoryEnabled ? memories.filter((memory) => memory.enabled) : [],
      persistUserMessage: true,
      ...extra,
    }),
    [activeModel, autoMemory, memories, memoryEnabled, webSearch],
  );

  const send = useCallback(
    async (text: string, attachments: AttachmentMeta[]) => {
      if (pending) return;

      let targetId: string;
      try {
        targetId = await ensureConversation();
      } catch {
        return;
      }

      const store = useChatStore.getState();
      const existing = store.getMessages(targetId);

      // The id is reused for the persisted row so the client store and the
      // database agree on message identity (edit depends on this).
      const userMessageId = uid('m');

      store.addMessage(targetId, {
        id: userMessageId,
        conversationId: targetId,
        role: 'user',
        content: text,
        attachments,
        sources: [],
        status: 'complete',
        createdAt: Date.now(),
      });

      const assistantLocalId = uid('a');
      store.addMessage(targetId, {
        id: assistantLocalId,
        conversationId: targetId,
        role: 'assistant',
        content: '',
        attachments: [],
        sources: [],
        status: 'streaming',
        createdAt: Date.now(),
        model: activeModel,
      });

      await runStream({
        targetConversationId: targetId,
        assistantLocalId,
        payload: {
          ...buildPayload(text, attachments, buildHistory(existing), { userMessageId }),
          conversationId: targetId,
        },
      });
    },
    [activeModel, buildPayload, ensureConversation, pending, runStream],
  );

  /** Shared tail for regenerate / retry / edit — all resend the preceding prompt. */
  const replay = useCallback(
    async (
      targetId: string,
      prompt: Message,
      history: ChatRequestPayload['history'],
      replaceIds: string[],
      options: { persistUserMessage?: boolean; userMessageId?: string } = {},
    ) => {
      const store = useChatStore.getState();
      const assistantLocalId = uid('a');
      store.addMessage(targetId, {
        id: assistantLocalId,
        conversationId: targetId,
        role: 'assistant',
        content: '',
        attachments: [],
        sources: [],
        status: 'streaming',
        createdAt: Date.now(),
        model: activeModel,
      });

      await runStream({
        targetConversationId: targetId,
        assistantLocalId,
        payload: {
          ...buildPayload(prompt.content, prompt.attachments, history, {
            replaceMessageIds: replaceIds,
            // Regenerate and retry replay a prompt that is already stored, so
            // the server must not write it again. Edit replaces the prompt,
            // so it is persisted under its existing id.
            persistUserMessage: options.persistUserMessage ?? false,
            userMessageId: options.userMessageId,
          }),
          conversationId: targetId,
        },
      });
    },
    [activeModel, buildPayload, runStream],
  );

  const regenerate = useCallback(
    async (message: Message) => {
      if (pending || !conversationRef.current) return;
      const targetId = conversationRef.current;

      const store = useChatStore.getState();
      const all = store.getMessages(targetId);
      const index = all.findIndex((m) => m.id === message.id);
      if (index === -1) return;

      let userIndex = index - 1;
      while (userIndex >= 0 && all[userIndex].role !== 'user') userIndex -= 1;
      if (userIndex < 0) return;

      const prompt = all[userIndex];
      const history = buildHistory(all.slice(0, userIndex));
      const replaceIds = all.slice(index).map((m) => m.id);

      store.removeMessagesFrom(targetId, message.id);
      await replay(targetId, prompt, history, replaceIds);
    },
    [pending, replay],
  );

  const edit = useCallback(
    async (message: Message, nextText: string) => {
      if (pending || !conversationRef.current) return;
      const targetId = conversationRef.current;

      const store = useChatStore.getState();
      const all = store.getMessages(targetId);
      const index = all.findIndex((m) => m.id === message.id);
      if (index === -1) return;

      const history = buildHistory(all.slice(0, index));
      const replaceIds = all.slice(index).map((m) => m.id);

      store.removeMessagesFrom(targetId, message.id);

      // Put the edited prompt back so the transcript shows what was actually
      // asked. It keeps the original id, which is what lets the server
      // replace the stored row instead of appending a duplicate.
      const edited: Message = { ...message, content: nextText, status: 'complete' };
      store.addMessage(targetId, edited);

      await replay(targetId, edited, history, replaceIds, {
        persistUserMessage: true,
        userMessageId: edited.id,
      });
    },
    [pending, replay],
  );

  const retry = useCallback(
    async (message: Message) => {
      if (pending || !conversationRef.current) return;
      const targetId = conversationRef.current;

      const store = useChatStore.getState();
      const all = store.getMessages(targetId);
      const index = all.findIndex((m) => m.id === message.id);
      if (index === -1) return;

      let userIndex = index - 1;
      while (userIndex >= 0 && all[userIndex].role !== 'user') userIndex -= 1;
      if (userIndex < 0) return;

      const prompt = all[userIndex];
      const history = buildHistory(all.slice(0, userIndex));
      const replaceIds = all.slice(index).map((m) => m.id);

      store.removeMessagesFrom(targetId, message.id);
      await replay(targetId, prompt, history, replaceIds);
    },
    [pending, replay],
  );

  /* ---------------------------------------------------------------------- */
  /* Render                                                                   */
  /* ---------------------------------------------------------------------- */
  if (loadError) {
    return (
      <div className="flex flex-1 items-center justify-center px-6 py-16">
        <div className="glass max-w-md rounded-[var(--radius-lg)] px-6 py-6 text-center">
          <AlertTriangle size={22} className="mx-auto text-warning" />
          <h2 className="mt-3 font-display text-base font-semibold text-ink">
            This chat could not be opened
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted">{loadError}</p>
          <div className="mt-5 flex justify-center gap-2">
            <Button variant="primary" onClick={() => router.push('/chat')}>
              Start a new chat
            </Button>
            {accountsEnabled && !user ? (
              <Button variant="outline" onClick={() => openAuth('sync')}>
                Sign in
              </Button>
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  const isEmpty = messages.length === 0;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {pending ? <div className="yx-progress h-0.5 w-full shrink-0" aria-hidden="true" /> : null}

      <MessageList
        messages={messages}
        streamingMessageId={streamingMessageId}
        queries={queries}
        onEdit={(message, nextText) => void edit(message, nextText)}
        onRegenerate={(message) => void regenerate(message)}
        onRetry={(message) => void retry(message)}
      />

      {isEmpty && !pending ? (
        <Welcome
          onSelect={(prompt) => void send(prompt, [])}
          accountsEnabled={accountsEnabled}
          authenticated={Boolean(user)}
          onSignIn={() => openAuth('sync')}
        />
      ) : null}

      <div className="shrink-0 px-4 pb-4 sm:px-6">
        <div className="mx-auto w-full max-w-3xl">
          <Composer
            onSend={(text, attachments) => void send(text, attachments)}
            onStop={stop}
            streaming={pending}
            disabled={loading}
            webSearch={webSearch}
            onToggleWebSearch={(value) => setSetting('webSearch', value)}
            authenticated={Boolean(user)}
          />

          {!user ? (
            <p className="mt-2 flex items-center justify-center gap-1.5 text-[0.68rem] text-subtle">
              <WifiOff size={11} />
              Guest mode — chats stay in this browser. Sign in to sync them.
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}
