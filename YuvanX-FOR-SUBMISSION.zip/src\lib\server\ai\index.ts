import { getFallbackProviderConfig, getGeminiConfig } from '@/lib/server/env';
import { geminiProvider } from '@/lib/server/ai/providers/gemini';
import { openAICompatibleProvider } from '@/lib/server/ai/providers/openai-compatible';
import {
  AIProviderError,
  isAbortError,
  type AIProvider,
  type ChatTurn,
  type ProviderResult,
  type TokenUsage,
} from '@/lib/server/ai/types';

export interface CompletionOptions {
  model: string;
  system: string;
  turns: ChatTurn[];
  webSearch?: boolean;
  signal: AbortSignal;
  onText: (delta: string) => void;
  /**
   * Called when a previous attempt already streamed text that must be
   * discarded (a retry, or a failover to another model). Without this the
   * half-finished output of a failed attempt would be glued to the front of
   * the next model's answer.
   */
  onReset?: () => void;
  onSearch?: (queries: string[]) => void;
  onUsage?: (usage: TokenUsage | undefined, model: string) => void;
  maxOutputTokens?: number;
  thinkingLevel?: 'low' | 'medium' | 'high';
}

const MAX_ATTEMPTS_PER_MODEL = 3;
const BASE_BACKOFF_MS = 600;
/** How long a model is skipped after it reports that it is at capacity. */
const OVERLOAD_COOLDOWN_MS = 90_000;
/** Used when the provider does not say when the quota frees up again. */
const QUOTA_FALLBACK_COOLDOWN_MS = 6 * 60 * 60 * 1000;
/**
 * A per-minute limit is enforced over a rolling minute, so a 20 s pause just
 * buys another 429. Park for most of the window unless the provider is more
 * specific about when it frees up.
 */
const RATE_LIMIT_COOLDOWN_MS = 45_000;

interface ModelPause {
  until: number;
  reason: 'overloaded' | 'quota' | 'rate_limit';
}

/**
 * Models that are temporarily unusable. A model that reports "high demand" is
 * skipped for a minute; a model whose daily quota is spent is skipped until
 * the provider says the quota resets. Either way the request fails over to the
 * next model immediately instead of waiting.
 */
const pausedUntil = new Map<string, ModelPause>();

function pauseFor(model: string): ModelPause | null {
  const pause = pausedUntil.get(model);
  if (!pause) return null;
  if (Date.now() >= pause.until) {
    pausedUntil.delete(model);
    return null;
  }
  return pause;
}

/** Read "Please retry in 16h17m30s" so the cooldown matches the real reset. */
function parseRetryAfter(message: string): number | undefined {
  // Seconds are the common shape for a per-minute throttle ("try again in
  // about 12 seconds"), including a decimal like "12.5s".
  const secondsOnly = /(?:retry|try again) in\s+(?:about\s+)?([\d.]+)\s*(?:s\b|seconds?\b)/i.exec(
    message,
  );
  if (secondsOnly?.[1]) {
    const ms = Math.round(Number(secondsOnly[1]) * 1_000);
    if (Number.isFinite(ms) && ms > 0) return ms;
  }

  const match = /retry in\s+((?:\d+h)?(?:\d+m)?(?:\d+s)?)/i.exec(message);
  if (!match || !match[1]) return undefined;
  const hours = /(\d+)h/.exec(match[1]);
  const minutes = /(\d+)m/.exec(match[1]);
  const seconds = /(\d+)s/.exec(match[1]);
  const total =
    (hours ? Number(hours[1]) * 3_600_000 : 0) +
    (minutes ? Number(minutes[1]) * 60_000 : 0) +
    (seconds ? Number(seconds[1]) * 1_000 : 0);
  return total > 0 ? total : undefined;
}

function describeWait(ms: number): string {
  const minutes = Math.round(ms / 60_000);
  if (minutes < 60) return `${Math.max(1, minutes)} minute${minutes === 1 ? '' : 's'}`;
  const hours = Math.round(ms / 3_600_000);
  return `${hours} hour${hours === 1 ? '' : 's'}`;
}

function sleep(ms: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      reject(new AIProviderError('aborted', 'The request was cancelled.', false));
    };
    if (signal.aborted) {
      onAbort();
      return;
    }
    signal.addEventListener('abort', onAbort, { once: true });
  });
}

function buildModelChain(requested: string): string[] {
  const config = getGeminiConfig();
  const chain = [requested];
  if (config) {
    for (const model of config.fallbackModels) {
      if (!chain.includes(model)) chain.push(model);
    }
  }
  // Skip models that are known to be unusable right now. If every model is
  // paused we still try them all rather than failing the request outright.
  const available = chain.filter((model) => pauseFor(model) === null);
  return available.length > 0 ? available : chain;
}

/**
 * Execute a completion with bounded retries, model fallback and provider
 * failover. Only the Gemini provider supports attachments and search, so the
 * secondary provider is only used for plain text requests.
 */
export async function complete(options: CompletionOptions): Promise<ProviderResult> {
  const config = getGeminiConfig();
  if (!config) {
    throw new AIProviderError(
      'auth',
      'GEMINI_API_KEY is not configured on the server.',
      false,
    );
  }

  const chain = buildModelChain(options.model);
  const hasAttachments = options.turns.some((turn) => (turn.attachments ?? []).length > 0);
  const useSearch = Boolean(options.webSearch);

  // The secondary provider can only answer plain text without search. When it
  // can stand in, a dead Gemini key must not become a dead app.
  const fallbackConfig = getFallbackProviderConfig();
  const fallbackEligible = Boolean(fallbackConfig) && !hasAttachments && !useSearch;

  // If every configured model is paused, fail immediately with a clear
  // message instead of burning requests on models we already know cannot
  // answer right now — unless the fallback can take over.
  const allPaused = chain.length > 0 && chain.every((model) => pauseFor(model) !== null);
  if (allPaused && !fallbackEligible) {
    const waits = chain
      .map((model) => pauseFor(model))
      .filter((pause): pause is ModelPause => pause !== null)
      .map((pause) => pause.until - Date.now());
    const soonest = waits.length > 0 ? Math.min(...waits) : QUOTA_FALLBACK_COOLDOWN_MS;
    const soonestPause = chain
      .map((model) => pauseFor(model))
      .filter((pause): pause is ModelPause => pause !== null)
      .sort((a, b) => a.until - b.until)[0];
    const seconds = Math.max(5, Math.ceil(soonest / 1000));

    // A short wait means a per-minute throttle, not a spent daily allowance.
    // Say so plainly instead of implying the whole key is out of quota.
    if (soonestPause?.reason === 'rate_limit' && soonest <= 120_000) {
      throw new AIProviderError(
        'rate_limit',
        `Gemini is asking us to slow down — the free tier allows only a few messages per minute. Try again in about ${seconds} seconds.`,
        true,
      );
    }

    throw new AIProviderError(
      'quota_exceeded',
      `All models on this key have hit their free-tier limit. The next one unlocks in about ${describeWait(soonest)}.`,
      true,
    );
  }

  let lastError: AIProviderError | null = null;
  // Tracks whether an attempt already streamed text, so the accumulator can
  // be reset before a retry or a failover starts a fresh answer.
  let streamed = false;

  const onText = (delta: string) => {
    streamed = true;
    options.onText(delta);
  };

  const discardPartialAnswer = () => {
    if (!streamed) return;
    streamed = false;
    options.onReset?.();
  };

  // Nothing to try when every model is parked and the fallback will answer.
  const modelsToTry = allPaused ? [] : chain;

  for (const model of modelsToTry) {
    for (let attempt = 0; attempt < MAX_ATTEMPTS_PER_MODEL; attempt += 1) {
      const startedAt = Date.now();
      try {
        discardPartialAnswer();
        const result = await geminiProvider.stream(
          {
            model,
            system: options.system,
            turns: options.turns,
            webSearch: useSearch,
            maxOutputTokens: options.maxOutputTokens ?? config.maxOutputTokens,
            thinkingLevel: options.thinkingLevel ?? config.thinkingLevel,
            timeoutMs: config.timeoutMs,
            store: config.store,
            signal: options.signal,
          },
          { onText, onSearch: options.onSearch },
        );
        options.onUsage?.(result.usage, result.model);
        // eslint-disable-next-line no-console -- server-side timing diagnostics
        console.info(
          `[yuvanx] model=${result.model} answered in ${Date.now() - startedAt}ms`,
        );
        return result;
      } catch (error) {
        const providerError =
          error instanceof AIProviderError
            ? error
            : new AIProviderError(
                'unknown',
                error instanceof Error ? error.message : 'Unknown provider error.',
                false,
              );

        console.warn(
          `[yuvanx] model=${model} attempt=${attempt + 1} failed (${providerError.code}) after ${Date.now() - startedAt}ms`,
        );

        if (providerError.code === 'aborted') throw providerError;
        lastError = providerError;

        if (providerError.code === 'overloaded') {
          // Capacity, not a blip: skip this model for a while and fail over
          // to the next one immediately instead of waiting on backoff.
          pausedUntil.set(model, {
            until: Date.now() + OVERLOAD_COOLDOWN_MS,
            reason: 'overloaded',
          });
          break;
        }

        if (providerError.code === 'quota_exceeded') {
          // The daily allowance for this model is spent. Wait exactly as long
          // as the provider says and fail over to the next model right away.
          const wait = parseRetryAfter(providerError.message) ?? QUOTA_FALLBACK_COOLDOWN_MS;
          pausedUntil.set(model, { until: Date.now() + wait, reason: 'quota' });
          break;
        }

        if (providerError.code === 'rate_limit') {
          // A per-minute limit will not clear because we asked again 600 ms
          // later. Park the model and let the next one answer now; prefer the
          // provider's own retry hint when it gives one.
          const hinted = parseRetryAfter(providerError.message);
          const wait = hinted ? Math.max(10_000, hinted) : RATE_LIMIT_COOLDOWN_MS;
          pausedUntil.set(model, {
            until: Date.now() + wait,
            reason: 'rate_limit',
          });
          break;
        }

        if (providerError.code === 'model_not_found') break; // try the next model
        if (!providerError.retryable) break;
        if (attempt === MAX_ATTEMPTS_PER_MODEL - 1) break;

        const backoff = BASE_BACKOFF_MS * Math.pow(2, attempt);
        await sleep(backoff, options.signal);
      }
    }
  }

  // Secondary provider — plain text only.
  if (fallbackEligible && fallbackConfig) {
    try {
      discardPartialAnswer();
      const result = await openAICompatibleProvider.stream(
        {
          model: fallbackConfig.model,
          system: options.system,
          turns: options.turns,
          webSearch: false,
          // The fallback provider's own budget, not Gemini's. Providers such
          // as Groq reject a request outright when max_tokens exceeds the
          // account's per-minute output allowance, so never send Gemini's
          // larger default here.
          maxOutputTokens: config.fallbackMaxOutputTokens,
          thinkingLevel: options.thinkingLevel ?? config.thinkingLevel,
          timeoutMs: config.timeoutMs,
          store: false,
          signal: options.signal,
        },
        { onText },
      );
      options.onUsage?.(result.usage, result.model);
      return result;
    } catch (error) {
      if (isAbortError(error)) throw error;
      // Keep the original Gemini error — it is the more informative one.
    }
  }

  throw lastError ?? new AIProviderError('unknown', 'The AI provider did not respond.', false);
}

/** Non-streaming helper for short internal tasks (titles, memory extraction). */
export async function generateText(options: {
  model: string;
  system: string;
  prompt: string;
  signal: AbortSignal;
  maxOutputTokens?: number;
}): Promise<string> {
  let out = '';
  await complete({
    model: options.model,
    system: options.system,
    turns: [{ role: 'user', content: options.prompt }],
    webSearch: false,
    signal: options.signal,
    maxOutputTokens: options.maxOutputTokens ?? 512,
    onText: (delta) => {
      out += delta;
    },
  });
  return out.trim();
}

export type { AIProvider, ChatTurn, ProviderResult, TokenUsage };
